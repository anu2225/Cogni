package com.eapp.dto.reponseDTO;

public class UserAuthResponseDTO {
    private String token;

    public UserAuthResponseDTO(String token) {
        this.token = token;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
