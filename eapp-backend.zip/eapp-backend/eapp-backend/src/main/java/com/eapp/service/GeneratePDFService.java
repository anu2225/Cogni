package com.eapp.service;


public interface GeneratePDFService {
	
	public byte[] generateEappPDF(String quoteId);


}
