package com.eapp.service;

import com.eapp.dao.TransactionDetailSequenceRepos;
import com.eapp.entity.TransactionDetailSequence;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TransactionDetailSequenceServiceImpl implements TransactionDetailSequenceService{

	@Autowired
	private TransactionDetailSequenceRepos transactionDetailSequenceRepos;

	public int incrementId() {
		TransactionDetailSequence transactionDetailSequence = transactionDetailSequenceRepos
				.save(new TransactionDetailSequence());
		return transactionDetailSequence.getId();
	}
}