package com.eapp.entity;

public class PDFEntity {
	
	private byte[] pdfData;

	public byte[] getPdfData() {
		return pdfData;
	}

	public void setPdfData(byte[] pdfData) {
		this.pdfData = pdfData;
	}


}
