package com.eapp.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity(name = "dropdown_details")
@Table(name = "dropdown_details")
public class DropdownDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int mapping_id;
	
	private String mapping_code;
	private String type;
	private int level;
	private String parent_name;
	private String short_name;
	private String long_name;
	
	public DropdownDetails() {
	}
	
	public DropdownDetails(int mapping_id, String mapping_code, String type, int level, String parent_name,
			String short_name, String long_name) {
		super();
		this.mapping_id = mapping_id;
		this.mapping_code = mapping_code;
		this.type = type;
		this.level = level;
		this.parent_name = parent_name;
		this.short_name = short_name;
		this.long_name = long_name;
	}

	public int getMapping_id() {
		return mapping_id;
	}

	public void setMapping_id(int mapping_id) {
		this.mapping_id = mapping_id;
	}

	public String getMapping_code() {
		return mapping_code;
	}

	public void setMapping_code(String mapping_code) {
		this.mapping_code = mapping_code;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public String getParent_name() {
		return parent_name;
	}

	public void setParent_name(String parent_name) {
		this.parent_name = parent_name;
	}

	public String getShort_name() {
		return short_name;
	}

	public void setShort_name(String short_name) {
		this.short_name = short_name;
	}

	public String getLong_name() {
		return long_name;
	}

	public void setLong_name(String long_name) {
		this.long_name = long_name;
	}
	
	
	
}
