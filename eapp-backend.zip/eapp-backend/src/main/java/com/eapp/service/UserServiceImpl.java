package com.eapp.service;

import com.eapp.dao.UserRepository;
import com.eapp.dto.requestDTO.UserRequestDTO;
import com.eapp.dto.reponseDTO.UserResponseDTO;
import com.eapp.entity.User;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;


@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserServiceImpl(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public UserResponseDTO signup(UserRequestDTO userRequestDTO) {
        if (userRepository.existsById(userRequestDTO.getEmail())) {
            throw new IllegalStateException("User already exists with this email");
        }

        User user = new User(
                userRequestDTO.getEmail(),
                userRequestDTO.getPassword(),
                userRequestDTO.getFirstName(),
                userRequestDTO.getLastName()
        );
        userRepository.save(user);

        return new UserResponseDTO(user.getEmail(), user.getFirstName(), user.getLastName());
    }

    @Override
    public UserResponseDTO login(UserRequestDTO userRequestDTO){
        User user = userRepository.findByEmail(
                userRequestDTO.getEmail()
        ).orElseThrow(() -> new IllegalStateException("User not found"));

        // Compare raw password with encoded password
        if (!passwordEncoder.matches(userRequestDTO.getPassword(), user.getPassword())) {
            throw new IllegalStateException("Invalid password");
        }

        return new UserResponseDTO(user.getEmail(), user.getFirstName(), user.getLastName());
    }

    @Override
    public UserResponseDTO createUser(UserRequestDTO userRequestDTO) {
        User user = new User(
                userRequestDTO.getEmail(),
                userRequestDTO.getPassword(),
                userRequestDTO.getFirstName(),
                userRequestDTO.getLastName()
        );
        userRepository.save(user);
        return new UserResponseDTO(user.getEmail(), user.getFirstName(), user.getLastName());
    }

    @Override
    public UserResponseDTO getUserByEmail(String email) {
        return userRepository.findById(email)
                .map(user -> new UserResponseDTO(user.getEmail(), user.getFirstName(), user.getLastName()))
                .orElse(null);
    }

    @Override
    public List<UserResponseDTO> getAllUsers() {
        return userRepository.findAll().stream()
                .map(user -> new UserResponseDTO(user.getEmail(), user.getFirstName(), user.getLastName()))
                .collect(Collectors.toList());
    }

    @Override
    public void deleteUser(String email) {
        userRepository.deleteById(email);
    }
}
