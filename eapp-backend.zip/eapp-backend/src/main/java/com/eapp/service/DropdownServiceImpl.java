package com.eapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eapp.dao.DropdownDetailsRepos;

@Service
public class DropdownServiceImpl implements DropdownService {
	
	@Autowired
	private DropdownDetailsRepos dropdownDetailsRepos;

	@Override
	public List<String> findCountries() {
		return dropdownDetailsRepos.findCountries();
	}

	@Override
	public List<String> findStates(String country) {
		return dropdownDetailsRepos.findStates(country);
	}

	@Override
	public List<String> findDistrictes(String state) {
		return dropdownDetailsRepos.findDistrictes(state);
	}

	@Override
	public List<String> findBanks() {
		return dropdownDetailsRepos.findBanks();
	}

	@Override
	public List<String> findBankBranches(String bank) {
		return dropdownDetailsRepos.findBankBranches(bank);
	}
	
	@Override
	public List<String> findEvidenceProof() {
		return dropdownDetailsRepos.findEvidenceProof();
	}
	
	@Override
	public List<String> findOccupationCode() {
		return dropdownDetailsRepos.findOccupationCode(); 
	}
	
	@Override
	public List<String> findMaritalStatus() {
		return dropdownDetailsRepos.findMaritalStatus();
	}
	
	@Override
	public List<String> findFamilyMemberType() {
		return dropdownDetailsRepos.findFamilyMemberType();
	}
	
	@Override
	public List<String> findBeneficiaryRelation() {
		return dropdownDetailsRepos.findBeneficiaryRelation();
	}

}
