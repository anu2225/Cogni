package com.eapp.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eapp.dao.QuoteDetailsRepos;
import com.eapp.entity.QuoteDetails;

@Service
public class EappServiceImpl implements EappService {
	
	@Autowired
	private QuoteDetailsRepos eappRepos;

	@Override
	public QuoteDetails create(QuoteDetails eapp) {
		try {
		Optional<QuoteDetails> detailsNewVersionNo = eappRepos.findDetailsWithLatestVersionNo(eapp.getQuotation_id(),eapp.getScreen_No());
		eapp.setUPDATED_BY("Dummy");
		eapp.setUPDATED_TIME(new Date());
		QuoteDetails savedEapp = null;
		if(detailsNewVersionNo.isEmpty()) {
			eapp.setCREATED_BY("dummy");
			eapp.setCREATION_TIME(new Date());
			savedEapp=eappRepos.save(eapp);
		} else {
			eapp.setVERSION_NO(detailsNewVersionNo.get().getVERSION_NO()+1);
			eapp.setCREATED_BY(detailsNewVersionNo.get().getCREATED_BY());
			eapp.setCREATION_TIME(detailsNewVersionNo.get().getCREATION_TIME());
			detailsNewVersionNo.get().setEFFECTIVE_END_DATE(new Date());
			eappRepos.save(detailsNewVersionNo.get());
			savedEapp=eappRepos.save(eapp);
		}
		return savedEapp;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public QuoteDetails update(QuoteDetails eapp) {
		return eappRepos.save(eapp);
	}

	@Override
	public List<QuoteDetails> getAll() {
		return eappRepos.findAll();
	}

	@Override
	public QuoteDetails getEappDetailsById(int id) {
		return eappRepos.findById(id).get();
	}

	@Override
	public void deleteEappDetailsById(int id) {
		eappRepos.deleteById(id);
	}

	@Override
	public QuoteDetails getCaseDetailsByQuotoIdAndScreenNo(String quoationId, int screenNo) {
		try {
			Optional<QuoteDetails> detailsNewVersionNo = eappRepos.findDetailsWithLatestVersionNo(quoationId,screenNo);
			if(detailsNewVersionNo.isEmpty()) {
				return null;
			}
			return detailsNewVersionNo.get();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
