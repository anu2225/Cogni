package com.eapp.service;

import java.util.List;

import org.springframework.stereotype.Service;
@Service
public interface DropdownService {
	
	List<String> findCountries();
	List<String> findStates(String country);
	List<String> findDistrictes(String state);
	List<String> findBanks();
	List<String> findBankBranches(String bank);
	List<String> findEvidenceProof();
	List<String> findOccupationCode();
	List<String> findMaritalStatus();
	List<String> findFamilyMemberType();
	List<String> findBeneficiaryRelation();

	
	
	

	
}
