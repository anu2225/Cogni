package com.eapp.service;

import com.eapp.dto.requestDTO.UserRequestDTO;
import com.eapp.dto.reponseDTO.UserResponseDTO;

import java.util.List;

public interface UserService {
    UserResponseDTO createUser(UserRequestDTO userRequestDTO);
    UserResponseDTO getUserByEmail(String email);
    List<UserResponseDTO> getAllUsers();
    void deleteUser(String email);
    UserResponseDTO signup(UserRequestDTO userRequestDTO);
    UserResponseDTO login(UserRequestDTO userRequestDTO);
}
