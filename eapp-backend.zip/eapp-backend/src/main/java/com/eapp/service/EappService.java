package com.eapp.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.eapp.entity.QuoteDetails;

@Service
public interface EappService {
	
	QuoteDetails create(QuoteDetails eapp);
	QuoteDetails update(QuoteDetails eapp);
	List<QuoteDetails> getAll();
	void deleteEappDetailsById(int id);
	QuoteDetails getEappDetailsById(int id);
	QuoteDetails getCaseDetailsByQuotoIdAndScreenNo(String quoationId, int screenNo);
}
