package com.eapp.service;

import com.eapp.dto.requestDTO.CalculationRequest;
import com.eapp.dto.reponseDTO.CalculationResponse;
import org.springframework.stereotype.Service;

@Service
public class PremiumService {

    public CalculationResponse calculateInternal(CalculationRequest req) {

        double baseRate = 12.5;      // internal placeholder rate
        double premium = (req.getSumAssured() / 1000) * baseRate;

        if (req.isSmoker()) {
            premium = premium * 1.25;     // smoker loading
        }

        CalculationResponse res = new CalculationResponse();
        res.setPremium(Math.round(premium));
        res.setMessage("Internal premium calculated");
        res.setFromCoherent(false);

        return res;
    }
}
