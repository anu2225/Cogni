package com.eapp.service;

import org.springframework.stereotype.Service;

@Service
public class PaymentsService {
	
	private static final String KEY = "";
	private static final String KEY_SECRET = "";
	private static final String CURRENNCY = "";


	
	public void createPaymentTransaction(Double amount) {
		
	}

}
