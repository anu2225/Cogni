package com.eapp.service;
 
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;
 
import com.eapp.dao.QuoteDetailsRepos;
import com.eapp.entity.QuoteDetails;
 
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimplePdfExporterConfiguration;
 
@Service
public class GeneratePDFServiceImpl implements GeneratePDFService {
	@Autowired
	private QuoteDetailsRepos quoteRepos;
 
	public List<QuoteDetails> getPDFData(String quoationId) {
		List<QuoteDetails> quoteList = new ArrayList<QuoteDetails>();
		for (int i = 1; i < 11; i++) {
			try {
				
				Optional<QuoteDetails> findDetailsWithLatestVersionNo = quoteRepos
						.findDetailsWithLatestVersionNo(quoationId, i);
				if (!findDetailsWithLatestVersionNo.isEmpty()) {
					quoteList.add(findDetailsWithLatestVersionNo.get());
			}
 
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return quoteList;
 
	}
 
 
	public byte[] generateEappPDF(String quoationId) {
 
		List<QuoteDetails> quoteList = getPDFData(quoationId);
		
		System.out.println("Quote list is"+ quoteList);
		
		JRPdfExporter exporter = new JRPdfExporter();
		List<JasperPrint> jasperPrintList = new ArrayList<JasperPrint>();
		try {
			String jrxmlFileName = ResourceUtils.getFile("classpath:eAppPDF.jrxml").getAbsolutePath();
			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("customerName", "John Smith");
			JasperReport jasperReport = JasperCompileManager.compileReport(jrxmlFileName);
 
			JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, new JREmptyDataSource(1));
			jasperPrintList.add(jasperPrint);
 
		} catch (Exception e) {
			System.out.println("Error Generating Report");
			e.printStackTrace();
		}
 
		exporter.setExporterInput(SimpleExporterInput.getInstance(jasperPrintList));
		SimplePdfExporterConfiguration configuration = new SimplePdfExporterConfiguration();
		configuration.setCreatingBatchModeBookmarks(true);
		exporter.setConfiguration(configuration);
 
		try {
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(outputStream));
			exporter.exportReport();
			byte[] pdfByteArray = outputStream.toByteArray();
			System.out.println("Exporting pdf as byteararay");
			return pdfByteArray;
		} catch (Exception e) {
			System.out.println("Error Exporting pdf as byteararay");
			return null;
 
		}
 
	}
 
}
 
 