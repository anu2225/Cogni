package com.eapp.service;

public interface TransactionDetailSequenceService {

	public int incrementId();

}
