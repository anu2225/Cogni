package com.eapp.dto.requestDTO;

public class CalculationRequest {

    private double sumAssured;
    private boolean smoker;
    private int age;

    public double getSumAssured() {
        return sumAssured;
    }

    public void setSumAssured(double sumAssured) {
        this.sumAssured = sumAssured;
    }

    public boolean isSmoker() {
        return smoker;
    }

    public void setSmoker(boolean smoker) {
        this.smoker = smoker;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}

//package com.eapp.dto.requestDTO;
//
//import lombok.Data;
//
//@Data
//public class CalculationRequest {
//
//    private String _1a_DOB;
//    private String _1b_Product;
//    private String _1c_Gender;
//    private double _1d_Face_Amount;
//    private int _1e_Occupation;
//    private String _1h_Policy_Inception_Date;
//    private String _1i_Smoker;
//    private String _1j_Pre_Existing_Disease;
//    private double _1k_Extra_mortality;
//    private int _1p_Policy_Term;
//    private String _1r_Mandatory_Premium_Period;
//    private double _1zb_PAV;
//    private double _1zc_per_mille_rating_death;
//    private double _1zd_per_mille_rating_TPD;
//    private double _1ze_per_mille_rating_SCI;
//
//    private String _2a_Death_Benefit;
//    private String _2b_Total_and_Permanent_Disability_TPD;
//    private String _2c_Accidental_Death_and_Dismemberment_ADD;
//    private String _2d_Staged_Critical_Illness_SCI;
//    private String _2e_Hospital_Cash_Benefit_HCB;
//
//    private String _3a_Partial_Withdrawl;
//    private double _3b_Partial_Withdrawl_Amount;
//
//    // Meta
//    private String version_id;
//    private String call_purpose;
//    private String source_system;
//
//    public double get_1d_Face_Amount() {
//
//
//        return 0;
//    }
//
//    public String getVersion_id() {
//
//
//        return "";
//    }
//
//    public String getCall_purpose() {
//
//
//        return "";
//    }
//
//    public String getSource_system() {
//
//
//        return "";
//    }
//
//    public double getSumAssured() {
//        return 0;
//    }
//
//    public boolean isSmoker() {
//        return false;
//    }
//}

