package com.eapp.dto.reponseDTO;

public class UserResponseDTO {
    private String email;
    private String firstName;
    private String lastName;

    // Constructor
    public UserResponseDTO(String email, String firstName, String lastName) {
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    // Getters
    public String getEmail() {
        return email;
    }
    public String getFirstName() {
        return firstName;
    }
    public String getLastName() {
        return lastName;
    }
}
