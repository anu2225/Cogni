package com.eapp.dto.reponseDTO;

public class CalculationResponse {

    private double premium;
    private String message;
    private boolean fromCoherent;

    public double getPremium() {
        return premium;
    }

    public void setPremium(double premium) {
        this.premium = premium;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isFromCoherent() {
        return fromCoherent;
    }

    public void setFromCoherent(boolean fromCoherent) {
        this.fromCoherent = fromCoherent;
    }
}

//package com.eapp.dto.reponseDTO;
//
//import lombok.Data;
//
//@Data
//public class CalculationResponse {
//
//    private Object apiResponse;
//    private String message;
//    private double fallbackPremium;
//
//    public void setApiResponse(Object coherentResponse) {
//
//    }
//
//    public void setMessage(String coherentApiSuccess) {
//
//    }
//
//    public void setFallbackPremium(double fallbackPremium) {
//
//    }
//
//    public void setPremium(long round) {
//
//    }
//
//    public void setFromCoherent(boolean b) {
//
//    }
//}