package com.eapp.dao;

import com.eapp.entity.TransactionDetailSequence;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TransactionDetailSequenceRepos extends JpaRepository<TransactionDetailSequence, Integer> {

}
