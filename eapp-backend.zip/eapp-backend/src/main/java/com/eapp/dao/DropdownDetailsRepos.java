package com.eapp.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.eapp.entity.DropdownDetails;

public interface DropdownDetailsRepos extends JpaRepository<DropdownDetails, Integer> {
	
	@Query("select long_name from dropdown_details where mapping_code='LOCATION' and `type` = 'Country'")
	List<String> findCountries();
	
	@Query("select long_name from dropdown_details where mapping_code='LOCATION' and `type` = 'State' and parent_name=:country")
	List<String> findStates(String country);
	
	@Query("select long_name from dropdown_details where mapping_code='LOCATION' and `type` = 'District' and parent_name=:state")
	List<String> findDistrictes(String state);
	
	@Query("select long_name from dropdown_details where mapping_code='BANK' and `type` = 'Bank Name'")
	List<String> findBanks();
	
	@Query("select long_name from dropdown_details where mapping_code='BANK' and `type` = 'Branch Name' and parent_name=:bank")
	List<String> findBankBranches(String bank);
	
	@Query("select long_name from dropdown_details where mapping_code='ID' and `type` = 'Evidence'")
	List<String> findEvidenceProof();
	
	@Query("select long_name from dropdown_details where mapping_code='OCCUPATION' and `type` = 'Occupation Code'")
	List<String> findOccupationCode();
	
	@Query("select long_name from dropdown_details where mapping_code='MARITAL STATUS' and `type` = 'Marriage Status'")
	List<String> findMaritalStatus();
	
	@Query("select long_name from dropdown_details where mapping_code='FAMILY' and `type` = 'Family Member Type'")
	List<String> findFamilyMemberType();
	
	@Query("select long_name from dropdown_details where mapping_code='BENEFICIARY' and `type` = 'Beneficiary Relation'")
	List<String> findBeneficiaryRelation();
	
	
	
	

}
