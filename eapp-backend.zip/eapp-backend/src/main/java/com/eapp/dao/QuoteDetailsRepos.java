package com.eapp.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.eapp.entity.QuoteDetails;


public interface QuoteDetailsRepos extends JpaRepository<QuoteDetails, Integer> {
	
	@Query("select t from t_quotation_save t  where \r\n"
			+ "Quotation_id=:quoationId and Screen_No = :screenNo and\r\n"
			+ "VERSION_NO=(\r\n"
			+ "select max(VERSION_NO) from t_quotation_save \r\n"
			+ "where Quotation_id=:quoationId and Screen_No = :screenNo\r\n"
			+ "group by Quotation_id,Screen_No )")
	Optional<QuoteDetails> findDetailsWithLatestVersionNo(String quoationId, int screenNo);

}
