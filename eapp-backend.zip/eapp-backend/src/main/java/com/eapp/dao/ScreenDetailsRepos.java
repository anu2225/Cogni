package com.eapp.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eapp.entity.ScreenDetails;

public interface ScreenDetailsRepos extends JpaRepository<ScreenDetails,Integer> {

}
