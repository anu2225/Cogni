package com.eapp.entity;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity(name = "t_quotation_save")
@Table(name = "t_quotation_save")
public class QuoteDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Quotation_Save_id;
	
	private String Quotation_id;
	private int Screen_No;
	private int VERSION_NO = 1;
	private String JSON_DATA;
	private Date CREATION_TIME;
	private String CREATED_BY;
	private Date UPDATED_TIME;
	private String UPDATED_BY;
	private Date EFFECTIVE_END_DATE;
	
	public QuoteDetails() {
	}
	
	public QuoteDetails(String quotation_id, int screen_No, String jSON_DATA) {
		super();
		Quotation_id = quotation_id;
		Screen_No = screen_No;
		JSON_DATA = jSON_DATA;
	}
	
	public QuoteDetails(int quotation_Save_id, String quotation_id, int screen_No, int vERSION_NO, String jSON_DATA,
			Date cREATION_TIME, String cREATED_BY, Date uPDATED_TIME, String uPDATED_BY, Date eFFECTIVE_END_DATE) {
		super();
		Quotation_Save_id = quotation_Save_id;
		Quotation_id = quotation_id;
		Screen_No = screen_No;
		VERSION_NO = vERSION_NO;
		JSON_DATA = jSON_DATA;
		CREATION_TIME = cREATION_TIME;
		CREATED_BY = cREATED_BY;
		UPDATED_TIME = uPDATED_TIME;
		UPDATED_BY = uPDATED_BY;
		EFFECTIVE_END_DATE = eFFECTIVE_END_DATE;
	}

	public int getQuotation_Save_id() {
		return Quotation_Save_id;
	}

	public void setQuotation_Save_id(int quotation_Save_id) {
		Quotation_Save_id = quotation_Save_id;
	}

	public String getQuotation_id() {
		return Quotation_id;
	}

	public void setQuotation_id(String quotation_id) {
		Quotation_id = quotation_id;
	}

	public int getScreen_No() {
		return Screen_No;
	}

	public void setScreen_No(int screen_No) {
		Screen_No = screen_No;
	}

	public int getVERSION_NO() {
		return VERSION_NO;
	}

	public void setVERSION_NO(int vERSION_NO) {
		VERSION_NO = vERSION_NO;
	}

	public String getJSON_DATA() {
		return JSON_DATA;
	}

	public void setJSON_DATA(String jSON_DATA) {
		JSON_DATA = jSON_DATA;
	}

	public Date getCREATION_TIME() {
		return CREATION_TIME;
	}

	public void setCREATION_TIME(Date cREATION_TIME) {
		CREATION_TIME = cREATION_TIME;
	}

	public String getCREATED_BY() {
		return CREATED_BY;
	}

	public void setCREATED_BY(String cREATED_BY) {
		CREATED_BY = cREATED_BY;
	}

	public Date getUPDATED_TIME() {
		return UPDATED_TIME;
	}

	public void setUPDATED_TIME(Date uPDATED_TIME) {
		UPDATED_TIME = uPDATED_TIME;
	}

	public String getUPDATED_BY() {
		return UPDATED_BY;
	}

	public void setUPDATED_BY(String uPDATED_BY) {
		UPDATED_BY = uPDATED_BY;
	}

	public Date getEFFECTIVE_END_DATE() {
		return EFFECTIVE_END_DATE;
	}

	public void setEFFECTIVE_END_DATE(Date eFFECTIVE_END_DATE) {
		EFFECTIVE_END_DATE = eFFECTIVE_END_DATE;
	}

	@Override
	public String toString() {
		return "T_QUOTATION_SAVE [Quotation_Save_id=" + Quotation_Save_id + ", Quotation_id=" + Quotation_id
				+ ", Screen_No=" + Screen_No + ", VERSION_NO=" + VERSION_NO + ", JSON_DATA=" + JSON_DATA
				+ ", CREATION_TIME=" + CREATION_TIME + ", CREATED_BY=" + CREATED_BY + ", UPDATED_TIME=" + UPDATED_TIME
				+ ", UPDATED_BY=" + UPDATED_BY + ", EFFECTIVE_END_DATE=" + EFFECTIVE_END_DATE + "]";
	}
	
	

}
