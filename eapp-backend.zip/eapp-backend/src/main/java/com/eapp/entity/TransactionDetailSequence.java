package com.eapp.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "txn_details_seq")
public class TransactionDetailSequence {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	public TransactionDetailSequence() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
}