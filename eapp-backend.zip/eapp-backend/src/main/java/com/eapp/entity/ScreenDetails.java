package com.eapp.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity(name = "T_SCREEN_MASTER")
@Table(name = "T_SCREEN_MASTER")
public class ScreenDetails {
	
	@Id
	private int Screen_No;
	private String Screen_name;
	private int SCREEN_SEQ;
	
	public ScreenDetails() {
	}

	public int getScreen_No() {
		return Screen_No;
	}

	public void setScreen_No(int screen_No) {
		Screen_No = screen_No;
	}

	public String getScreen_name() {
		return Screen_name;
	}

	public void setScreen_name(String screen_name) {
		Screen_name = screen_name;
	}

	public int getSCREEN_SEQ() {
		return SCREEN_SEQ;
	}

	public void setSCREEN_SEQ(int sCREEN_SEQ) {
		SCREEN_SEQ = sCREEN_SEQ;
	}

	@Override
	public String toString() {
		return "t_screen_master [Screen_No=" + Screen_No + ", Screen_name=" + Screen_name + ", SCREEN_SEQ=" + SCREEN_SEQ
				+ "]";
	}
	

}
