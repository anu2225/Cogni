package com.eapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eapp.service.DropdownService;

@RestController
@RequestMapping("/eapp/dropdown")
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:3003"})
public class DropdownController {
	
	@Autowired
	private DropdownService dropdownService;
   
	@GetMapping("/getCoutries")
	public ResponseEntity<List<String>> findCountries() {
		return  new ResponseEntity<>(dropdownService.findCountries(),HttpStatus.OK);
	}
	
	@GetMapping("/getStates")
	public ResponseEntity<List<String>> findStates(@Param("country") String country) {
		return  new ResponseEntity<>(dropdownService.findStates(country),HttpStatus.OK);
	}
	
	@GetMapping("/getDistrict")
	public ResponseEntity<List<String>> findDistrictes(@Param("state") String state) {
		return  new ResponseEntity<>(dropdownService.findDistrictes(state),HttpStatus.OK);
	}
	
	@GetMapping("/getBanks")
	public ResponseEntity<List<String>> findBanks() {
		return  new ResponseEntity<>(dropdownService.findBanks(),HttpStatus.OK);
	}
	
	@GetMapping("/getBankBranch")
	public ResponseEntity<List<String>> findBankBranches(@Param("bank") String bank) {
		return  new ResponseEntity<>(dropdownService.findBankBranches(bank),HttpStatus.OK);
	}
	
	@GetMapping("/getEvidenceProof")
	public ResponseEntity<List<String>> findEvidenceProof() {
		return  new ResponseEntity<>(dropdownService.findEvidenceProof(),HttpStatus.OK);
	}
	
	@GetMapping("/getOccupationCode")
	public ResponseEntity<List<String>> findOccupationCode() {
		return  new ResponseEntity<>(dropdownService.findOccupationCode(),HttpStatus.OK);
	}
	
	@GetMapping("/getMaritalStatus")
	public ResponseEntity<List<String>> findMaritalStatus() {
		return  new ResponseEntity<>(dropdownService.findMaritalStatus(),HttpStatus.OK);
	}
	@GetMapping("/getFamilyMemberType")
	public ResponseEntity<List<String>> findFamilyMemberType() {
		return  new ResponseEntity<>(dropdownService.findFamilyMemberType(),HttpStatus.OK);
	}
	
	@GetMapping("/getBeneficiaryRelation")
	public ResponseEntity<List<String>> findBeneficiaryRelation() {
		return  new ResponseEntity<>(dropdownService.findBeneficiaryRelation(),HttpStatus.OK);
	}
}
