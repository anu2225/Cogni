package com.eapp.controller;

import com.eapp.dto.reponseDTO.UserAuthResponseDTO;
import com.eapp.dto.requestDTO.UserRequestDTO;
import com.eapp.dto.reponseDTO.UserResponseDTO;
import com.eapp.entity.User;
import com.eapp.service.UserService;
import com.eapp.security.JwtUtil;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class UserAuthController {

    private final UserService userService;
    private final JwtUtil jwtUtil;
    private final AuthenticationManager authenticationManager;
    private final PasswordEncoder passwordEncoder;

    public UserAuthController(UserService userService,
                              JwtUtil jwtUtil,
                              AuthenticationManager authenticationManager,
                              PasswordEncoder passwordEncoder) {
        this.userService = userService;
        this.jwtUtil = jwtUtil;
        this.authenticationManager = authenticationManager;
        this.passwordEncoder = passwordEncoder;
    }

    @PostMapping("/signup")
    public ResponseEntity<UserResponseDTO> signup(@RequestBody UserRequestDTO userRequestDTO) {
        // Encrypt password before saving
        userRequestDTO.setPassword(passwordEncoder.encode(userRequestDTO.getPassword()));

        UserResponseDTO response =  userService.signup(userRequestDTO);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/login")
    public ResponseEntity<UserAuthResponseDTO> login(@RequestBody UserRequestDTO userRequestDTO) {
        UserResponseDTO response = userService.login(userRequestDTO);

        // Generate JWT token after successful login
        String token = jwtUtil.generateToken(response.getEmail(),response.getFirstName(),response.getLastName());

        UserAuthResponseDTO res = new UserAuthResponseDTO(token);

        return ResponseEntity.ok(res);
    }
}