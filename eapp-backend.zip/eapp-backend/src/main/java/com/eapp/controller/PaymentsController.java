//package com.eapp.controller;
//
//import org.json.JSONObject;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.razorpay.Order;
//import com.razorpay.RazorpayClient;
//import com.razorpay.RazorpayException;
//
//@RestController
//@RequestMapping("/eapp/payments")
//@CrossOrigin(origins = {"http://localhost:5000", "http://localhost:3003","http://localhost:3000"})
//
//public class PaymentsController {
//
//
//
////	@GetMapping("/createPaymentTransaction")
////	public void createPaymentTransaction(@Param("amount") Double amount) {
////
////	}
////
//    @Value("${rzp_key_id}")
//    private String keyId;
//
//    @Value("${rzp_key_secret}")
//    private String secret;
//
//    @PostMapping("/createPaymentTransaction/")
//    public String Payment(@RequestParam("amount") String stramount) throws RazorpayException {
//        System.out.println("line 38 " + stramount);
//        RazorpayClient razorpayClient = new RazorpayClient(keyId, secret);
//        JSONObject orderRequest = new JSONObject();
//        String[] parts = stramount.split("\\.");
//        String amtStr = parts[0];
//        int amt = Integer.parseInt(amtStr);
//        System.out.println(amt  + "<== int Amount is");
//        System.out.println("Amount is ==>  " + amt);
//        orderRequest.put("amount",1399900 );
//        orderRequest.put("currency", "INR");
//        orderRequest.put("receipt", "order_receipt_144");
//
//        Order order = razorpayClient.orders.create(orderRequest);
//        String orderId = order.get("id");
//        System.out.println("Order ==> "+ order);
//
//        System.out.println("Order Request" + orderRequest);
//
//        return orderId;
//    }
//
//
//
//}
//
//
//
