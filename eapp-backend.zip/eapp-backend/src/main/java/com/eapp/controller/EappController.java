package com.eapp.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eapp.entity.QuoteDetails;
import com.eapp.service.EappService;





@RestController
@RequestMapping("/eapp")
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:3003"})
public class EappController {
	
	private final Logger logger =LoggerFactory.getLogger(EappController.class);
	
	@Autowired
	private EappService eappService;
	
	
	@PostMapping("/add")
	public ResponseEntity<QuoteDetails> create(@RequestBody QuoteDetails eapp) {
		
		logger.info("Start"); 
		logger.debug("Eapp details"+ eapp);
		System.out.println("Data => " + eapp);
		logger.info("End");
		 
		return new ResponseEntity<>(eappService.create(eapp), HttpStatus.CREATED);
	}
	
	@PostMapping("/update")
	public ResponseEntity<QuoteDetails> update(@RequestBody QuoteDetails eapp) {
		logger.info("Start"); 
		logger.debug("Eapp details"+ eapp);
		logger.info("End");
		 
		return new ResponseEntity<>(eappService.update(eapp),HttpStatus.OK);
	}
	
	@GetMapping("/getAll")
	public ResponseEntity<List<QuoteDetails>> findAll() {
		return  new ResponseEntity<>(eappService.getAll(),HttpStatus.OK);
	}
	
	@GetMapping("/getByID")
	public ResponseEntity<QuoteDetails> getByID(@Param("id") int id) {
		return  new ResponseEntity<>(eappService.getEappDetailsById(id),HttpStatus.OK);
	}
	
	@GetMapping("/getCaseDetailsByQuotoIdAndScreenNo")
	public ResponseEntity<QuoteDetails> getCaseDetailsByQuotoIdAndScreenNo(
			@Param("quoationId") String quoationId,@Param("screenNo") int screenNo) {
		return  new ResponseEntity<>(eappService.getCaseDetailsByQuotoIdAndScreenNo(quoationId, screenNo),HttpStatus.OK);
	}
}
