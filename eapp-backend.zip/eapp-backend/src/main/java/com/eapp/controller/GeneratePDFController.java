package com.eapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.eapp.entity.PDFEntity;
import com.eapp.service.GeneratePDFService;

@RestController
@RequestMapping("/api/generate-pdf-service")
@CrossOrigin(origins = { "http://localhost:3000", "http://localhost:3003", "http://localhost:5000" })

public class GeneratePDFController {

	@Autowired
	private GeneratePDFService generatePdfService;
	@PostMapping(value = "/generateEappPdf")
	public byte[] generatePdfService(@RequestBody String quoteId) {

		System.out.println("Generate PDF Entry");
		byte[] generatePdf = generatePdfService.generateEappPDF(quoteId);
		PDFEntity pdfEntity = new PDFEntity();
		pdfEntity.setPdfData(generatePdf);
		return generatePdf;

	}

}
