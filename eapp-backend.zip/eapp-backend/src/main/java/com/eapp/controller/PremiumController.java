package com.eapp.controller;

import com.eapp.dto.requestDTO.CalculationRequest;
import com.eapp.dto.reponseDTO.CalculationResponse;
import com.eapp.service.CoherentService;
import com.eapp.service.PremiumService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/calc")
public class PremiumController {

    @Autowired
    private PremiumService premiumService;

    @Autowired
    private CoherentService coherentService;

    @PostMapping("/premium")
    public CalculationResponse calculatePremium(@RequestBody CalculationRequest req) {

        // Step 1: Try Coherent
        CalculationResponse coherentRes = coherentService.getCoherentPremium(req);

        if (coherentRes != null) {
            coherentRes.setMessage("Premium calculated from Coherent");
            coherentRes.setFromCoherent(true);
            return coherentRes;
        }

        // Step 2: If Coherent Fails → Internal
        CalculationResponse internal = premiumService.calculateInternal(req);
        internal.setMessage("Coherent failed — Internal premium calculated");
        internal.setFromCoherent(false);

        return internal;
    }
}


//package com.eapp.controller;
//
//import com.eapp.dto.requestDTO.CalculationRequest;
//import com.eapp.dto.reponseDTO.CalculationResponse;
//import com.eapp.service.CoherentService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.*;
//
//@RestController
//@RequestMapping("/premium")
//public class PremiumController {
//
//    @Autowired
//    private CoherentService service;
//
//    @PostMapping("/calculate")
//    public CalculationResponse calculate(@RequestBody CalculationRequest request) {
//        return service.calculatePremium(request);
//    }
//}
