import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import i18next from "i18next";
import cookies from "js-cookie";
import BasicTabs from "./Components/BasicTabs";
import { Translate } from "@mui/icons-material";
import { useParams } from "react-router-dom";
import styled from "@emotion/styled";
import {Grid,IconButton,Menu,MenuItem} from "@mui/material";
import React from "react";

const CustomAppBar = styled(AppBar)({
  backgroundColor:'#808080'
});

interface Language {
  code: string;
  name: string;
  country_code: string;
  dir: string;
}

const languages : Language[] = [
  {
    code: "en",
    name: "English",
    country_code: "gb",
    dir:'ltr',
  },
  {
    code: "th",
    name: "แบบไทย",
    country_code: "th",
    dir:'ltr',
  },
];

export default function App() {
  const currentLanguageCode = cookies.get("i18next") || "en";
  const currentLanguage = languages.find((l) => l.code === currentLanguageCode);
  const { t } = useTranslation();
  const params = useParams();

  useEffect(() => {
    //console.log('Setting page stuff')
    document.body.dir = currentLanguage?.dir || "ltr";
    document.title = t("app_title");
  }, [currentLanguage, t]);


  //Mobile Menu State
  const [anchorEl,setAnchorEl] = useState<null|HTMLElement>(null);
  const handleMenuOpen = (event:React.MouseEvent<HTMLElement>)=> {
    setAnchorEl(event.currentTarget);
  };
  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  return (
    <Box 
    sx={{ flexGrow: 1, backgroundColor: "#C9E9EA" }}
    >
        <AppBar position="static" style={{ background: "#808080" }}>
        <Toolbar sx={{display:'flex',justifyContent:'space-between'}} variant="dense">
          <Typography sx={{ fontWeight: "bold", flex: 1, textAlign: "left" }}>
            Cognizant Solution eApp (MVP)
          </Typography>
          <IconButton color="inherit" onClick={handleMenuOpen}>
            <Translate/>
          </IconButton>
          <Menu
          anchorEl={anchorEl}
          open= {Boolean(anchorEl)}
          onClose={handleMenuClose}
          transformOrigin={{
            vertical:"top",
            horizontal:"right",
          }}
          >
            <MenuItem disabled>
              <Typography variant="subtitle1">{t("language")}</Typography>
            </MenuItem>
            {languages.map(({code,name}) => (
              <MenuItem
              key={code}
              onClick={()=>{
i18next.changeLanguage(code);
handleMenuClose();
              }}
              selected={currentLanguageCode === code}
              >
                {name}
              </MenuItem>
            ))}
          </Menu>
        </Toolbar>
      </AppBar>

      <Box 
      sx={{
        margin:"auto",
        maxWidth:1280,
        padding: {xs:"1rem", sm:"2rem"},
      }}
      >
          <BasicTabs />
          </Box>
    </Box>
  );
}
