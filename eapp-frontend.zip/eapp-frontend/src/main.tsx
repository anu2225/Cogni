import React, { Suspense } from 'react';
import ReactDOM from 'react-dom/client';
import i18next from 'i18next';
import { initReactI18next } from 'react-i18next';
import HttpApi from 'i18next-http-backend';
import LanguageDetector from 'i18next-browser-languagedetector';
import 'bootstrap/dist/js/bootstrap.js';
import 'bootstrap/dist/css/bootstrap.min.css';
import "./index.css";
import { RouterProvider, createBrowserRouter, Navigate } from 'react-router-dom';

// --- COMPONENT IMPORTS ---
import App from './App.jsx';
import SignIn from './Components/Auth/SignIn.js';
import SignUp from './Components/Auth/SignUp.js';
import BasicTabs from './Components/BasicTabs'; 
import Underwriting from './Components/underwriting/Underwriting';
import ApplicationPolicyList from './Components/application/ApplicationPolicyList.js';
import Application from './Components/application/Application.js';

// --- PLACEHOLDER COMPONENTS ---
// TODO:  (Replace these with real imports when files are created)
const Proofing = () => <div className="p-4"><h2>Proofing List / Details</h2></div>;
const Payment = () => <div className="p-4"><h2>Payment Gateway</h2></div>;
const Claims = () => <div className="p-4"><h2>Claims Processing</h2></div>;

// --- I18N CONFIGURATION ---
i18next
  .use(HttpApi)
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    supportedLngs: ['en', 'th'],
    fallbackLng: 'en',
    debug: false,
    detection: {
      order: ['path', 'cookie', 'htmlTag'],
      caches: ['cookie'],
    },
    backend: {
      loadPath: '/assets/locales/{{lng}}/translation.json',
    },
  });

// --- ROUTER CONFIGURATION ---
const router = createBrowserRouter([
  // 1. PUBLIC ROUTES
  {
    path: '/',
    element: <SignIn />
  },
  {
    path: '/signin',
    element: <SignIn />
  },
  {
    path: '/signup',
    element: <SignUp />
  },

  // 2. PROTECTED APP ROUTES (Wrapped in App Layout)
  {
    element: <App />, // This is your Sidebar/Header Layout
    children: [
      // A. Application (Form) - Requires ID
      {
        path: 'application',
        element: <Application/>
      },
      
      {
        path: 'application/:txnTypeId',
        element: <BasicTabs />
      },

      // B. Underwriting - Handles BOTH List and Details
      {
        path: 'underwriting', // No ID -> Component should show List
        element: <Underwriting />
      },
      {
        path: 'underwriting/:txnTypeId', // Has ID -> Component should show Details
        element: <Underwriting />
      },

      // C. Proofing - Handles BOTH List and Details
      {
        path: 'proofing', 
        element: <Proofing />
      },
      {
        path: 'proofing/:txnTypeId',
        element: <Proofing />
      },

      // D. Other Modules
      {
        path: 'payment',
        element: <Payment />
      },
      {
        path: 'payment/:txnTypeId',
        element: <Payment />
      },
      {
        path: 'claims',
        element: <Claims />
      },
      {
        path: 'claims/:txnTypeId',
        element: <Claims />
      }
    ]
  }
]);

const loadingMarkup = (
  <div className="py-4 text-center">
    <h3>Loading..</h3>
  </div>
);

ReactDOM.createRoot(document.getElementById('root')!).render(
  <Suspense fallback={loadingMarkup}>
    <React.StrictMode>
      <RouterProvider router={router} />
    </React.StrictMode>
  </Suspense>,
);