import React, { useEffect, useState } from "react";

import {
  AppBar,
  Box,
  Toolbar,
  Typography,
  IconButton,
  Menu,
  MenuItem,
  Grid,
  useMediaQuery,
  useTheme,
} from "@mui/material";

import { Translate, Menu as MenuIcon } from "@mui/icons-material";

import { useTranslation } from "react-i18next";

import i18next from "i18next";

import cookies from "js-cookie";

import BasicTabs from "./Components/BasicTabs";

import { useParams } from "react-router-dom";

import styled from "@emotion/styled";

// Global Styles to Prevent Horizontal Scroll

document.documentElement.style.overflowX = "hidden";

document.body.style.overflowX = "hidden";

const CustomAppBar = styled(AppBar)({
  backgroundColor: "#808080",
});

interface Language {
  code: string;

  name: string;

  country_code: string;

  dir: string;
}

const languages: Language[] = [
  { code: "en", name: "English", country_code: "gb", dir: "ltr" },

  { code: "th", name: "แบบไทย", country_code: "th", dir: "ltr" },
];

export default function App() {
  const currentLanguageCode = cookies.get("i18next") || "en";

  const currentLanguage = languages.find((l) => l.code === currentLanguageCode);

  const { t } = useTranslation();

  const params = useParams();

  const theme = useTheme();

  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));

  useEffect(() => {
    document.body.dir = currentLanguage?.dir || "ltr";

    document.title = t("app_title");
  }, [currentLanguage, t]);

  // Mobile Menu State

  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

  const handleMenuOpen = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  return (
    <Box
      sx={{
        flexGrow: 1,

        backgroundColor: "#C9E9EA",

        overflowX: "hidden", // Prevents horizontal scrolling

        width: "100vw", // Ensures it does not exceed the viewport width
      }}
    >
      {/* Responsive AppBar with Hamburger Menu */}
      <CustomAppBar position="static">
        <Toolbar sx={{ display: "flex", justifyContent: "space-between" }}>
          {isMobile && (
            <IconButton color="inherit">
              <MenuIcon /> {/* Hamburger Menu Icon */}
            </IconButton>
          )}
          <Typography
            variant={isMobile ? "h6" : "h5"}
            sx={{
              fontWeight: "bold",

              flex: 1,

              textAlign: "left",

              whiteSpace: "nowrap",

              overflow: "hidden",

              textOverflow: "ellipsis",
            }}
          >
            Cognizant Solution eApp (MVP)
          </Typography>
          <IconButton color="inherit" onClick={handleMenuOpen}>
            <Translate />
          </IconButton>

          {/* Language Menu */}
          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={handleMenuClose}
            transformOrigin={{ vertical: "top", horizontal: "right" }}
          >
            <MenuItem disabled>
              <Typography variant="subtitle1">{t("language")}</Typography>
            </MenuItem>

            {languages.map(({ code, name }) => (
              <MenuItem
                key={code}
                onClick={() => {
                  i18next.changeLanguage(code);

                  handleMenuClose();
                }}
                selected={currentLanguageCode === code}
              >
                {name}
              </MenuItem>
            ))}
          </Menu>
        </Toolbar>
      </CustomAppBar>

      {/* Responsive Layout */}
      <Grid
        container
        justifyContent="center"
        sx={{
          maxWidth: "100vw", // Prevents horizontal overflow

          margin: "auto",

          padding: { xs: "1rem", sm: "2rem" },

          overflowX: "hidden", // Ensures no extra width is added
        }}
      >
        <Grid item xs={12}>
          <BasicTabs />
        </Grid>
      </Grid>
    </Box>
  );
}
