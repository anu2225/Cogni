import React, { useState, useEffect } from 'react';
import { 
  Box, Paper, Typography, Grid, TextField, 
  Button, Stack, IconButton, CircularProgress, 
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  MenuItem, Select, FormControl, InputLabel, Chip, Divider,
  Dialog, DialogTitle, DialogContent, DialogActions, 
  FormControlLabel, RadioGroup, Radio, Checkbox, FormLabel
} from '@mui/material';
import { ArrowBack, Person, Assignment, LocalHospital, Assessment, Gavel, Close } from '@mui/icons-material';
import { useParams, useNavigate } from 'react-router-dom';
import axios from '../../api/axiosInterceptor';
import dayjs from 'dayjs';

// --- Interfaces ---
interface ApiRecord {
  quotation_id: string;
  screen_No: number;
  json_DATA: string;
  creation_TIME: string;
  version_NO: number;
}

interface UnderwritingCase {
  uwCode: string;
  creationDate: string;
  applicantName: string;
  serviceType: string;
  appNumber: string;
  policyNumber: string;
  agentCode: string;
  branch: string;
  productName: string;
  email: string;
  mobile: string;
  dob: string;
  gender: string;
  heightWeight: string; 
  occupation: string;
  income: string;
  sumAssured: string;
  premium: string;
  address: string;
  occLevelLife: string;
  occLevelAccident: string;
  occLevelHealth: string;
  tpdExposure: string;
  medicalReport: string;
}

// --- MODAL COMPONENT (Internal) ---
const DecisionModal = ({ open, onClose, caseData, onSubmit }: { open: boolean, onClose: () => void, caseData: UnderwritingCase | null, onSubmit: (data: any) => void }) => {
  const [emValue, setEmValue] = useState('0');
  const [perMille, setPerMille] = useState('0');
  const [uwDecision, setUwDecision] = useState('');
  const [reasonDesc, setReasonDesc] = useState('');
  const [icdCode, setIcdCode] = useState('');
  const [autoRenewal, setAutoRenewal] = useState('Yes');
  const [increaseRate, setIncreaseRate] = useState('0');
  const [consent, setConsent] = useState(true);

  if (!caseData) return null;

  const handleSubmit = () => {
    onSubmit({ uwDecision, reasonDesc, emValue, perMille, icdCode, autoRenewal, consent });
    onClose();
  };

  const SectionHeader = ({ title }: { title: string }) => (
    <Box sx={{ display: 'flex', alignItems: 'center', mb: 2, mt: 3, pb: 1, borderBottom: '1px solid #eee' }}>
      <Typography variant="subtitle1" fontWeight="bold" color="text.primary">{title}</Typography>
    </Box>
  );

  const InfoRow = ({ label, value }: { label: string, value: React.ReactNode }) => (
    <Grid item xs={12} sm={6} md={3}>
      <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 0.5, textTransform: 'uppercase', fontSize: '0.7rem' }}>{label}</Typography>
      <Typography variant="body2" fontWeight="500">{value}</Typography>
    </Grid>
  );

  // Helper to parse currency string
  const getRawPremium = (val: string) => Number(val.replace(/[^0-9.-]+/g,""));

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle sx={{ bgcolor: '#f5f5f5', borderBottom: '1px solid #ddd', pb: 2 }}>
        <Box display="flex" justifyContent="space-between" alignItems="center">
          <Typography variant="h6" fontWeight="bold">New Underwriting Decision</Typography>
          <IconButton onClick={onClose}><Close /></IconButton>
        </Box>
      </DialogTitle>

      <DialogContent dividers sx={{ p: 4 }}>
        {/* 1. Policy Info */}
        <SectionHeader title="Policy Information" />
        <Grid container spacing={2}>
          <InfoRow label="UW Code" value={caseData.uwCode} />
          <InfoRow label="Status" value="In Progress" />
          <InfoRow label="Product" value={caseData.productName} />
          <InfoRow label="Insured" value={caseData.applicantName} />
          <InfoRow label="Inception Date" value={caseData.creationDate} />
          <InfoRow label="Confirm Status" value={<Chip label="Pending" size="small" color="warning" />} />
        </Grid>

        <Divider sx={{ my: 3 }} />

        {/* 2. Target Info */}
        <SectionHeader title="Target & Premium Calculation" />
        <Grid container spacing={3}>
          <Grid item xs={12} sm={4}>
            <TextField label="Lay Sum Assured" fullWidth size="small" value={caseData.sumAssured} disabled />
          </Grid>
          <Grid item xs={12} sm={4}>
            <TextField label="Target Premium" fullWidth size="small" value={caseData.premium} disabled />
          </Grid>
          <Grid item xs={12} sm={4}>
            <TextField label="Premium Increase Rate (%)" fullWidth size="small" value={increaseRate} onChange={(e) => setIncreaseRate(e.target.value)} />
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth size="small">
              <InputLabel>EM (Extra Mortality)</InputLabel>
              <Select value={emValue} label="EM (Extra Mortality)" onChange={(e) => setEmValue(e.target.value)}>
                <MenuItem value="0">0% (Standard)</MenuItem>
                <MenuItem value="25">25%</MenuItem>
                <MenuItem value="50">50%</MenuItem>
                <MenuItem value="75">75%</MenuItem>
                <MenuItem value="100">100%</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth size="small">
              <InputLabel>Per Mille Loading</InputLabel>
              <Select value={perMille} label="Per Mille Loading" onChange={(e) => setPerMille(e.target.value)}>
                <MenuItem value="0">0</MenuItem>
                <MenuItem value="50">50</MenuItem>
                <MenuItem value="100">100</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12}>
            <Paper variant="outlined" sx={{ p: 2, bgcolor: '#f9f9f9', textAlign: 'center' }}>
              <Typography variant="caption" color="text.secondary">Total Premium Calculation Formula</Typography>
              <Typography variant="body1" fontFamily="monospace" fontWeight="bold">
                {getRawPremium(caseData.premium)} + (Base * {emValue}%) + ({perMille} * SA/1000)
              </Typography>
            </Paper>
          </Grid>
        </Grid>

        <Divider sx={{ my: 3 }} />

        {/* 3. Decision Section */}
        <SectionHeader title="Final Decision" />
        <Grid container spacing={3}>
          <Grid item xs={12} sm={6}>
            <TextField label="Current Underwriter" fullWidth size="small" value="UW-John Doe" disabled />
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth size="small">
              <InputLabel>Decision</InputLabel>
              <Select value={uwDecision} label="Decision" onChange={(e) => setUwDecision(e.target.value)}>
                <MenuItem value="Standard">Standard Case</MenuItem>
                <MenuItem value="Conditional">Conditional Acceptance</MenuItem>
                <MenuItem value="Postpone">Postpone</MenuItem>
                <MenuItem value="Decline">Decline</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
              <FormLabel component="legend" sx={{ fontSize: '0.8rem' }}>Auto-Renewal</FormLabel>
              <RadioGroup row value={autoRenewal} onChange={(e) => setAutoRenewal(e.target.value)}>
                <FormControlLabel value="Yes" control={<Radio size="small" />} label="Yes" />
                <FormControlLabel value="No" control={<Radio size="small" />} label="No" />
              </RadioGroup>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField label="ICD Code" fullWidth size="small" placeholder="If medical condition exists" value={icdCode} onChange={(e) => setIcdCode(e.target.value)} />
          </Grid>
          <Grid item xs={12}>
            <TextField
              label="Reason / Description" fullWidth multiline rows={3}
              required={uwDecision !== 'Standard'}
              placeholder="Mandatory if decision is not Standard..."
              value={reasonDesc} onChange={(e) => setReasonDesc(e.target.value)}
            />
          </Grid>
          <Grid item xs={12}>
            <FormControlLabel control={<Checkbox checked={consent} onChange={(e) => setConsent(e.target.checked)} />} label="I agree to the underwriting terms and confirm this decision." />
          </Grid>
        </Grid>
      </DialogContent>

      <DialogActions sx={{ p: 3, bgcolor: '#f5f5f5', borderTop: '1px solid #ddd', justifyContent: 'space-between' }}>
        <Stack direction="row" spacing={1}>
          <Button size="small" color="warning" variant="outlined">Increase Premium</Button>
          <Button size="small" color="warning" variant="outlined">Restrict SA</Button>
        </Stack>
        <Stack direction="row" spacing={2}>
          <Button onClick={onClose} color="inherit">Cancel</Button>
          <Button variant="contained" onClick={handleSubmit} disabled={!uwDecision || !consent}>Submit Decision</Button>
        </Stack>
      </DialogActions>
    </Dialog>
  );
};


// --- MAIN PAGE COMPONENT ---
const UnderwritingDetails: React.FC = () => {
  const { txnTypeId } = useParams();
  const navigate = useNavigate();
  
  const [loading, setLoading] = useState(true);
  const [caseData, setCaseData] = useState<UnderwritingCase | null>(null);
  
  // Controls Modal Visibility
  const [openModal, setOpenModal] = useState(false);

  // Quick Decision State (Bottom Panel)
  const [comments, setComments] = useState('');

  useEffect(() => {
    if (!txnTypeId) {
      setLoading(false);
      return;
    }

    const fetchData = async () => {
      setLoading(true);
      try {
        const response = await axios.get<ApiRecord[]>('http://localhost:8001/eapp/getAll');
        const allRecords = response.data;
        const matchingRecords = allRecords.filter(item => item.quotation_id === txnTypeId);

        if (matchingRecords.length === 0) {
            setCaseData(null);
            return;
        }

        const screens: { [key: number]: any } = {};
        let creationTime = '';

        matchingRecords.forEach(rec => {
            if (!creationTime || new Date(rec.creation_TIME) > new Date(creationTime)) {
                creationTime = rec.creation_TIME;
            }
            const currentStored = screens[rec.screen_No];
            if (!currentStored || rec.version_NO > currentStored.version_NO) {
                try {
                    const parsedData = typeof rec.json_DATA === 'string' ? JSON.parse(rec.json_DATA) : rec.json_DATA;
                    screens[rec.screen_No] = { ...rec, parsedData };
                } catch (e) {
                    console.error(`Error parsing JSON for Screen ${rec.screen_No}`, e);
                }
            }
        });

        const s1 = screens[1]?.parsedData || {};
        const s2 = screens[2]?.parsedData || {};
        const s3 = screens[3]?.parsedData || {};
        const s10 = screens[10]?.parsedData || {};

        const mapped: UnderwritingCase = {
          uwCode: `UW-${txnTypeId}`,
          creationDate: creationTime ? dayjs(creationTime).format('DD MMM YYYY') : '-',
          applicantName: `${s1.insuredFirstName || ''} ${s1.insuredSurName || ''}`.trim() || 'Unknown',
          serviceType: 'New Business',
          appNumber: txnTypeId,
          policyNumber: 'PENDING-001', 
          agentCode: 'AG-1029 (Direct)', 
          branch: 'Head Office',
          productName: s2.basicPlan || 'General Life Plan',
          email: s1.emailAddress || '-',
          mobile: s1.primaryNumber || s1.workPhoneNumber || '-',
          dob: s1.insuredDateOfBirth ? dayjs(s1.insuredDateOfBirth).format('DD/MM/YYYY') : '-',
          gender: s1.insuredGender || '-',
          heightWeight: 'N/A', 
          occupation: s1.occupationCode || s1.occupationDetail || 'N/A',
          income: s1.annualIncome ? `INR ${Number(s1.annualIncome).toLocaleString()}` : '-',
          sumAssured: s2.basicSumInsured ? `${Number(s2.basicSumInsured).toLocaleString()}` : '0',
          premium: (s10.annualPremium || s3.AmountOfPaymentWithThisApplication) ? `${Number(s10.annualPremium || s3.AmountOfPaymentWithThisApplication).toLocaleString()}` : '0',
          address: s1.regFullAddr || `${s1.regAddrNum || ''} ${s1.regAddrStrNum || ''} ${s1.regAddrProvince || ''}`.trim(),
          occLevelLife: 'Class 1',
          occLevelAccident: 'Class 1',
          occLevelHealth: 'Standard',
          tpdExposure: 'Low',
          medicalReport: 'Pending Review'
        };

        setCaseData(mapped);
      } catch (error) {
        console.error("Error fetching details", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [txnTypeId]);

  const handleDecisionSubmit = (data: any) => {
    console.log("Decision from Modal:", data);
    // api call to save the data..
  };

  // --- Render Helpers ---
  if (loading) return <Box sx={{ p: 5, textAlign: 'center' }}><CircularProgress /></Box>;
  if (!caseData) return <Box sx={{ p: 3 }}><Typography>No records found.</Typography><Button startIcon={<ArrowBack />} onClick={() => navigate('/underwriting')}>Back</Button></Box>;

  const SectionHeader = ({ title, icon }: { title: string, icon: React.ReactNode }) => (
    <Box sx={{ display: 'flex', alignItems: 'center', mb: 2, mt: 4, pb: 1, borderBottom: '1px solid #e0e0e0' }}>
      <Box sx={{ color: 'primary.main', mr: 1, display: 'flex' }}>{icon}</Box>
      <Typography variant="h6" fontWeight="bold" color="text.primary">{title}</Typography>
    </Box>
  );

  const InfoRow = ({ label, value }: { label: string, value: string | React.ReactNode }) => (
    <Grid item xs={12} sm={6} md={3}>
      <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 0.5, textTransform: 'uppercase', fontSize: '0.7rem', letterSpacing: '0.5px' }}>{label}</Typography>
      <Typography variant="body2" fontWeight="500">{value}</Typography>
    </Grid>
  );

  return (
    <Box sx={{ p: 3, maxWidth: 1400, margin: 'auto', backgroundColor: '#f4f6f8', minHeight: '100vh' }}>
      
      {/* Top Nav */}
      <Stack direction="row" alignItems="center" spacing={2} sx={{ mb: 3 }}>
        <IconButton onClick={() => navigate('/underwriting')} sx={{ bgcolor: 'white', border: '1px solid #ccc' }}><ArrowBack /></IconButton>
        <Box>
          <Typography variant="h5" fontWeight="bold" color="text.primary">Underwriting Details</Typography>
          <Typography variant="body2" color="text.secondary">Reviewing Application: {txnTypeId}</Typography>
        </Box>
      </Stack>

      {/* 1. Header Info */}
      <Paper elevation={0} sx={{ p: 3, borderRadius: 2, border: '1px solid #e0e0e0' }}>
        <Grid container spacing={3}>
          <InfoRow label="Underwriting Code" value={caseData.uwCode} />
          <InfoRow label="Creation Date" value={caseData.creationDate} />
          <InfoRow label="Applicant Name" value={caseData.applicantName} />
          <InfoRow label="Service Type" value={<Chip label={caseData.serviceType} color="primary" size="small" variant="outlined"/>} />
        </Grid>
      </Paper>

      {/* 2. Basic Info */}
      <SectionHeader title="Policy / Application Basic Info" icon={<Assignment />} />
      <Paper elevation={1} sx={{ p: 3, borderRadius: 2 }}>
        <Grid container spacing={3}>
          <InfoRow label="Application No." value={caseData.appNumber} />
          <InfoRow label="Policy No." value={caseData.policyNumber} />
          <InfoRow label="Agent Code" value={caseData.agentCode} />
          <InfoRow label="Branch" value={caseData.branch} />
          <InfoRow label="Product Name" value={caseData.productName} />
          <InfoRow label="Email" value={caseData.email} />
          <InfoRow label="Mobile" value={caseData.mobile} />
        </Grid>
      </Paper>

      {/* 3. Proposer Info */}
      <SectionHeader title="Proposer Information" icon={<Person />} />
      <Paper elevation={1} sx={{ p: 3, borderRadius: 2 }}>
        <Grid container spacing={3}>
          <InfoRow label="Full Name" value={caseData.applicantName} />
          <InfoRow label="DOB" value={caseData.dob} />
          <InfoRow label="Gender" value={caseData.gender} />
          <InfoRow label="Occupation" value={caseData.occupation} />
          <InfoRow label="Income" value={caseData.income} />
          <InfoRow label="Sum Assured" value={`INR ${caseData.sumAssured}`} />
          <InfoRow label="Premium" value={`INR ${caseData.premium}`} />
          <Grid item xs={12}>
            <Divider sx={{ my: 1 }} />
            <Typography variant="caption" color="text.secondary" sx={{ textTransform: 'uppercase', fontSize: '0.7rem' }}>Permanent Address</Typography>
            <Typography variant="body2">{caseData.address}</Typography>
          </Grid>
        </Grid>
      </Paper>

      {/* 4. Risk Assessment */}
      <SectionHeader title="Risk Assessment" icon={<LocalHospital />} />
      <Paper elevation={1} sx={{ p: 3, borderRadius: 2 }}>
        <Grid container spacing={3}>
          <InfoRow label="Life Occ. Level" value={<Chip label={caseData.occLevelLife} size="small" color="success" />} />
          <InfoRow label="Accident Occ. Level" value={<Chip label={caseData.occLevelAccident} size="small" color="success" />} />
          <InfoRow label="Health Occ. Level" value={<Chip label={caseData.occLevelHealth} size="small" color="info" />} />
          <InfoRow label="Medical Report" value={caseData.medicalReport} />
        </Grid>
      </Paper>

      {/* 5. Policy Table */}
      <SectionHeader title="Policy Details" icon={<Assessment />} />
      <TableContainer component={Paper} elevation={1} sx={{ borderRadius: 2 }}>
        <Table size="small">
          <TableHead sx={{ bgcolor: '#f5f5f5' }}>
            <TableRow>
              <TableCell><strong>Product Name</strong></TableCell>
              <TableCell><strong>Sum Assured</strong></TableCell>
              <TableCell><strong>Annual Premium</strong></TableCell>
              <TableCell><strong>UW Decision</strong></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            <TableRow>
              <TableCell>{caseData.productName}</TableCell>
              <TableCell>{caseData.sumAssured}</TableCell>
              <TableCell>{caseData.premium}</TableCell>
              <TableCell><Typography color="orange" fontWeight="bold">Pending</Typography></TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </TableContainer>

      {/* 6. Quick Action / Open Modal */}
      <SectionHeader title="Underwriting Action" icon={<Gavel />} />
      <Paper elevation={3} sx={{ p: 4, mb: 5, borderRadius: 2, borderLeft: '6px solid #1976d2' }}>
        <Grid container spacing={3}>
          <Grid item xs={12} md={8}>
            <TextField 
              fullWidth 
              label="Quick Comments / Notes" 
              multiline 
              rows={2} 
              placeholder="Enter internal remarks..."
              value={comments}
              onChange={(e) => setComments(e.target.value)}
            />
          </Grid>
          <Grid item xs={12} display="flex" justifyContent="flex-end" gap={2} mt={1}>
            <Button variant='outlined' size="large" onClick={() => setOpenModal(true)}>
              New Decision
            </Button>
            <Button variant='contained' size="large" onClick={() => {}}>
              Underwrittin
            </Button>
          </Grid>
        </Grid>
      </Paper>

      {/* --- INTEGRATED MODAL --- */}
      <DecisionModal 
        open={openModal} 
        onClose={() => setOpenModal(false)} 
        caseData={caseData} 
        onSubmit={handleDecisionSubmit}
      />

    </Box>
  );
};

export default UnderwritingDetails;