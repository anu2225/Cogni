import React, { useState } from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions,
  Box, Typography, IconButton, Grid, TextField,
  Button, Stack, FormControl, InputLabel, Select, MenuItem,
  Divider, Chip, FormControlLabel, RadioGroup, Radio, Checkbox, FormLabel, Paper
} from '@mui/material';
import { Close } from '@mui/icons-material';

// --- Interfaces ---
// (You might want to move this to a shared types.ts file)
export interface UnderwritingCase {
  uwCode: string;
  creationDate: string;
  applicantName: string;
  serviceType: string;
  productName: string;
  sumAssured: string;
  premium: string;
  // ... add other fields needed for the modal
}

interface DecisionModalProps {
  open: boolean;
  onClose: () => void;
  caseData: UnderwritingCase | null;
  onSubmit: (data: any) => void; // Callback to send data back to parent
}

const DecisionModal: React.FC<DecisionModalProps> = ({ open, onClose, caseData, onSubmit }) => {
  // --- Form State ---
  const [emValue, setEmValue] = useState('0');
  const [perMille, setPerMille] = useState('0');
  const [uwDecision, setUwDecision] = useState('');
  const [reasonDesc, setReasonDesc] = useState('');
  const [icdCode, setIcdCode] = useState('');
  const [autoRenewal, setAutoRenewal] = useState('Yes');
  const [increaseRate, setIncreaseRate] = useState('0');
  const [consent, setConsent] = useState(true);

  if (!caseData) return null;

  // --- Helper Components for Layout ---
  const SectionHeader = ({ title }: { title: string }) => (
    <Box sx={{ display: 'flex', alignItems: 'center', mb: 2, mt: 3, pb: 1, borderBottom: '1px solid #eee' }}>
      <Typography variant="subtitle1" fontWeight="bold" color="text.primary">
        {title}
      </Typography>
    </Box>
  );

  const InfoRow = ({ label, value }: { label: string, value: React.ReactNode }) => (
    <Grid item xs={12} sm={6} md={3}>
      <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 0.5, textTransform: 'uppercase', fontSize: '0.7rem' }}>
        {label}
      </Typography>
      <Typography variant="body2" fontWeight="500">{value}</Typography>
    </Grid>
  );

  const handleSubmit = () => {
    // Collect all form data and send to parent
    const decisionData = {
        uwDecision,
        reasonDesc,
        emValue,
        perMille,
        icdCode,
        autoRenewal,
        consent
    };
    onSubmit(decisionData);
    onClose();
  };

  // Helper to parse currency string to number for formula
  const getRawPremium = (val: string) => Number(val.replace(/[^0-9.-]+/g,""));

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle sx={{ bgcolor: '#f5f5f5', borderBottom: '1px solid #ddd', pb: 2 }}>
        <Box display="flex" justifyContent="space-between" alignItems="center">
          <Typography variant="h6" fontWeight="bold">New Underwriting Decision</Typography>
          <IconButton onClick={onClose}><Close /></IconButton>
        </Box>
      </DialogTitle>

      <DialogContent dividers sx={{ p: 4 }}>
        
        {/* 1. Policy Information Section */}
        <SectionHeader title="Policy Information" />
        <Grid container spacing={2} sx={{ mb: 3 }}>
          <InfoRow label="UW Code" value={caseData.uwCode} />
          <InfoRow label="Status" value="In Progress" />
          <InfoRow label="Product Name" value={caseData.productName} />
          <InfoRow label="Insured Name" value={caseData.applicantName} />
          <InfoRow label="Inception Date" value={caseData.creationDate} />
          <InfoRow label="Next Payment" value="-" />
          <InfoRow label="Confirm Status" value={<Chip label="Pending" size="small" color="warning" />} />
        </Grid>

        <Divider sx={{ my: 3 }} />

        {/* 2. Target Info Section */}
        <SectionHeader title="Target & Premium Calculation" />
        <Grid container spacing={3}>
          <Grid item xs={12} sm={4}>
            <TextField label="Lay Sum Assured" fullWidth size="small" value={caseData.sumAssured} disabled />
          </Grid>
          <Grid item xs={12} sm={4}>
            <TextField label="Target Premium" fullWidth size="small" value={caseData.premium} disabled />
          </Grid>
          <Grid item xs={12} sm={4}>
            <TextField 
                label="Premium Increase Rate (%)" 
                fullWidth size="small" 
                value={increaseRate} 
                onChange={(e) => setIncreaseRate(e.target.value)}
            />
          </Grid>

          {/* EM & Per Mille Selection */}
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth size="small">
              <InputLabel>EM (Extra Mortality)</InputLabel>
              <Select value={emValue} label="EM (Extra Mortality)" onChange={(e) => setEmValue(e.target.value)}>
                <MenuItem value="0">0% (Standard)</MenuItem>
                <MenuItem value="25">25%</MenuItem>
                <MenuItem value="50">50%</MenuItem>
                <MenuItem value="75">75%</MenuItem>
                <MenuItem value="100">100%</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth size="small">
              <InputLabel>Per Mille Loading</InputLabel>
              <Select value={perMille} label="Per Mille Loading" onChange={(e) => setPerMille(e.target.value)}>
                <MenuItem value="0">0</MenuItem>
                <MenuItem value="50">50</MenuItem>
                <MenuItem value="100">100</MenuItem>
              </Select>
            </FormControl>
          </Grid>

          {/* Formula Display */}
          <Grid item xs={12}>
            <Paper variant="outlined" sx={{ p: 2, bgcolor: '#f9f9f9', textAlign: 'center' }}>
              <Typography variant="caption" color="text.secondary">Total Premium Calculation Formula</Typography>
              <Typography variant="body1" fontFamily="monospace" fontWeight="bold">
                {getRawPremium(caseData.premium)} + (Base * {emValue}%) + ({perMille} * SA/1000)
              </Typography>
            </Paper>
          </Grid>
        </Grid>

        <Divider sx={{ my: 3 }} />

        {/* 3. Underwriting Decision Section */}
        <SectionHeader title="Final Decision" />
        <Grid container spacing={3}>
          <Grid item xs={12} sm={6}>
            <TextField label="Current Underwriter" fullWidth size="small" value="UW-John Doe" disabled />
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth size="small">
              <InputLabel>Decision</InputLabel>
              <Select value={uwDecision} label="Decision" onChange={(e) => setUwDecision(e.target.value)}>
                <MenuItem value="Standard">Standard Case</MenuItem>
                <MenuItem value="Conditional">Conditional Acceptance</MenuItem>
                <MenuItem value="Postpone">Postpone</MenuItem>
                <MenuItem value="Decline">Decline</MenuItem>
              </Select>
            </FormControl>
          </Grid>

          <Grid item xs={12} sm={6}>
            <FormControl component="fieldset">
              <FormLabel component="legend" sx={{ fontSize: '0.8rem' }}>Auto-Renewal</FormLabel>
              <RadioGroup row value={autoRenewal} onChange={(e) => setAutoRenewal(e.target.value)}>
                <FormControlLabel value="Yes" control={<Radio size="small" />} label="Yes" />
                <FormControlLabel value="No" control={<Radio size="small" />} label="No" />
              </RadioGroup>
            </FormControl>
          </Grid>

          <Grid item xs={12} sm={6}>
            <TextField 
                label="ICD Code" 
                fullWidth size="small" 
                placeholder="If medical condition exists" 
                value={icdCode} 
                onChange={(e) => setIcdCode(e.target.value)} 
            />
          </Grid>

          <Grid item xs={12}>
            <TextField
              label="Reason / Description"
              fullWidth
              multiline
              rows={3}
              required={uwDecision !== 'Standard'}
              placeholder="Mandatory if decision is not Standard..."
              value={reasonDesc}
              onChange={(e) => setReasonDesc(e.target.value)}
            />
          </Grid>

          <Grid item xs={12}>
            <FormControlLabel 
                control={<Checkbox checked={consent} onChange={(e) => setConsent(e.target.checked)} />} 
                label="I agree to the underwriting terms and confirm this decision." 
            />
          </Grid>
        </Grid>

      </DialogContent>

      <DialogActions sx={{ p: 3, bgcolor: '#f5f5f5', borderTop: '1px solid #ddd', justifyContent: 'space-between' }}>
        <Stack direction="row" spacing={1}>
          <Button size="small" color="warning" variant="outlined">Increase Premium</Button>
          <Button size="small" color="warning" variant="outlined">Restrict SA</Button>
        </Stack>
        <Stack direction="row" spacing={2}>
          <Button onClick={onClose} color="inherit">Cancel</Button>
          <Button variant="contained" onClick={handleSubmit} disabled={!uwDecision || !consent}>Submit Decision</Button>
        </Stack>
      </DialogActions>
    </Dialog>
  );
};

export default DecisionModal;