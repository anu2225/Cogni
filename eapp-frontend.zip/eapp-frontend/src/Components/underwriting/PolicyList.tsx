import React, { useState, useEffect } from 'react';
import { 
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow, 
  Paper, TextField, Box, TablePagination, Link as MuiLink, CircularProgress
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import axios from '../../api/axiosInterceptor';

export interface Policy {
  quoteId: string;
  policyholderName: string;
  type: string;
  premium: number;
  status: string;
  quoteSubmittedDate: string;
  version: number;
}

interface ApiResponse {
  quotation_id: string;
  creation_TIME: string;
  json_DATA: string;
  version_NO: number;
  screen_No: number; // Added Screen Number to Interface
}

const PolicyList: React.FC = () => {
  const navigate = useNavigate();
  
  const [policies, setPolicies] = useState<Policy[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  useEffect(() => {
    const fetchPolicies = async () => {
      try {
        const response = await axios.get<ApiResponse[]>('http://localhost:8001/eapp/getAll');
        const rawData = response.data;

        // --- LOGIC: Group Multiple Screens into One Policy ---
        const groupedMap = new Map<string, { 
            name: string, 
            date: string, 
            maxVersion: number 
        }>();

        rawData.forEach((item) => {
          const currentId = item.quotation_id;
          
          // 1. Initialize entry if it doesn't exist
          if (!groupedMap.has(currentId)) {
            groupedMap.set(currentId, { name: 'Unknown', date: '', maxVersion: 0 });
          }

          const entry = groupedMap.get(currentId)!;

          // 2. Track the latest Version Number
          if (item.version_NO > entry.maxVersion) {
            entry.maxVersion = item.version_NO;
          }

          // 3. Track the latest Activity Date
          if (!entry.date || new Date(item.creation_TIME) > new Date(entry.date)) {
            entry.date = item.creation_TIME;
          }

          // 4. Extract Name ONLY from Screen 1 (Life Assured Details)
          if (item.screen_No === 1) {
             try {
               const parsed = JSON.parse(item.json_DATA);
               if (parsed.insuredFirstName || parsed.insuredSurName) {
                 entry.name = `${parsed.insuredFirstName || ''} ${parsed.insuredSurName || ''}`.trim();
               }
             } catch (e) {
               console.error("Failed to parse Name for", currentId);
             }
          }
        });

        // 5. Convert Map to Array for Table
        const mappedData: Policy[] = Array.from(groupedMap.entries()).map(([id, data]) => {
          return {
            quoteId: id,
            policyholderName: data.name,
            quoteSubmittedDate: data.date ? data.date.split('T')[0] : '',
            version: data.maxVersion,
            type: "General Insurance",
            premium: 0,
            status: "Submitted"
          };
        });

        setPolicies(mappedData);
        setLoading(false); // Stop loading
      } catch (error) {
        console.error("Error fetching policies:", error);
        setLoading(false); // Stop loading even on error
      }
    };

    fetchPolicies();
  }, []);

  const handleOpenDetails = (quoteId: string) => {
    navigate(`/underwriting/${quoteId}`);
  };

  // ... Pagination Handlers ...
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => { setSearchQuery(e.target.value); setPage(0); };
  const handleChangePage = (_: unknown, newPage: number) => setPage(newPage);
  const handleChangeRowsPerPage = (e: React.ChangeEvent<HTMLInputElement>) => { setRowsPerPage(parseInt(e.target.value, 10)); setPage(0); };

  const filteredPolicies = policies.filter((policy) => {
    if (!searchQuery) return true;
    return (
      policy.quoteId.toLowerCase().includes(searchQuery.toLowerCase()) || 
      policy.policyholderName.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  const visiblePolicies = filteredPolicies.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  return (
    <div>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2, mt: 2 }}>
        <TextField label="Search ID or Name" variant="outlined" size="small" value={searchQuery} onChange={handleSearchChange} sx={{ width: '300px' }} />
      </Box>

      <TableContainer component={Paper} >
        <Table>
          <TableHead>
            <TableRow sx={{ backgroundColor: '#f5f5f5' }}>
              <TableCell><strong>Application ID</strong></TableCell>
              <TableCell><strong>Name</strong></TableCell>
              <TableCell><strong>Type</strong></TableCell>
              <TableCell><strong>Status</strong></TableCell>
              <TableCell><strong>Date</strong></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {loading ? (
               <TableRow>
                <TableCell colSpan={5} align="center" sx={{ py: 3 }}>
                  <CircularProgress size={24} /> <span style={{ marginLeft: 10 }}>Loading...</span>
                </TableCell>
              </TableRow>
            ) : visiblePolicies.length > 0 ? (
              visiblePolicies.map((policy) => (
                <TableRow key={policy.quoteId} hover>
                  <TableCell>
                    <MuiLink component="button" variant="body2" onClick={() => handleOpenDetails(policy.quoteId)}>
                        {policy.quoteId}
                    </MuiLink>
                  </TableCell>
                  <TableCell>{policy.policyholderName}</TableCell>
                  <TableCell>{policy.type}</TableCell>
                  <TableCell>{policy.status}</TableCell>
                  <TableCell>{policy.quoteSubmittedDate}</TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow><TableCell colSpan={5} align="center">No applications found.</TableCell></TableRow>
            )}
          </TableBody>
        </Table>
        <TablePagination rowsPerPageOptions={[5, 10, 25]} component="div" count={filteredPolicies.length} rowsPerPage={rowsPerPage} page={page} onPageChange={handleChangePage} onRowsPerPageChange={handleChangeRowsPerPage} />
      </TableContainer>
    </div>
  );
};

export default PolicyList;