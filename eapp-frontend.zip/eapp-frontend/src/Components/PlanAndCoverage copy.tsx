import {
  Box,
  Divider,
  Link,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
  tableCellClasses,
} from "@mui/material";
import React, { useEffect } from "react";
import { useTranslation } from "react-i18next";
interface ChildComponentProps {
  fields: {
    basicPlan: string;
    basicSumInsured: string;
    basicPlanPremium: string;
    typeOfDivident: string;
    insuranceTerm: string;
    ppt: string;
  };
  setFields: React.Dispatch<
    React.SetStateAction<{
      basicPlan: string;
      basicSumInsured: string;
      basicPlanPremium: string;
      typeOfDivident: string;
      insuranceTerm: string;
      ppt: string;
    }>
  >;
  savedQuotation: any;
  savedTransaction: any;
}



const camelToNormal = (text: string) => {
  return text.replace(/([A-Z])/g, ' $1').replace(/^./, function (str) { return str.toUpperCase(); });
};
const PlanAndCoverage: React.FC<ChildComponentProps> = ({
  fields,
  setFields,
  savedQuotation,
  savedTransaction,
}) => {
  let jsonData;
  let headers: any[] = [];
  let OptRiderData;
  let OptHeaders: any[] = [];
  const handleFieldChange = (val: string, fieldName: string) => {
    setFields({ ...fields, [fieldName]: val });
    // setFields({ ...newFields })
    console.log("After ==>", fields);
  };

  const { t } = useTranslation();

  useEffect(() => {
    if (savedTransaction && savedTransaction.length > 0) {
      const baseSA = savedTransaction[0]?.txn_input_json?.Base_SA;
      const plan = savedTransaction[0]?.txn_input_json?.Plan;
      const term = savedTransaction[0]?.txn_input_json["SSPP.Policy_Term"];
      const ppt = savedTransaction[0]?.txn_input_json?.PPT;
      setFields((prevFields) => ({
        ...prevFields,
        basicPlanPremium: savedTransaction[0]?.txn_output_json?.outputs?.PremiumSummary[1]?.basePlan,
        basicSumInsured: baseSA,
        basicPlan: plan,
        insuranceTerm: term,
        ppt: ppt,
        typeOfDivident: "Non - Participatory"
      }));
    }
   
  }, [savedTransaction]);

  // if (savedTransaction !== null && savedTransaction !== undefined) {
      if (savedTransaction  && typeof savedTransaction === "object" && Object.keys(savedTransaction).length !== 0) {
          console.log(savedTransaction);
          jsonData = savedTransaction[0]?.txn_output_json?.outputs?.RiderDetails;
          if( savedTransaction[0]?.txn_output_json?.outputs?.RiderDetails[0] &&  savedTransaction[0]?.txn_output_json?.outputs?.RiderDetails[0].length !==0){
              headers = Object.keys(
                savedTransaction[0]?.txn_output_json?.outputs?.RiderDetails[0]
              );
            }
          // console.log(headers);
          OptRiderData = savedTransaction[0]?.txn_output_json?.outputs?.OptionalBenefitDetails;
          if(savedTransaction[0]?.txn_output_json?.outputs?.OptionalBenefitDetails[0] && savedTransaction[0]?.txn_output_json?.outputs?.OptionalBenefitDetails[0].length !==0){
              OptHeaders = Object.keys(
                  savedTransaction[0]?.txn_output_json?.outputs?.OptionalBenefitDetails[0]
                );
          }
        }
  return (
    <Box>
      <Paper elevation={3} sx={{ margin: 2 }}>
        <Box sx={{ padding: 2 }}>
          <Typography className="typography-main-header">
            {t("quotation_summaryh")}
          </Typography>
          <Divider />
          <Box sx={{ display: "flex", flexDirection: "row", marginTop: 2 }}>
            <Typography>{t("quotation_summary")}&emsp;</Typography>
            <Link
              underline="always"
              color="inherit"
              sx={{ color: "#000048" }}
              onClick={() => {
                const file = new Blob(
                  [
                    Uint8Array.from(atob(savedQuotation.txn_pdf), (c) =>
                      c.charCodeAt(0)
                    ),
                  ],
                  { type: "application/pdf" }
                );
                //Build a URL from the file
                const fileURL = URL.createObjectURL(file);
                //Open the URL on new Window
                window.open(fileURL);
                return true;
                4;
              }}
            >
              Download Link to Quotation
            </Link>
          </Box>
        </Box>
      </Paper>
      <Paper elevation={3} sx={{ margin: 2 }}>
        <Box sx={{ padding: 2 }}>
          <Typography className="typography-main-header">
            {t("main_plan")}
          </Typography>
          <Divider />
          <Box sx={{ marginTop: 2 }}>
            <TableContainer>
              <Table
                className="table-main"
                aria-label="simple table"
              >
                <TableBody>
                  <TableRow>
                    {/* <TableCell>{t("basic_plan")}</TableCell>{" "} */}
                    <TableCell>
                      <Box>
                        <TextField
                          id="basic_plan"
                          label={t("basic_plan")}
                          size="small"
                          variant="standard"
                          InputProps={{ readOnly: true }}
                          value={fields.basicPlan}
                          onChange={(e) => handleFieldChange(e.target.value, "basicPlan")}></TextField>
                        {/* {plan} */}
                      </Box>
                    </TableCell>
                    <TableCell>
                      <TextField
                        size="small"
                        label={t("basic_sum_insured")}
                        variant="standard"
                        type="number"
                        InputProps={{ readOnly: true }}
                        value={fields.basicSumInsured}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "basicSumInsured")
                        } />
                      {/* {baseSA} */}
                    </TableCell>
                    <TableCell>
                      <TextField
                        size="small"
                        label={t("basic_plan_premium")}
                        variant="standard"
                        id="outlined-disabled"
                        InputProps={{ readOnly: true }}
                        value={fields.basicPlanPremium}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "basicPlanPremium")
                        }
                      />
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    {/* <TableCell>{t("type_of_dividend")}</TableCell> */}
                    <TableCell>
                      <Box>
                        <TextField
                          id="type_of_dividend"
                          size="small"
                          label={t("type_of_dividend")}
                          variant="standard"
                          InputProps={{ readOnly: true }}
                          value={fields.typeOfDivident}
                          onChange={(e) => handleFieldChange(e.target.value, "typeOfDivident")}
                        >
                        </TextField>
                      </Box>
                    </TableCell>
                    <TableCell>
                      <Box>
                        <TextField
                          id="type_of_dividend"
                          size="small"
                          label={t("term_of_insurance")}
                          InputProps={{ readOnly: true }}
                          variant="standard"
                          value={fields.insuranceTerm}
                          onChange={(e) =>
                            handleFieldChange(e.target.value, "insuranceTerm")
                          }
                        ></TextField>
                      </Box>
                    </TableCell>
                    <TableCell>
                      <Box>
                        <TextField
                          id="type_of_dividend"
                          size="small"
                          label={t("term_of_premium_payment")}
                          InputProps={{ readOnly: true }}
                          variant="standard"
                          value={fields.ppt}
                          onChange={(e) => handleFieldChange(e.target.value, "ppt")}
                        ></TextField>
                      </Box>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        </Box>
      </Paper>


      <Paper elevation={3} sx={{ margin: 2 }}>
        <Box sx={{ padding: 2 }}>
          <Typography className="typography-main-header">
            {t("riders")}
          </Typography>
          <Divider />
          <Box sx={{ marginTop: 2 }}>
            <TableContainer>
             
              <Table
                className="table-main"
                aria-label="simple table"
              >
                <TableHead>
                  <TableRow>
                    {headers?.map((header) => (
                      <TableCell key={header}>{camelToNormal(header)}</TableCell>
                    ))}

                  </TableRow>
                </TableHead>
                <TableBody>
                  {jsonData?.map(
                    (
                      row: {
                        [x: string]:
                        | string
                        | number
                        | boolean
                        | React.ReactElement<
                          any,
                          string | React.JSXElementConstructor<any>
                        >
                        | Iterable<React.ReactNode>
                        | React.ReactPortal
                        | null
                        | undefined;
                      },
                      rowIndex: React.Key | null | undefined
                    ) => (
                      <TableRow key={rowIndex}>
                        {headers?.map((header) => (
                          <TableCell key={header}>{row[header]}</TableCell>
                        ))}
                      </TableRow>
                    )
                  )}
                </TableBody>
              </Table>
           
            </TableContainer>
          </Box>
        </Box>
      </Paper>

      <Paper elevation={3} sx={{ margin: 2 }}>
        <Box sx={{ padding: 2 }}>
          <Typography className="typography-main-header">
            {t("optional_benefits")}
            {/* Translation Required */}
          </Typography>
          <Divider />
          <Box sx={{ marginTop: 2 }}>
            <TableContainer>
           
              <Table
                className="table-main"
                aria-label="simple table"
              >
                <TableHead>
                  <TableRow>
                    {OptHeaders?.map((header) => (
                      <TableCell key={header}>{camelToNormal(header)}</TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {OptRiderData?.map(
                    (
                      row: {
                        [x: string]:
                        | string
                        | number
                        | boolean
                        | React.ReactElement<
                          any,
                          string | React.JSXElementConstructor<any>
                        >
                        | Iterable<React.ReactNode>
                        | React.ReactPortal
                        | null
                        | undefined;
                      },
                      rowIndex: React.Key | null | undefined
                    ) => (
                      <TableRow key={rowIndex}>
                        {OptHeaders?.map((header) => (
                          <TableCell key={header}>{row[header]}</TableCell>
                        ))}
                      </TableRow>
                    )
                  )}
                </TableBody>
              </Table>
             
            </TableContainer>
          </Box>
        </Box>
      </Paper>
    </Box>
  );
};

export default PlanAndCoverage;

