import {
  Box,
  Divider,
  Link,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from "@mui/material";

import React, { useEffect } from "react";

import { useTranslation } from "react-i18next";

interface ChildComponentProps {
  fields: {
    basicPlan: string;

    basicSumInsured: string;

    basicPlanPremium: string;

    typeOfDivident: string;

    insuranceTerm: string;

    ppt: string;
  };

  setFields: React.Dispatch<
    React.SetStateAction<{
      basicPlan: string;

      basicSumInsured: string;

      basicPlanPremium: string;

      typeOfDivident: string;

      insuranceTerm: string;

      ppt: string;
    }>
  >;

  savedQuotation: any;

  savedTransaction: any;
}

const camelToNormal = (text: string) => {
  return text
    .replace(/([A-Z])/g, " $1")
    .replace(/^./, (str) => str.toUpperCase());
};

const PlanAndCoverage: React.FC<ChildComponentProps> = ({
  fields,

  setFields,

  savedQuotation,

  savedTransaction,
}) => {
  let jsonData;

  let headers: any[] = [];

  let OptRiderData;

  let OptHeaders: any[] = [];

  const handleFieldChange = (val: string, fieldName: string) => {
    setFields({ ...fields, [fieldName]: val });
  };

  const { t } = useTranslation();

  useEffect(() => {
    if (savedTransaction && savedTransaction.length > 0) {
      const baseSA = savedTransaction[0]?.txn_input_json?.Base_SA;

      const plan = savedTransaction[0]?.txn_input_json?.Plan;

      const term = savedTransaction[0]?.txn_input_json["SSPP.Policy_Term"];

      const ppt = savedTransaction[0]?.txn_input_json?.PPT;

      setFields((prevFields) => ({
        ...prevFields,

        basicPlanPremium:
          savedTransaction[0]?.txn_output_json?.outputs?.PremiumSummary[1]
            ?.basePlan,

        basicSumInsured: baseSA,

        basicPlan: plan,

        insuranceTerm: term,

        ppt: ppt,

        typeOfDivident: "Non - Participatory",
      }));
    }
  }, [savedTransaction]);

  if (
    savedTransaction &&
    typeof savedTransaction === "object" &&
    Object.keys(savedTransaction).length !== 0
  ) {
    jsonData = savedTransaction[0]?.txn_output_json?.outputs?.RiderDetails;

    if (jsonData?.length) {
      headers = Object.keys(jsonData[0]);
    }

    OptRiderData =
      savedTransaction[0]?.txn_output_json?.outputs?.OptionalBenefitDetails;

    if (OptRiderData?.length) {
      OptHeaders = Object.keys(OptRiderData[0]);
    }
  }

  return (
    <Box sx={{ width: "100%", padding: 2 }}>
      {/* Quotation Summary */}
      <Paper elevation={3} sx={{ marginBottom: 2, padding: 2 }}>
        <Typography className="typography-main-header">
          {t("quotation_summaryh")}
        </Typography>
        <Divider />
        <Box
          sx={{
            display: "flex",
            flexDirection: { xs: "column", sm: "row" },
            marginTop: 2,
          }}
        >
          <Typography>{t("quotation_summary")}&emsp;</Typography>
          <Link
            underline="always"
            color="inherit"
            sx={{ color: "#000048" }}
            onClick={() => {
              const file = new Blob(
                [
                  Uint8Array.from(atob(savedQuotation.txn_pdf), (c) =>
                    c.charCodeAt(0)
                  ),
                ],
                {
                  type: "application/pdf",
                }
              );

              const fileURL = URL.createObjectURL(file);

              window.open(fileURL);
            }}
          >
            Download Link to Quotation
          </Link>
        </Box>
      </Paper>

      {/* Main Plan */}
      <Paper elevation={3} sx={{ marginBottom: 2, padding: 2 }}>
        <Typography className="typography-main-header">
          {t("main_plan")}
        </Typography>
        <Divider />
        <Box sx={{ marginTop: 2 }}>
          <TableContainer sx={{ width: "100%" }}>
            <Table className="table-main" sx={{ width: "100%" }} >
              <TableBody>
                {[
                  ["basicPlan", "basicSumInsured", "basicPlanPremium","typeOfDivident","insuranceTerm", "ppt"]
                ].map((row, rowIndex) => (
                  <TableRow
                    key={rowIndex}
                    sx={{ display: "flex", flexWrap: "wrap" }}
                  >
                    {row.map((field) => (
                      <TableCell
                        key={field}
                        sx={{ flex: "1 1 30%", minWidth: "120px" }}
                      >
                        <TextField
                          // fullWidth
                          size="small"
                          label={t(field)}
                          variant="standard"
                          InputProps={{ readOnly: true }}
                          value={fields[field as keyof typeof fields]}
                          onChange={(e) =>
                            handleFieldChange(e.target.value, field)
                          }
                        />
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      </Paper>

      {/* Riders */}
      <Paper elevation={3} sx={{ marginBottom: 2, padding: 2 }}>
        <Typography className="typography-main-header">
          {t("riders")}
        </Typography>
        <Divider />
        <Box sx={{ marginTop: 2 }}>
          <TableContainer sx={{ width: "100%" }}>
            <Table sx={{ width: "100%" }}>
              <TableHead>
                <TableRow>
                  {headers?.map((header) => (
                    <TableCell key={header}>{camelToNormal(header)}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {jsonData?.map((row: any, rowIndex: number) => (
                  <TableRow key={rowIndex}>
                    {headers?.map((header) => (
                      <TableCell key={header}>{row[header]}</TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      </Paper>

      {/* Optional Benefits */}
      <Paper elevation={3} sx={{ marginBottom: 2, padding: 2 }}>
        <Typography className="typography-main-header">
          {t("optional_benefits")}
        </Typography>
        <Divider />
        <Box sx={{ marginTop: 2 }}>
          <TableContainer sx={{ width: "100%" }}>
            <Table sx={{ width: "100%" }}>
              <TableHead>
                <TableRow>
                  {OptHeaders?.map((header) => (
                    <TableCell key={header}>{camelToNormal(header)}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {OptRiderData?.map((row: any, rowIndex: number) => (
                  <TableRow key={rowIndex}>
                    {OptHeaders?.map((header) => (
                      <TableCell key={header}>{row[header]}</TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      </Paper>
    </Box>
  );
};

export default PlanAndCoverage;
