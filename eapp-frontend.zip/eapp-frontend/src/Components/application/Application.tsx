import { Paper, Typography } from '@mui/material'
import ApplicationPolicyList from './ApplicationPolicyList'

const Application = () => {
  return (
    <Paper sx={{ p: 3, height: '100%' }}>
      <Typography variant="h5" gutterBottom>
        Application Data Sharing Pool
      </Typography>
      <ApplicationPolicyList />
    </Paper>
  )
}

export default Application
