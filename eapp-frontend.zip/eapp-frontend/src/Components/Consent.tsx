import * as React from "react";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Divider from "@mui/material/Divider";
import Button from "@mui/material/Button";
import {
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableRow,
  ToggleButton,
  ToggleButtonGroup,
  Typography,
  tableCellClasses,
  useMediaQuery,
  useTheme,
} from "@mui/material";
import FormControlLabel from "@mui/material/FormControlLabel";
import { useTranslation } from "react-i18next";
import Checkbox from "@mui/material/Checkbox";
import ReactSignatureCanvas from "react-signature-canvas";
import styled from "@emotion/styled";
import "../styles.css"


// const StyledButton = styled(Button)({
//   backgroundColor: "#000048",
//   color: "#ffffff",
//   "&:hover": {
//     backgroundColor: "#000036",
//   },
// });

interface ChildComponentProps {
  fields: {
    checkBoxConsent: boolean;
    parentSignURL: string;
    laSignURL: string;
    custLangPrefOptn: string;
    infoDisclosureConsent: string;
  };
  setFields: React.Dispatch<
    React.SetStateAction<{
      checkBoxConsent: boolean;
      parentSignURL: string;
      laSignURL: string;
      custLangPrefOptn: string;
      infoDisclosureConsent: string;
    }>
  >;
}

const Consent: React.FC<ChildComponentProps> = ({ fields, setFields }) => {
  const handleChange = (value: boolean, fieldName: any) => {
    // const value = event.target.checked
    console.log("Bool value ==> ", value);

    setFields((prevFields) => ({
      ...prevFields,
      [fieldName]: value,
    }));
  };

  const handleButtonChange = (
    event: React.MouseEvent<HTMLElement>,
    fieldName: string
  ) => {
    console.log(event.currentTarget.textContent);
    const stateVal = event.currentTarget.textContent;
    setFields((fields) => ({ ...fields, [fieldName]: stateVal }));
  };

  const { t } = useTranslation();

  const theme = useTheme();
  const isSmallScreen = useMediaQuery(theme.breakpoints.down("sm"));

  const signatureRefParent = React.useRef<any>(null);
  const signatureRefla = React.useRef<any>(null);

  const clearSignatureParent = () => {
    if (signatureRefParent.current) {
      signatureRefParent.current.clear();
    }
  };

  const clearSignaturela = () => {
    if (signatureRefla.current) {
      signatureRefla.current.clear();
    }
  };

  const getParentSignatureImage = () => {
    if (signatureRefParent.current) {
      const parentSignURL = signatureRefParent.current.toDataURL();
      console.log("Sign is==> ", parentSignURL);
      setFields({
        ...fields,
        parentSignURL: parentSignURL,
      });
      // fields.parentSignURL = parentSignURL;
      return parentSignURL;
    }
    return null;
  };

  const getLifeAssuredSignatureImage = () => {
    if (signatureRefla.current) {
      const lasignURL = signatureRefla.current.toDataURL();
      console.log("Sign is==> ", lasignURL);
      setFields({
        ...fields,
        laSignURL: lasignURL,
      });
      fields.laSignURL = lasignURL;
      return lasignURL;
    }
    return null;
  };
  return (
    <Box>
      <Paper elevation={3} sx={{ margin: 2 }}>
        <Box sx={{ padding: 2 }}>
          <Typography className="typography-main-header">
            {t("consent_declaration_and_authorization")}
          </Typography>
          <Divider />
        </Box>
        <Box sx={{ padding: 2 }}>
          <FormControlLabel
            control={
              <Checkbox
                checked={fields.checkBoxConsent}
                onChange={(e) =>
                  handleChange(e.target.checked, "checkBoxConsent")
                }
                inputProps={{ "aria-label": "controlled" }}
              />
            }
            label={t("i_hereby")}
          />
          <Typography>{t("message")}</Typography>
          <Divider />
        </Box>
        <TableContainer>
          <Table
            className="table-main"
          >
            <TableBody>
              <TableRow>
                <TableCell sx={{ fontSize: isSmallScreen ? "0.8rem" : "1rem" }}>
                  {t("parent_sign")}
                </TableCell>
                <TableCell>
                  <div
                    style={{ border: "2px solid #000048", borderRadius: "5px",width:isSmallScreen?"100%": "700px", }}
                  >
                    <ReactSignatureCanvas
                      penColor="black"
                      canvasProps={{
                        width: isSmallScreen ? 300 : 700,
                        height: 200,
                        className: "signatureCanvas",
                      }}
                      ref={signatureRefParent}
                    />
                  </div>
                  <Stack
                    direction={isSmallScreen? "column" : "row"}
                    spacing={1}
                    justifyContent={"flex-end"}
                    marginTop={1}
                  >
                    <Button
                    className="styled-button"
                      color="primary"
                      variant="contained"
                      onClick={clearSignatureParent}
                    >
                      {" "}
                      Clear{" "}
                    </Button>
                    <Button
                    className="styled-button"
                      color="primary"
                      variant="contained"
                      onClick={getParentSignatureImage}
                    >
                      Get Signature
                    </Button>
                  </Stack>
                </TableCell>
              </TableRow>
              {fields.parentSignURL !== "" && (
                <TableRow>
                  <TableCell sx={{fontSize: isSmallScreen ? "0.8rem" : "1rem"}} >{t("signature_for_display")}</TableCell>
                  <TableCell>
                    <img src={fields.parentSignURL} alt={"signURL"} />
                  </TableCell>
                </TableRow>
              )}
              <TableRow>
                <TableCell sx={{fontSize: isSmallScreen ? "0.8rem" : "1rem"}} >{t("sign_of_life_assured")}</TableCell>
                <TableCell>
                  <div
                    style={{ border: "2px solid #000048", borderRadius: "5px",width:isSmallScreen?"100%": "700px", }}
                  >
                    <ReactSignatureCanvas
                      penColor="black"
                      canvasProps={{
                        width: isSmallScreen ? 300 : 700,
                        height: 200,
                        className: "signatureCanvas",
                      }}
                      ref={signatureRefla}
                    />
                  </div>
                  <Stack
                    direction= {isSmallScreen? "column" : "row"}
                    spacing={1}
                    justifyContent={"flex-end"}
                    marginTop={1}
                  >
                    <Button
                    className="styled-button"
                      color="primary"
                      variant="contained"
                      onClick={clearSignaturela}
                    >
                      {" "}
                      Clear{" "}
                    </Button>
                    <Button
                    className="styled-button"
                      color="primary"
                      variant="contained"
                      onClick={getLifeAssuredSignatureImage}
                    >
                      Get Signature
                    </Button>
                  </Stack>
                </TableCell>
              </TableRow>
              {fields.laSignURL !== "" && (
                <TableRow>
                  <TableCell sx={{fontSize: isSmallScreen ? "0.8rem" : "1rem"}} >{t("signature_for_display")}</TableCell>
                  <TableCell>
                    <img src={fields.laSignURL} alt={"signURL"} />
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      <Paper elevation={3} sx={{ margin: 2 }}>
        <Box>
          <Typography className="typography-main-header" padding={2}>
            {t("tax_consent")}
          </Typography>
          <Divider />
          <TableContainer>
            <Table
              className="table-main"
            >
              <TableBody>
                <TableRow>
                  <TableCell>{t("consent_to_disclose_info_to_rd")}</TableCell>
                  <TableCell>
                    <ToggleButtonGroup
                      color="primary"
                      value={fields.infoDisclosureConsent}
                      exclusive
                      fullWidth
                      onChange={(event) =>
                        handleButtonChange(event, "infoDisclosureConsent")
                      }
                      aria-label="Platform"
                    >
                      <ToggleButton value="Yes">Yes</ToggleButton>
                      <ToggleButton value="No">No</ToggleButton>
                    </ToggleButtonGroup>
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      </Paper>

      <Paper elevation={3} sx={{ margin: 2 }}>
        <Box>
          <Typography className="typography-main-header" padding={2}>
            {t("delivery_option")}
          </Typography>
          <Divider />
          <TableContainer>
            <Table
              className="table-main"
            >
              <TableBody>
                <TableRow>
                  <TableCell>{t("customer_language_preference")}</TableCell>
                  <TableCell>
                    <ToggleButtonGroup
                      color="primary"
                      value={fields.custLangPrefOptn}
                      exclusive
                      fullWidth
                      onChange={(event) =>
                        handleButtonChange(event, "custLangPrefOptn")
                      }
                      aria-label="Platform"
                    >
                      <ToggleButton value="Thai">Thai</ToggleButton>
                      <ToggleButton value="English">English</ToggleButton>
                    </ToggleButtonGroup>
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>{t("select_button")}</TableCell>
                  <TableCell>
                    <ToggleButtonGroup
                      color="primary"
                      value={fields.custLangPrefOptn}
                      exclusive
                      fullWidth
                      onChange={(event) =>
                        handleButtonChange(event, "custLangPrefOptn")
                      }
                      aria-label="Platform"
                    >
                      <ToggleButton value="Electronic format delivered by email">
                        Electronic format delivered by email
                      </ToggleButton>
                      <ToggleButton value="Hard copy format delivered by post">
                        Hard copy format delivered by post
                      </ToggleButton>
                    </ToggleButtonGroup>
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      </Paper>
    </Box>
  );
};

export default Consent;
