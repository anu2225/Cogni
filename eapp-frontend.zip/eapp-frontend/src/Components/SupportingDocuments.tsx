import styled from "@emotion/styled";
import {UploadFile } from "@mui/icons-material";
import {
  Box,
  Button,
  Divider,
  Link,
  Paper,
  Table,
  TableBody,
  TableCell,
  tableCellClasses,
  TableContainer,
  TableRow,
  Typography,
} from "@mui/material";
import { useTranslation } from "react-i18next";

const StyledButton = styled(Button)({
  backgroundColor: '#000048',
  color:'#ffffff',
  '&:hover':{
      backgroundColor:'#000036',
  }
})

interface ChildComponentProps {
  fields: {
    evidenceDocument: any;
    medicalExamDocument:any;

  };
  setFields: React.Dispatch<
    React.SetStateAction<{
      evidenceDocument: any;
      medicalExamDocument:any;

    }>
  >;
}

const SupportingDocuments: React.FC<ChildComponentProps> = ({
  fields,
  setFields,
}) => {
  const { t } = useTranslation();

  const handleFieldChange = (val: any, fieldName: string) => {
    const newFields = { ...fields, [fieldName]: val };
    setFields({ ...newFields });
    console.log("After ==>", newFields);
  };

  const setFiles = async (e: any,name:string) => {
    const file = e.target.files[0];
    // we need to get the raw bytes
    const buffer = await file.arrayBuffer();
    // each entry of array should contain 8 bits
    const bytes = new Uint8Array(buffer);
    handleFieldChange(bytes, name);
  };

  return (
    <Box>
      <Paper elevation={3} sx={{ margin: 2 }}>
        <Box sx={{ padding: 2 }}>
          <Typography sx={{ color: "#000048", fontWeight: "bold" }}>
            {t("supporting_documents")}
          </Typography>
          <Divider />
          <TableContainer>
            <Table
              className="table-main"
              aria-label="table2"
            >
              <TableBody>
                <TableRow>
                  <TableCell>{t("insured_evidence_of_proof")}</TableCell>
                  <TableCell>
                    <Button variant="outlined" component="label" startIcon={<UploadFile/>}>
                      Upload File
                    <input
                      name="evidenceDocument"
                      type="file"
                      hidden
                      onInput={(e) => setFiles(e,'evidenceDocument')}
                    />
                    </Button>
                  </TableCell>
                  {fields.evidenceDocument !== "" && (<TableCell>
                    <Link
                      onClick={() => {
                        var blob = new Blob(
                          [
                            new Uint8Array(
                              Object.keys(fields.evidenceDocument).map(
                                (key) => fields.evidenceDocument[key]
                              )
                            ),
                          ],
                          { type: "application/pdf" }
                        );
                        var url = URL.createObjectURL(blob);
                        window.open(url);
                      }}
                      underline="always"
                      color="inherit"
                      sx={{ color: "purple" }}
                    >
                      View File
                    </Link>
                  </TableCell>)}
                </TableRow>
                <TableRow>
                  <TableCell>{t("medical_exam_request")}</TableCell>
                  <TableCell>
                    <Button variant="outlined" component="label" startIcon={<UploadFile/>}>
                      Upload File
                    <input
                      name="medicalExamDocument"
                      type="file"
                      hidden
                      onInput={(e) => setFiles(e,'medicalExamDocument')}
                    />
                    </Button>
                  </TableCell>
                  {fields.medicalExamDocument !== "" && (<TableCell>
                    <Link
                      onClick={() => {
                        var blob = new Blob(
                          [
                            new Uint8Array(
                              Object.keys(fields.medicalExamDocument).map(
                                (key) => fields.medicalExamDocument[key]
                              )
                            ),
                          ],
                          { type: "application/pdf" }
                        );
                        var url = URL.createObjectURL(blob);
                        window.open(url);
                      }}
                      underline="always"
                      color="inherit"
                      sx={{ color: "purple" }}
                    >
                      View File
                    </Link>
                  </TableCell>)}
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      </Paper>
    </Box>
  );
};

export default SupportingDocuments;
