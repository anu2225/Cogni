import React from "react";

import {
  Box,
  Divider,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableRow,
  Typography,
  tableCellClasses,
  Link,
  ToggleButtonGroup,
  ToggleButton,
  Grid,
} from "@mui/material";

import { useTranslation } from "react-i18next";

interface ChildComponentProps {
  fields: {
    usaRelatedBirth: string;

    greenCardStatus: string;

    usaTaxStatus: string;

    minimumResidencyCondition: string;
  };

  setFields: React.Dispatch<
    React.SetStateAction<{
      usaRelatedBirth: string;

      greenCardStatus: string;

      usaTaxStatus: string;

      minimumResidencyCondition: string;
    }>
  >;
}

const FatcaCrs: React.FC<ChildComponentProps> = ({ fields, setFields }) => {
  const handleButtonChange = (
    event: React.MouseEvent<HTMLElement>,

    fieldName: string
  ) => {
    const stateVal = event.currentTarget.textContent;

    setFields((fields) => ({ ...fields, [fieldName]: stateVal }));
  };

  const { t } = useTranslation();

  return (
    <Box>
      {/* FATCA Section */}
      <Paper elevation={3} sx={{ margin: 2 }}>
        <Box sx={{ padding: 2 }}>
          <Typography className="typography-main-header">
            {t("status")}
          </Typography>
          <Divider />
          <Box sx={{ marginTop: 2 }}>
            <TableContainer>
              <Table
                className="table-main"
                aria-label="table2"
              >
                <TableBody>
                  <TableRow>
                    <TableCell>
                      {t("fq1")}
                      <span style={{ color: "red" }}>*</span>
                    </TableCell>
                    <TableCell>
                      <ToggleButtonGroup
                        color="primary"
                        value={fields.usaRelatedBirth}
                        exclusive
                        fullWidth
                        size="small"
                        onChange={(event) =>
                          handleButtonChange(event, "usaRelatedBirth")
                        }
                        aria-label="Platform"
                      >
                        <ToggleButton value="No">No</ToggleButton>
                        <ToggleButton value="US Nationality">
                          US Nationality
                        </ToggleButton>
                        <ToggleButton value="Born in USA">
                          Born in USA
                        </ToggleButton>
                        <ToggleButton value="Born in USA with Nationality">
                          Born in USA with Nationality
                        </ToggleButton>
                      </ToggleButtonGroup>
                    </TableCell>
                  </TableRow>

                  {/* Other rows */}
                  <TableRow>
                    <TableCell>
                      {t("fq2")}
                      <span style={{ color: "red" }}>*</span>
                    </TableCell>
                    <TableCell>
                      <ToggleButtonGroup
                        color="primary"
                        value={fields.greenCardStatus}
                        exclusive
                        fullWidth
                        onChange={(event) =>
                          handleButtonChange(event, "greenCardStatus")
                        }
                        aria-label="Platform"
                      >
                        <ToggleButton value="No">No</ToggleButton>
                        <ToggleButton value="Yes">Yes</ToggleButton>
                        <ToggleButton value="Yes, but expired">
                          Yes, but expired
                        </ToggleButton>
                      </ToggleButtonGroup>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>
                      {t("fq3")}
                      <span style={{ color: "red" }}>*</span>
                    </TableCell>
                    <TableCell>
                      <ToggleButtonGroup
                        color="primary"
                        value={fields.usaTaxStatus}
                        exclusive
                        fullWidth
                        onChange={(event) =>
                          handleButtonChange(event, "usaTaxStatus")
                        }
                        aria-label="Platform"
                      >
                        <ToggleButton value="No">No</ToggleButton>
                        <ToggleButton value="Yes">Yes</ToggleButton>
                      </ToggleButtonGroup>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>
                      {t("fq4")}
                      <span style={{ color: "red" }}>*</span>
                    </TableCell>
                    <TableCell>
                      <ToggleButtonGroup
                        color="primary"
                        value={fields.minimumResidencyCondition}
                        exclusive
                        fullWidth
                        onChange={(event) =>
                          handleButtonChange(event, "minimumResidencyCondition")
                        }
                        aria-label="Platform"
                      >
                        <ToggleButton value="No">No</ToggleButton>
                        <ToggleButton value="Yes">Yes</ToggleButton>
                      </ToggleButtonGroup>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>{t("s1")}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>{t("s2")}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>{t("s3")}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>{t("s4")}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>{t("s5")}</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        </Box>
      </Paper>

      {/* CRS Section */}
      <Paper elevation={3} sx={{ margin: 2 }}>
        <Box sx={{ padding: 2 }}>
          <Typography className="typography-main-header">
            {t("crs_status")}
          </Typography>
          <Divider />
          <Box sx={{ marginTop: 2 }}>
            <TableContainer>
              <Table
                className="table-main"
                aria-label="simple table"
              >
                <TableBody>
                  <TableRow>
                    <TableCell>
                      {t("fq5")}
                      <span style={{ color: "red" }}>*</span>
                    </TableCell>
                    <TableCell>
                      {/* Dynamic UI for small screens */}
                      <Box
                        sx={{
                          display: "flex",

                          flexDirection: { xs: "column", sm: "row" },

                          alignItems: { xs: "flex-start", sm: "center" },

                          gap: 1,
                        }}
                      >
                        {/* <Typography>{t("crs_form")}</Typography> */}
                        <Link
                          href="#"
                          underline="always"
                          color="inherit"
                          sx={{
                            color: "#1976d2",

                            fontSize: { xs: "0.8rem", sm: "1rem" },
                          }}
                        >
                          CRSForm.pdf
                        </Link>
                      </Box>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        </Box>
      </Paper>
    </Box>
  );
};

export default FatcaCrs;
