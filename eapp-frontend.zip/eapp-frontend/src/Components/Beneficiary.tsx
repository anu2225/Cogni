import * as React from "react";

import { useEffect, useState } from "react";

import {
  Box,
  Button,
  Divider,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableRow,
  TextField,
  Typography,
} from "@mui/material";

import { useTranslation } from "react-i18next";

import { Dropdown } from "./Dropdown/Dropdown";

import { getBeneficiaryRelation } from "./Dropdown/DropdownApi";

interface ChildComponentProps {
  fields: {
    beneficiaryFirstName: string;

    beneficiaryLastName: string;

    beneficiaryAge: number;

    relationshipWithInsured: string;

    address: string;

    percentageOfBenefit: number;
  }[];

  setFields: React.Dispatch<
    React.SetStateAction<
      {
        beneficiaryFirstName: string;

        beneficiaryLastName: string;

        beneficiaryAge: number;

        relationshipWithInsured: string;

        address: string;

        percentageOfBenefit: number;
      }[]
    >
  >;
}

const Beneficiary: React.FC<ChildComponentProps> = ({ fields, setFields }) => {
  const { t } = useTranslation();

  const [beneficiaryTypeOpt, setBeneficiaryTypeOpt] = useState([]);

  useEffect(() => {
    getBeneficiaryRelation().then((res) => {
      setBeneficiaryTypeOpt(res.data);
    });
  }, []);

  const handleFieldChange = (val: string, fieldName: string, index: number) => {
    const updatedFields = fields.map((field, i) =>
      i === index ? { ...field, [fieldName]: val } : field
    );

    setFields(updatedFields);
  };

  const onHandleAddBeneficiary = () => {
    const newDetails = [
      {
        beneficiaryFirstName: "",

        beneficiaryLastName: "",

        beneficiaryAge: 18,

        relationshipWithInsured: "",

        address: "",

        percentageOfBenefit: 0,
      },
    ];

    setFields([...fields, ...newDetails]);
  };

  const onClickRemove = (index: number) => {
    const updatedFields = fields.filter((_, i) => i !== index);

    setFields(updatedFields);
  };

  return (
    <Box>
      {fields.map((row, index) => (
        <Paper elevation={3} sx={{ margin: 2 }} key={index}>
          <Box sx={{ padding: 2 }}>
            <Typography className="typography-main-header" >
              {`${t("beneficiary")} ${index + 1}`}
            </Typography>
            <Divider />
            <TableContainer>
              <Table
                className="table-main"
                size="small"
              >
                <TableBody>
                  <TableRow>
                    <TableCell>
                      <TextField
                        fullWidth
                        label={t("beneficiary_first_name")}
                        variant="standard"
                        value={row.beneficiaryFirstName}
                        onChange={(e) =>
                          handleFieldChange(
                            e.target.value,

                            "beneficiaryFirstName",

                            index
                          )
                        }
                      />
                    </TableCell>
                    <TableCell>
                      <TextField
                        fullWidth
                        label={t("beneficiary_last_name")}
                        variant="standard"
                        value={row.beneficiaryLastName}
                        onChange={(e) =>
                          handleFieldChange(
                            e.target.value,

                            "beneficiaryLastName",

                            index
                          )
                        }
                      />
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>
                      <TextField
                        fullWidth
                        type="number"
                        label={t("age")}
                        variant="standard"
                        value={row.beneficiaryAge}
                        onChange={(e) =>
                          handleFieldChange(
                            e.target.value,

                            "beneficiaryAge",

                            index
                          )
                        }
                      />
                    </TableCell>
                    <TableCell>
                      <Dropdown
                        label={t("relationship_with_insured")}
                        options={beneficiaryTypeOpt}
                        value={row.relationshipWithInsured}
                        onChange={(e) =>
                          handleFieldChange(
                            e.target.value,

                            "relationshipWithInsured",

                            index
                          )
                        }
                      />
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>
                      <TextField
                        fullWidth
                        label={t("address")}
                        variant="standard"
                        value={row.address}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "address", index)
                        }
                      />
                    </TableCell>
                    <TableCell>
                      <TextField
                        fullWidth
                        type="number"
                        label={t("percentage_of_benefit")}
                        variant="standard"
                        value={row.percentageOfBenefit}
                        onChange={(e) =>
                          handleFieldChange(
                            e.target.value,

                            "percentageOfBenefit",

                            index
                          )
                        }
                      />
                    </TableCell>
                  </TableRow>

                  {fields.length > 1 && (
                    <TableRow>
                      <TableCell colSpan={2} sx={{ textAlign: "center" }}>
                        <Button
                          variant="contained"
                          color="error"
                          onClick={() => onClickRemove(index)}
                        >
                          {t("remove")}
                        </Button>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        </Paper>
      ))}

      {fields.length < 5 && (
        <Box sx={{ textAlign: "center", marginTop: 2 }}>
          <Button className="styled-button" onClick={onHandleAddBeneficiary}>
            + {t("add")}
          </Button>
        </Box>
      )}
    </Box>
  );
};

export default Beneficiary;
