run npm install first
then run npm install react-router-dom
then run npm run dev to start the dev server