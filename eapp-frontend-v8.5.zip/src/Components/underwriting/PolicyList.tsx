import React, { useState, useEffect } from 'react';
import {
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Paper, TextField, Box, TablePagination, Link as MuiLink, CircularProgress,
  Stack,
  Typography,
  Switch
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import axios from '../../api/axiosInterceptor';
 
export interface Policy {
  caseNumber: string;
  clientNo: string;
  clientName: string;
  quotationNumber: string;
  quotationDate: string;
  applicationNumber: string;
  productName: string;
  sumAssured: string;
  annualPremium: string;
  uwStatus: number;
}
 
interface ApiResponse {
  policyId: string;
  creation_TIME: string;
  json_DATA: string;
  version_NO: number;
  screen_No: number;
  stateId: number;
  uwid: number;
  sa: number;
  periodPrem: number;
}
 
const PolicyList: React.FC = () => {
  const navigate = useNavigate();
 
  const [policies, setPolicies] = useState<Policy[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [page, setPage] = useState(0);
  const [useNewDesign, setUseNewDesign] = useState(false);
  const [rowsPerPage, setRowsPerPage] = useState(10);
 
  useEffect(() => {
    const fetchPolicies = async () => {
      try {
        const response = await axios.get('http://localhost:8001/eapp/getAllUw');
        const data: ApiResponse[] = response.data;
       
        const uniqueApplications = data.reduce((acc: any, record: ApiResponse) => {
          if (!acc[record.policyId]) {
            acc[record.policyId] = {
              caseNumber: record.uwid.toString(),
              clientNo: '',
              clientName: 'Unknown',
              quotationNumber: record.policyId,
              quotationDate: new Date(Date.now()).toISOString().split('T')[0],
              applicationNumber: record.policyId,
              productName: 'General Life Plan',
              sumAssured: record.sa?.toString() || '',
              annualPremium: record.periodPrem?.toString() || '',
              uwStatus: record.stateId || 0,
            };
          }
 
          let parsedData: any = {};
          try {
            parsedData = typeof record.json_DATA === 'string'
              ? JSON.parse(record.json_DATA)
              : record.json_DATA;
          } catch (e) {
            console.error('JSON parse error', e);
          }
 
          if (record.screen_No === 1) {
            acc[record.policyId].clientName =
              `${parsedData?.insuredFirstName || ''} ${parsedData?.insuredSurName || ''}`.trim() || 'Unknown';
            acc[record.policyId].clientNo = parsedData?.customerIdEbao || '';
          }
 
          if (record.screen_No === 2) {
            acc[record.policyId].productName = parsedData?.basicPlan || 'General Life Plan';
            acc[record.policyId].sumAssured = parsedData?.basicSumInsured || acc[record.policyId].sumAssured;
          }
 
          if (record.screen_No === 3) {
            acc[record.policyId].annualPremium =
              parsedData?.AmountOfPaymentWithThisApplication || acc[record.policyId].annualPremium;
          }
 
          return acc;
        }, {});
       
        setPolicies(Object.values(uniqueApplications));
        setLoading(false);
      } catch (error) {
        console.error('Error fetching policies:', error);
        setLoading(false);
      }
    };
   
    fetchPolicies();
  }, []);
 
  /* ===================== ONLY IMPORTANT CHANGE ===================== */
  const handleOpenDetails = (policy: Policy) => {
    if (useNewDesign) {
      navigate(`/underwriting/${policy.applicationNumber}/v2`, {
        state: { policyData: policy }
      });
    } else {
      navigate(`/underwriting/${policy.caseNumber}`, {
        state: { policyData: policy }
      });
    }
  };
  /* ================================================================ */
 
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
    setPage(0);
  };
 
  const handleChangeRowsPerPage = (e: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(parseInt(e.target.value, 10));
    setPage(0);
  };
 
  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
  };
 
  const filteredPolicies = policies.filter((policy) => {
    if (!searchQuery) return true;
    return (
      policy.caseNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      policy.clientName.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });
 
  const visiblePolicies = filteredPolicies.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage
  );
 
  return (
    <div>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2, mt: 2 }}>
        <TextField
          label="Search ID or Name"
          variant="outlined"
          size="small"
          value={searchQuery}
          onChange={handleSearchChange}
          sx={{ width: '300px' }}
        />
      </Box>
 
      <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 2 }}>
        <Typography variant="body2">Classic View</Typography>
        <Switch
          checked={useNewDesign}
          onChange={(e) => setUseNewDesign(e.target.checked)}
        />
        <Typography variant="body2">V2</Typography>
      </Stack>
 
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Case Number</TableCell>
              <TableCell>Client No</TableCell>
              <TableCell>Client Name</TableCell>
              <TableCell>Quotation Number</TableCell>
              <TableCell>Quotation Date</TableCell>
              <TableCell>Application Number</TableCell>
              <TableCell>Product Name</TableCell>
              <TableCell>Sum Assured</TableCell>
              <TableCell>Annual Premium</TableCell>
              <TableCell>UW Status</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={10} align="center">
                  <CircularProgress size={24} />
                </TableCell>
              </TableRow>
            ) : (
              visiblePolicies.map((policy, index) => (
                <TableRow key={index} hover>
                  <TableCell>
                    <MuiLink component="button" onClick={() => handleOpenDetails(policy)}>
                      CASE-{policy.caseNumber}
                    </MuiLink>
                  </TableCell>
                  <TableCell>{policy.clientNo}</TableCell>
                  <TableCell>{policy.clientName}</TableCell>
                  <TableCell>{policy.quotationNumber}</TableCell>
                  <TableCell>{policy.quotationDate}</TableCell>
                  <TableCell>{policy.applicationNumber}</TableCell>
                  <TableCell>{policy.productName}</TableCell>
                  <TableCell>{policy.sumAssured}</TableCell>
                  <TableCell>{policy.annualPremium}</TableCell>
                  <TableCell>{policy.uwStatus === 2 ? 'Not Started' : 'In Progress'}</TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </TableContainer>
 
      <TablePagination
        rowsPerPageOptions={[5, 10, 25, 50]}
        component="div"
        count={filteredPolicies.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </div>
  );
};
 
export default PolicyList;
 
 