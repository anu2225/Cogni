import React, { useState, useEffect } from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions,
  Box, Typography, IconButton, Grid, TextField,
  Button, Stack, FormControl, Select, MenuItem,
  Radio, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, CircularProgress,
  InputLabel, InputAdornment
} from '@mui/material';
import { Close } from '@mui/icons-material';

// --- Types ---
export interface PolicyProduct {
  id: string; 
  sequence: string;
  code: string;
  name: string;
  insured: string;
  inceptionDate: string;
  nextPaymentDate: string;
  status: string;
  laySumAssured: string;
  targetPremium: string;
  em: string;
  perMille: string;
  increaseRate: string;
  decision: string;
  finishStatus: string;
}

interface DecisionModalProps {
  open: boolean;
  onClose: () => void;
  selectedPolicies: PolicyProduct[]; 
  onSubmit: (data: any) => void;
}

const DecisionModal: React.FC<DecisionModalProps> = ({ open, onClose, selectedPolicies = [], onSubmit }) => {
  
  // --- State ---
  const [currentView, setCurrentView] = useState<'DECISION' | 'INCREASE_PREMIUM'>('DECISION');
  const [selectedTargetId, setSelectedTargetId] = useState<string | null>(null);
  
  // Decision Fields
  const [uwDecision, setUwDecision] = useState('');
  const [mortalityRate, setMortalityRate] = useState('0');
  
  // Increase Premium Form State
  const [loadingCalculate, setLoadingCalculate] = useState(false);
  const [premiumForm, setPremiumForm] = useState({
    em: '0',
    perMille: '0',
    occClass: '',
    riskClass: ''
  });

  // Reset on close
  useEffect(() => {
    if (!open) {
      setSelectedTargetId(null);
      setCurrentView('DECISION');
      setUwDecision('');
      setMortalityRate('0');
      setPremiumForm({ em: '0', perMille: '0', occClass: '', riskClass: '' });
    }
  }, [open]);

  const getSelectedPolicy = () => selectedPolicies.find(p => p.id === selectedTargetId);

  // --- Handlers ---
  const handleDecisionChange = (event: any) => {
    setUwDecision(event.target.value);
  };

  const handleCalculate = async () => {
    const policy = getSelectedPolicy();
    if (!policy) return;

    setLoadingCalculate(true);
    try {
      console.log("Sending Calculation Request:", { ...premiumForm, policyId: policy.id });
      await new Promise(resolve => setTimeout(resolve, 800)); 
      alert("Calculation Request Sent");
    } catch (error) {
      console.error("Calculation failed", error);
    } finally {
      setLoadingCalculate(false);
    }
  };

  const handleSavePremium = () => {
    console.log("Saving Premium Data:", premiumForm);
    setCurrentView('DECISION'); 
  };

  // --- Shared UI Helpers (Matching Parent Style) ---
  // Clean Section Header standardized to match parent style
  const SectionHeader = ({ title }: { title: string }) => (
    <Box sx={{ mb: 2, mt: 3, pb: 1, borderBottom: '1px solid #e0e0e0' }}>
      <Typography variant="h6" fontWeight="bold" color="text.primary">{title}</Typography>
    </Box>
  );

  // Clean Info Row standardized to match parent style
  const InfoRow = ({ label, value }: { label: string, value: React.ReactNode }) => (
    <Grid item xs={12} sm={6} md={3}>
      <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 0.5, textTransform: 'uppercase', fontSize: '0.7rem', letterSpacing: '0.5px' }}>{label}</Typography>
      <Typography variant="body2" fontWeight="500">{value}</Typography>
    </Grid>
  );

  // --- RENDER ---
  return (
    <Dialog open={open} onClose={onClose} maxWidth="xl" fullWidth>
      
      {/* HEADER: Standard MUI Dialog Header */}
      <DialogTitle sx={{ bgcolor: '#f5f5f5', borderBottom: '1px solid #ddd', pb: 2 }}>
        <Box display="flex" justifyContent="space-between" alignItems="center">
          <Typography variant="h6" fontWeight="bold">
             {currentView === 'DECISION' ? 'Policy Type' : 'Increase Premium Calculation'}
          </Typography>
          <IconButton onClick={onClose}><Close /></IconButton>
        </Box>
      </DialogTitle>

      <DialogContent dividers sx={{ p: 4, bgcolor: '#ffffff' }}>
        
        {/* ================= VIEW 1: DECISION SCREEN ================= */}
        {currentView === 'DECISION' && (
           <>
             {/* Header Info Block - Using Paper outlined like parent header */}
             <Paper elevation={0} variant="outlined" sx={{ p: 3, mb: 2, borderRadius: 2, border: '1px solid #e0e0e0' }}>
                 <Grid container spacing={3}>
                    <InfoRow label="Policy Number" value={selectedPolicies.length > 0 ? selectedPolicies[0].code : 'N/A'} />
                    <InfoRow label="Underwriting Code" value="1416471" />
                    <InfoRow label="Status" value="In Progress" />
                 </Grid>
             </Paper>

             {/* Table 1: Underwriting Product - Using standard MUI Paper styling */}
             <SectionHeader title="Underwriting Product" />
             <TableContainer component={Paper} elevation={1} sx={{ borderRadius: 2 }}>
                <Table size="small">
                  <TableHead sx={{ bgcolor: '#f5f5f5' }}>
                    <TableRow>
                      {['Product Sequence', 'Product Code', 'Product Name', 'Insured', 'Inception Date', 'Next Payment Date', 'Confirm Status'].map(h => (
                        <TableCell key={h}><strong>{h}</strong></TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {selectedPolicies.map((row) => (
                      <TableRow key={row.id} hover>
                        <TableCell>{row.sequence}</TableCell>
                        <TableCell>{row.code}</TableCell>
                        <TableCell>{row.name}</TableCell>
                        <TableCell>{row.insured}</TableCell>
                        <TableCell>{row.inceptionDate}</TableCell>
                        <TableCell>{row.nextPaymentDate}</TableCell>
                        <TableCell>{row.status}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>

             {/* Table 2: Target Info */}
             <SectionHeader title="Target Info" />
             <TableContainer component={Paper} elevation={1} sx={{ borderRadius: 2 }}>
                <Table size="small">
                  <TableHead sx={{ bgcolor: '#f5f5f5' }}>
                    <TableRow>
                      <TableCell width={50}></TableCell>
                      {['Product Code', 'Target Id', 'Lay Sum Assured', 'Target Premium', 'EM', 'Per mille', 'Premium Increase Rate', 'Underwriting decision', 'Status'].map(h => (
                        <TableCell key={h}><strong>{h}</strong></TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {selectedPolicies.map((row) => (
                      <TableRow key={row.id} selected={selectedTargetId === row.id} hover>
                        <TableCell align="center">
                          <Radio checked={selectedTargetId === row.id} onChange={() => setSelectedTargetId(row.id)} size="small"/>
                        </TableCell>
                        <TableCell>{row.code}</TableCell>
                        <TableCell>{row.id}</TableCell>
                        <TableCell>{row.laySumAssured}</TableCell>
                        <TableCell>{row.targetPremium}</TableCell>
                        <TableCell>{row.em}</TableCell>
                        <TableCell>{row.perMille}</TableCell>
                        <TableCell>{row.increaseRate}</TableCell>
                        <TableCell>{row.decision}</TableCell>
                        <TableCell>{row.finishStatus}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>

             {/* Decision Form - Using standard Paper elevation 1 with padding */}
             {selectedTargetId && (
                <Box mt={4}>
                    <SectionHeader title="Underwriting Decision" />
                    <Paper elevation={1} sx={{ p: 3, borderRadius: 2 }}>
                        <Grid container spacing={3}>
                            {/* Row 1: Underwriters */}
                            <Grid item xs={12} md={6}>
                                <TextField 
                                    label="Current Underwriter" 
                                    fullWidth 
                                    size="small" 
                                    value="John Doe" 
                                    disabled 
                                />
                            </Grid>
                            <Grid item xs={12} md={6}>
                                <TextField 
                                    label="Previous Underwriter" 
                                    fullWidth 
                                    size="small" 
                                    value="Jane Doe" 
                                    disabled 
                                />
                            </Grid>

                            {/* Row 2: Decision & Mortality */}
                            <Grid item xs={12} md={6}>
                                <FormControl fullWidth size="small">
                                    <InputLabel>Underwriting Decision</InputLabel>
                                    <Select 
                                        label="Underwriting Decision"
                                        value={uwDecision} 
                                        onChange={handleDecisionChange} 
                                    >
                                        <MenuItem value="Standard">Standard Case Underwritten</MenuItem>
                                        <MenuItem value="Conditional">Conditional Underwritten</MenuItem>
                                        <MenuItem value="Decline">Declination</MenuItem>
                                        <MenuItem value="Postpone">Postpone</MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={12} md={6}>
                                <TextField 
                                    label="Mortality Rate" 
                                    fullWidth 
                                    size="small"
                                    value={mortalityRate}
                                    onChange={(e) => setMortalityRate(e.target.value)}
                                    InputProps={{
                                        endAdornment: <InputAdornment position="end">%</InputAdornment>,
                                    }}
                                />
                            </Grid>

                            {/* Row 3: Actions */}
                            <Grid item xs={12}>
                                <Stack direction="row" spacing={2} justifyContent="flex-end">
                                    <Button 
                                        variant="contained"
                                        color="primary"
                                        disabled={uwDecision !== 'Conditional'}
                                        onClick={() => setCurrentView('INCREASE_PREMIUM')}
                                    >
                                        Increase Premium
                                    </Button>
                                    <Button variant="outlined" color="primary">
                                        Restrict Sum Assured
                                    </Button>
                                </Stack>
                            </Grid>
                        </Grid>
                    </Paper>
                </Box>
             )}
           </>
        )}

        {/* ================= VIEW 2: INCREASE PREMIUM SCREEN ================= */}
        {currentView === 'INCREASE_PREMIUM' && (
          <>
             {/* Section 1: Read Only Data - Using standard Paper style */}
             <SectionHeader title="Insurant Product Information" />
             <Paper elevation={1} sx={{ p: 3, borderRadius: 2 }}>
                <Grid container spacing={3}>
                    <InfoRow label="Policy Number" value={getSelectedPolicy()?.code || ''} />
                    <InfoRow label="Product Name" value={getSelectedPolicy()?.name || ''} />
                    <InfoRow label="Sum Assured" value={getSelectedPolicy()?.laySumAssured || ''} />
                    <InfoRow label="Current Premium" value={getSelectedPolicy()?.targetPremium || ''} />
                    <InfoRow label="Target ID" value={selectedTargetId || ''} />
                    <InfoRow label="Inception Date" value={getSelectedPolicy()?.inceptionDate || ''} />
                </Grid>
             </Paper>

             {/* Section 2: Input Form - Using standard Paper style */}
             <SectionHeader title="Premium Calculation Factors" />
             <Paper elevation={1} sx={{ p: 3, borderRadius: 2 }}>
                <Grid container spacing={3}>
                    {/* EM Value */}
                    <Grid item xs={12} sm={6} md={3}>
                        <FormControl fullWidth size="small">
                            <InputLabel>EM Value</InputLabel>
                            <Select
                                value={premiumForm.em}
                                label="EM Value"
                                onChange={(e) => setPremiumForm({...premiumForm, em: e.target.value})}
                            >
                                <MenuItem value="0">0%</MenuItem>
                                <MenuItem value="25">25%</MenuItem>
                                <MenuItem value="50">50%</MenuItem>
                                <MenuItem value="75">75%</MenuItem>
                                <MenuItem value="100">100%</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>

                    {/* Per Mille */}
                    <Grid item xs={12} sm={6} md={3}>
                        <FormControl fullWidth size="small">
                            <InputLabel>Per Mille</InputLabel>
                            <Select
                                value={premiumForm.perMille}
                                label="Per Mille"
                                onChange={(e) => setPremiumForm({...premiumForm, perMille: e.target.value})}
                            >
                                <MenuItem value="0">0%</MenuItem>
                                <MenuItem value="50">50%</MenuItem>
                                <MenuItem value="100">100%</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>

                    {/* Occupational Class */}
                    <Grid item xs={12} sm={6} md={3}>
                        <FormControl fullWidth size="small">
                            <InputLabel>Occupational Class</InputLabel>
                            <Select
                                value={premiumForm.occClass}
                                label="Occupational Class"
                                onChange={(e) => setPremiumForm({...premiumForm, occClass: e.target.value})}
                            >
                                <MenuItem value="1">Class 1</MenuItem>
                                <MenuItem value="2">Class 2</MenuItem>
                                <MenuItem value="3">Class 3</MenuItem>
                                <MenuItem value="4">Class 4</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>

                    {/* Risk Class */}
                    <Grid item xs={12} sm={6} md={3}>
                        <FormControl fullWidth size="small">
                            <InputLabel>Risk Class</InputLabel>
                            <Select
                                value={premiumForm.riskClass}
                                label="Risk Class"
                                onChange={(e) => setPremiumForm({...premiumForm, riskClass: e.target.value})}
                            >
                                <MenuItem value="Low">Low Risk</MenuItem>
                                <MenuItem value="Medium">Medium Risk</MenuItem>
                                <MenuItem value="High">High Risk</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>
                </Grid>
             </Paper>
          </>
        )}
      </DialogContent>

      {/* FOOTER ACTIONS: Standard MUI Dialog Footer */}
      <DialogActions sx={{ p: 3, bgcolor: '#f5f5f5', borderTop: '1px solid #ddd', justifyContent: 'flex-end' }}>
        {currentView === 'INCREASE_PREMIUM' ? (
            <>
                <Button 
                    variant="outlined"
                    onClick={handleCalculate}
                    disabled={loadingCalculate}
                    startIcon={loadingCalculate ? <CircularProgress size={16} /> : null}
                >
                    Calculate
                </Button>
                <Button 
                    variant="contained"
                    onClick={handleSavePremium}
                    disabled={loadingCalculate}
                >
                    Submit
                </Button>
                <Button 
                    color="inherit"
                    onClick={() => setCurrentView('DECISION')}
                >
                    Cancel
                </Button>
            </>
        ) : (
            <Button onClick={onClose} color="inherit">Close</Button>
        )}
      </DialogActions>
    </Dialog>
  );
};

export default DecisionModal;