import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from '../../api/axiosInterceptor'; 
import dayjs from 'dayjs';
import { 
  ArrowBack, Search, Notifications, 
  CheckCircle, Description, MonitorHeart,
  AttachMoney, AssignmentInd, CurrencyRupee,
  ChevronLeft, ChevronRight, ZoomIn, ZoomOut
} from '@mui/icons-material';

// --- PDF IMPORTS ---
import { Document, Page, pdfjs } from 'react-pdf';

// Configure PDF Worker (Required for react-pdf)
// Using unpkg CDN to avoid complex webpack config
pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`;

// --- TYPES ---
interface ApiRecord {
  quotation_id: string;
  screen_No: number;
  json_DATA: string;
  creation_TIME: string;
  version_NO: number;
}

interface UnderwritingCase {
  uwCode: string;
  applicantName: string;
  appNumber: string;
  productName: string;
  dob: string;
  gender: string;
  occupation: string;
  income: string;
  sumAssured: string;
  premium: string;
  bmi: string; 
  riskScore: number; 
}

const UnderwritingDetailsTailwind: React.FC = () => {
  const { txnTypeId } = useParams();
  const navigate = useNavigate();
  
  // --- STATE ---
  const [loading, setLoading] = useState(true);
  const [caseData, setCaseData] = useState<UnderwritingCase | null>(null);
  const [decision, setDecision] = useState('Standard');
  const [notes, setNotes] = useState('');

  // PDF Viewer State
  const [numPages, setNumPages] = useState<number | null>(null);
  const [pageNumber, setPageNumber] = useState(1);
  const [scale, setScale] = useState(1.0);

  // --- HELPER: Format Currency to INR ---
  const formatRupees = (value: string | number) => {
    if (!value) return '₹0';
    const num = Number(value);
    if (isNaN(num)) return '₹0';
    
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(num);
  };

  // --- HELPER: Calculate BMI ---
  const calculateBMI = (height: any, weight: any) => {
    const h = Number(height); // usually in cm
    const w = Number(weight); // usually in kg
    if (!h || !w) return '24.5'; // Default/Mock if missing
    
    // Formula: kg / (m^2)
    const bmi = w / ((h / 100) ** 2);
    return bmi.toFixed(1);
  };

  // --- DATA FETCHING ---
  useEffect(() => {
    if (!txnTypeId){
        console.log("No txnTypeId provided");
        return;
    } 

    const fetchData = async () => {
      setLoading(true);
      try {
        const response = await axios.get<ApiRecord[]>('http://localhost:8001/eapp/getAll');
        const matchingRecords = response.data.filter(item => item.quotation_id === txnTypeId);

        if (matchingRecords.length === 0) {
           setCaseData(null);
           console.log(response.data);
           console.log("No matching records found for txnTypeId:", txnTypeId);
           return;
        }

        const screens: { [key: number]: any } = {};
        matchingRecords.forEach(rec => {
           screens[rec.screen_No] = { parsedData: typeof rec.json_DATA === 'string' ? JSON.parse(rec.json_DATA) : rec.json_DATA };
        });

        const s1 = screens[1]?.parsedData || {};
        const s2 = screens[2]?.parsedData || {};
        const s10 = screens[10]?.parsedData || {};

        setCaseData({
          uwCode: `CASE-${txnTypeId?.substring(0,6)}`,
          applicantName: `${s1.insuredFirstName || 'Unknown'} ${s1.insuredSurName || ''}`,
          appNumber: txnTypeId,
          productName: s2.basicPlan || 'Term Life Protect',
          dob: s1.insuredDateOfBirth ? dayjs(s1.insuredDateOfBirth).format('DD MMM YYYY') : '-',
          gender: s1.insuredGender || 'Male',
          occupation: s1.occupationCode || 'Software Engineer',
          
          // Formatted Fields
          income: formatRupees(s1.annualIncome || 0),
          sumAssured: formatRupees(s2.basicSumInsured || 0),
          premium: formatRupees(s10.annualPremium || 0),
          
          // Calculated/Mocked Fields
          bmi: calculateBMI(s1.Height, s1.Weight), 
          riskScore: 75
        });

      } catch (error) {
        console.error("Error", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [txnTypeId]);

  function onDocumentLoadSuccess({ numPages }: { numPages: number }) {
    setNumPages(numPages);
  }

  // --- RENDER HELPERS ---
  if (loading) return <div className="min-h-screen bg-slate-900 flex items-center justify-center text-white font-mono animate-pulse">Loading...</div>;
  // if (!caseData) return <div className="min-h-screen bg-slate-900 flex items-center justify-center text-white">No Case Data Found</div>;

  return (
    <div className="min-h-screen bg-slate-900 text-slate-300 font-sans selection:bg-blue-500 selection:text-white">
      
      {/* --- TOP BAR --- */}
      <header className="h-16 bg-slate-800 border-b border-slate-700 flex items-center justify-between px-6 sticky top-0 z-50 shadow-md">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate('/underwriting')} className="text-slate-400 hover:text-white transition p-2 hover:bg-slate-700 rounded-full">
            <ArrowBack fontSize="small" />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-tr from-blue-600 to-blue-400 rounded-lg flex items-center justify-center font-bold text-white shadow-lg shadow-blue-500/20">A</div>
            <span className="text-white font-semibold text-lg tracking-tight">Life Insurance</span>
          </div>
        </div>

        <div className="flex-1 max-w-xl mx-8 relative hidden md:block">
          <Search className="absolute left-3 top-2.5 text-slate-500 text-sm" />
          <input 
            type="text" 
            placeholder="Search Policy, Applicant, or Medical Code..." 
            className="w-full bg-slate-900 border border-slate-700 rounded-lg py-2 pl-10 pr-4 text-sm text-slate-200 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition"
          />
        </div>

        <div className="flex items-center gap-4">
          <button className="text-slate-400 hover:text-white relative">
            <Notifications />
            <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full border border-slate-800"></span>
          </button>
          <div className="flex items-center gap-3 pl-4 border-l border-slate-700">
            <div className="text-right hidden md:block">
              <div className="text-xs text-white font-medium">Sarah J.</div>
              <div className="text-[10px] text-slate-400">Senior Underwriter</div>
            </div>
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-400 to-blue-500 ring-2 ring-slate-700"></div>
          </div>
        </div>
      </header>

      {/* --- MAIN CONTENT GRID --- */}
      <main className="p-4 grid grid-cols-12 gap-4 lg:h-[calc(100vh-64px)] overflow-y-auto custom-scrollbar">
        
        {/* === LEFT COLUMN: PROFILE & NAV (Col Span 3) === */}
        <aside className="col-span-12 lg:col-span-3 flex flex-col gap-4">
          
          {/* Applicant Card */}
          <div className="bg-slate-800 rounded-xl p-5 border border-slate-700 shadow-lg relative overflow-hidden group">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-green-400 to-blue-500"></div>
            
            <div className="flex items-start justify-between mb-6">
              <div className="flex gap-4">
                <div className="w-16 h-16 rounded-xl bg-slate-700 overflow-hidden ring-2 ring-slate-600 group-hover:ring-blue-500 transition-all">
                  <img src="https://i.pravatar.cc/150?img=11" alt="Profile" className="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition" />
                </div>
                <div>
                  <h2 className="text-white font-bold text-lg leading-tight">{caseData.applicantName}</h2>
                  <p className="text-xs text-slate-400 mt-1">{caseData.occupation}</p>
                  <span className="inline-block mt-2 text-[10px] font-mono text-blue-300 bg-blue-900/30 px-2 py-0.5 rounded border border-blue-500/20">
                    {caseData.uwCode}
                  </span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between items-center p-2.5 bg-slate-900/50 rounded-lg border border-slate-800 hover:border-slate-600 transition">
                <div className="flex items-center gap-3 text-slate-400 text-xs">
                  <div className="p-1.5 bg-slate-800 rounded text-blue-400"><MonitorHeart fontSize="inherit" /></div>
                  <span className="font-medium">BMI: {caseData.bmi}</span>
                </div>
                <CheckCircle sx={{ fontSize: 16 }} className="text-green-500" />
              </div>
              
              <div className="flex justify-between items-center p-2.5 bg-slate-900/50 rounded-lg border border-slate-800 hover:border-slate-600 transition">
                <div className="flex items-center gap-3 text-slate-400 text-xs">
                   <div className="p-1.5 bg-slate-800 rounded text-yellow-400"><CurrencyRupee fontSize="inherit" /></div>
                   <span className="font-medium">Income: {caseData.income}</span>
                </div>
                <CheckCircle sx={{ fontSize: 16 }} className="text-green-500" />
              </div>

              <div className="flex justify-between items-center p-2.5 bg-slate-900/50 rounded-lg border border-slate-800 hover:border-slate-600 transition">
                 <div className="flex items-center gap-3 text-slate-400 text-xs">
                   <div className="p-1.5 bg-slate-800 rounded text-purple-400"><AssignmentInd fontSize="inherit" /></div>
                   <span className="font-medium">Sum Assured: {caseData.sumAssured}</span>
                 </div>
                 <div className="text-[10px] bg-blue-500/10 text-blue-300 px-2 py-0.5 rounded border border-blue-500/20">Term 20</div>
              </div>
            </div>
          </div>

          {/* Navigation Menu */}
          <div className="bg-slate-800 rounded-xl overflow-hidden border border-slate-700 flex-1 shadow-lg flex flex-col">
            <div className="p-4 bg-slate-900/30 border-b border-slate-700">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Case Sections</span>
            </div>
            <div className="flex flex-col p-2 gap-1 flex-1 overflow-y-auto">
              {['Overview', 'Application QA', 'Medical History', 'Financial Docs', 'Documents (5)', 'Agent Report', 'Previous Policies'].map((item, idx) => (
                <button 
                  key={item}
                  className={`px-4 py-3 text-sm text-left rounded-lg transition-all duration-200 flex justify-between items-center
                    ${idx === 4 
                        ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/50 font-medium' 
                        : 'text-slate-400 hover:bg-slate-700/50 hover:text-slate-200'
                    }`}
                >
                  {item}
                  {idx === 4 && <span className="bg-white/20 text-white text-[10px] px-2 py-0.5 rounded-full">Active</span>}
                </button>
              ))}
            </div>
          </div>
        </aside>

        {/* === CENTER COLUMN: WORKSPACE (Col Span 6) === */}
        <section className="col-span-12 lg:col-span-6 flex flex-col gap-4">
          
          {/* Comparison Table */}
          <div className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden shadow-lg">
             <div className="p-3 px-4 border-b border-slate-700 flex justify-between items-center bg-slate-800">
               <div className="flex items-center gap-2">
                 <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></div>
                 <h3 className="text-white font-semibold text-sm">Self-Reported vs. Evidence</h3>
               </div>
               <span className="text-[10px] font-mono text-blue-300 bg-blue-900/30 border border-blue-500/30 px-2 py-1 rounded">Genclave AI Scan</span>
             </div>
             
             <table className="w-full text-sm text-left">
               <thead className="text-xs text-slate-500 uppercase bg-slate-900/50 border-b border-slate-700">
                 <tr>
                   <th className="px-4 py-3 font-medium">Condition</th>
                   <th className="px-4 py-3 font-medium">Evidence Found</th>
                   <th className="px-4 py-3 font-medium text-center">Status</th>
                 </tr>
               </thead>
               <tbody className="divide-y divide-slate-700">
                 <tr className="bg-slate-800/50 hover:bg-slate-700/30 transition">
                   <td className="px-4 py-3 text-slate-300">Hypertension <span className="text-yellow-500 text-[10px] ml-1 bg-yellow-500/10 px-1 rounded">⚠ Discrepancy</span></td>
                   <td className="px-4 py-3 text-yellow-500 font-medium">Found: High BP Meds</td>
                   <td className="px-4 py-3 text-center"><span className="bg-red-500/10 text-red-400 px-2 py-1 rounded text-xs border border-red-500/20 font-medium">Review</span></td>
                 </tr>
                 <tr className="hover:bg-slate-700/30 transition">
                   <td className="px-4 py-3 text-slate-300">High Cholesterol</td>
                   <td className="px-4 py-3 text-slate-500 italic">No Evidence Found</td>
                   <td className="px-4 py-3 text-center"><span className="text-slate-500 text-xs">--</span></td>
                 </tr>
                 <tr className="hover:bg-slate-700/30 transition">
                   <td className="px-4 py-3 text-slate-300">Appendectomy</td>
                   <td className="px-4 py-3 text-green-400 flex items-center gap-1.5">
                      <CheckCircle sx={{ fontSize: 14 }} /> Confirmed in History
                   </td>
                   <td className="px-4 py-3 text-center"><span className="bg-green-500/10 text-green-400 px-2 py-1 rounded text-xs border border-green-500/20">Match</span></td>
                 </tr>
               </tbody>
             </table>
          </div>

          {/* PDF Viewer */}
          <div className="bg-slate-800 rounded-xl border border-slate-700 flex-1 flex flex-col min-h-[500px] shadow-lg overflow-hidden">
            {/* Toolbar */}
            <div className="p-2 px-4 border-b border-slate-700 flex justify-between items-center bg-slate-900/80 backdrop-blur sticky top-0 z-10">
              <div className="flex items-center gap-2">
                 <Description className="text-blue-400" fontSize="small" />
                 <span className="text-slate-200 text-sm font-medium">Attending Physician Statement.pdf</span>
              </div>
              
              <div className="flex items-center gap-1 bg-slate-800 rounded-lg p-1 border border-slate-600 shadow-inner">
                <button 
                  disabled={pageNumber <= 1} 
                  onClick={() => setPageNumber(prev => prev - 1)}
                  className="p-1 text-slate-400 hover:text-white hover:bg-slate-700 rounded disabled:opacity-30 transition"
                >
                  <ChevronLeft fontSize="small" />
                </button>
                <span className="text-xs font-mono text-slate-300 w-16 text-center select-none">
                   {pageNumber} / {numPages || '--'}
                </span>
                <button 
                  disabled={pageNumber >= (numPages || 1)} 
                  onClick={() => setPageNumber(prev => prev + 1)}
                  className="p-1 text-slate-400 hover:text-white hover:bg-slate-700 rounded disabled:opacity-30 transition"
                >
                  <ChevronRight fontSize="small" />
                </button>
                <div className="w-px h-4 bg-slate-600 mx-2"></div>
                <button onClick={() => setScale(s => Math.max(0.5, s - 0.1))} className="p-1 text-slate-400 hover:text-white hover:bg-slate-700 rounded">
                  <ZoomOut fontSize="small" />
                </button>
                <button onClick={() => setScale(s => Math.min(2.0, s + 0.1))} className="p-1 text-slate-400 hover:text-white hover:bg-slate-700 rounded">
                  <ZoomIn fontSize="small" />
                </button>
              </div>
            </div>
            
            {/* PDF Canvas */}
            <div className="flex-1 bg-[#525659] p-6 relative overflow-auto flex justify-center custom-scrollbar">
               <Document
                  file="/medical-report.pdf" 
                  onLoadSuccess={onDocumentLoadSuccess}
                  loading={<div className="flex flex-col items-center mt-20 gap-4"><div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div><span className="text-slate-400 text-sm">Loading Document...</span></div>}
                  error={<div className="text-red-400 mt-20 text-center px-4 py-2 bg-red-900/20 border border-red-500/30 rounded">Failed to load PDF.<br/><span className="text-xs text-slate-400">Ensure 'medical-report.pdf' is in the public folder.</span></div>}
               >
                  <Page 
                    pageNumber={pageNumber} 
                    scale={scale} 
                    renderTextLayer={false} 
                    renderAnnotationLayer={false}
                    className="shadow-2xl"
                  />
               </Document>
            </div>
          </div>
        </section>

        {/* === RIGHT COLUMN: INSIGHTS & ACTIONS (Col Span 3) === */}
        <aside className="col-span-12 lg:col-span-3 flex flex-col gap-4">
          
          {/* Automated Risk Insights */}
          <div className="bg-slate-800 rounded-xl p-6 border border-slate-700 flex flex-col items-center relative shadow-lg">
             <div className="w-full flex justify-between items-center mb-6">
                <h3 className="text-slate-200 font-semibold text-sm">Automated Risk Score</h3>
                <span className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]"></span>
             </div>
             
             {/* Conic Gradient Gauge */}
             <div className="relative w-48 h-48 rounded-full flex items-center justify-center mb-6 shadow-2xl shadow-black/50"
                  style={{ background: `conic-gradient(#22c55e 0% 60%, #eab308 60% 85%, #ef4444 85% 100%)` }}
             >
                <div className="w-36 h-36 bg-slate-800 rounded-full flex flex-col items-center justify-center z-10 shadow-inner">
                   <span className="text-4xl font-bold text-white tracking-tighter">{caseData.riskScore}</span>
                   <span className="text-xs text-slate-500 font-medium uppercase tracking-widest mt-1">Low Risk</span>
                </div>
             </div>

             <div className="w-full space-y-3 bg-slate-900/50 p-4 rounded-lg border border-slate-700/50">
                <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Critical Flags Detected</div>
                <div className="flex items-center gap-3 text-xs group cursor-help">
                   <div className="w-2 h-2 rounded-full bg-red-500 group-hover:animate-ping"></div>
                   <span className="text-slate-300 group-hover:text-white transition">MIB: Cardiovasc History</span>
                </div>
                <div className="flex items-center gap-3 text-xs group cursor-help">
                   <div className="w-2 h-2 rounded-full bg-yellow-500"></div>
                   <span className="text-slate-300 group-hover:text-white transition">Rx: Medication Conflict</span>
                </div>
                 <div className="flex items-center gap-3 text-xs group cursor-help">
                   <div className="w-2 h-2 rounded-full bg-green-500"></div>
                   <span className="text-slate-300 group-hover:text-white transition">Financials: Verified</span>
                </div>
             </div>
          </div>

          {/* Final Decision Console */}
          <div className="bg-slate-800 rounded-xl border border-slate-700 flex-1 flex flex-col shadow-lg overflow-hidden">
             <div className="p-3 bg-gradient-to-r from-slate-800 to-slate-900 border-b border-slate-700">
                <h3 className="text-white font-semibold text-sm flex items-center gap-2">
                  <AssignmentInd fontSize="small" className="text-blue-400"/>
                  Final Decision Console
                </h3>
             </div>
             
             <div className="p-5 flex flex-col gap-5 flex-1">
                <div>
                   <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-2">Decision Type</label>
                   <div className="relative">
                      <select 
                          className="w-full bg-slate-900 border border-slate-600 rounded-lg p-2.5 text-sm text-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none appearance-none transition"
                          value={decision}
                          onChange={(e) => setDecision(e.target.value)}
                      >
                          <option value="Standard">Approve (Standard)</option>
                          <option value="Rated">Approve with Rating</option>
                          <option value="Postpone">Postpone</option>
                          <option value="Decline">Decline</option>
                      </select>
                      {/* Custom Arrow */}
                      <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                        <svg className="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                      </div>
                   </div>
                </div>

                {decision === 'Rated' && (
                  <div className="p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg flex items-start gap-2">
                    <div className="text-blue-400 mt-0.5">ℹ</div>
                    <div>
                      <div className="text-xs font-bold text-blue-300 mb-1">System Recommendation</div>
                      <div className="text-xs text-slate-400">Based on BMI and BP readings, consider Table B (+50%).</div>
                    </div>
                  </div>
                )}

                <div className="flex-1 flex flex-col">
                   <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-2">Underwriter Notes</label>
                   <textarea 
                      className="w-full flex-1 min-h-[120px] bg-slate-900 border border-slate-600 rounded-lg p-3 text-sm text-slate-300 resize-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition custom-scrollbar"
                      placeholder="Enter justification for decision..."
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                   ></textarea>
                </div>

                <div className="grid grid-cols-2 gap-3 mt-auto pt-4 border-t border-slate-700">
                   <button className="px-4 py-2.5 bg-transparent text-red-400 border border-red-500/30 rounded-lg hover:bg-red-500/10 text-sm font-semibold transition flex justify-center items-center gap-2">
                     Decline Case
                   </button>
                   <button className="px-4 py-2.5 bg-blue-600 text-white rounded-lg shadow-lg hover:bg-blue-500 hover:shadow-blue-500/25 text-sm font-semibold transition flex justify-center items-center gap-2 transform active:scale-95">
                     Submit Decision
                   </button>
                </div>
             </div>
          </div>

        </aside>
      </main>
    </div>
  );
};

export default UnderwritingDetailsTailwind;