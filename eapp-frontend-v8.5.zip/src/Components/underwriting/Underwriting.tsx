import React from 'react';
import { useParams } from 'react-router-dom';
import { Paper, Typography } from '@mui/material';
import PolicyList from './PolicyList';
import ApplicationBasicInfo from './ApplicationBasicInfo';
import UnderwritingDetails from './UnderwritingDetails';

const Underwriting: React.FC = () => {
  // Get the Transaction ID from the URL (e.g., /underwriting/Q000000488)
  const { txnTypeId } = useParams();

  // IF an ID exists, render ApplicationBasicInfo (Screen 2)
  if (txnTypeId) {
    return <ApplicationBasicInfo />;
  }

  // ELSE, render the List View (Screen 1: UW Case Details)
  return (
    <Paper sx={{ p: 3, height: '100%' }}>
      <Typography variant="h5" gutterBottom>
        Underwriting Sharing Pool
      </Typography>
      <PolicyList />
    </Paper>
  );
};

export default Underwriting;