import React, { useState } from 'react';
import { Paper, Typography, Grid, SelectChangeEvent, Button, Stack, IconButton, Box } from '@mui/material';
import { ArrowBack } from '@mui/icons-material';
import { useNavigate, useParams } from 'react-router-dom';
import { Dropdown } from '../Dropdown/Dropdown';
 
const UWRequirements: React.FC = () => {
  const { txnTypeId } = useParams();
  const navigate = useNavigate();
  const [nonMedicalRequirement, setNonMedicalRequirement] = useState<string>('');
  const [medicalRequirement, setMedicalRequirement] = useState<string>('');
 
  const nonMedicalOptions = [
    'Financial Supplement Questionnaire',
    'Third party verification of financial information',
    'financial statements',
    'Non-medical general questionnaire'
  ];
 
  const medicalOptions = [
    'Paramed',
    'Liver function tests',
    'Lipid profile',
    'MD exam',
    'Blood/HOS',
    'EKG',
    'MVR',
    'APS',
    'IR',
    'TM(Treadmill (stress) EKG)'
  ];
 
  const handleNonMedicalChange = (event: SelectChangeEvent<string>) => {
    setNonMedicalRequirement(event.target.value);
  };
 
  const handleMedicalChange = (event: SelectChangeEvent<string>) => {
    setMedicalRequirement(event.target.value);
  };
 
  return (
    <Box sx={{ p: 3, maxWidth: 1400, margin: 'auto', backgroundColor: '#f4f6f8' }}>
      <Stack direction="row" spacing={2} alignItems="center" sx={{ mb: 3 }}>
        <IconButton onClick={() => navigate(`/underwriting/${txnTypeId}`)}>
          <ArrowBack />
        </IconButton>
        <Box>
          <Typography variant="h5" fontWeight="bold">
            UW Requirements
          </Typography>
          <Typography variant="body2">
            Application : {txnTypeId}
          </Typography>
        </Box>
      </Stack>
     
      <Paper sx={{ p: 3, mb: 3 }}>
        <Grid container spacing={3}>
          <Grid item xs={12} md={6}>
            <Typography variant="h6" gutterBottom>
              Non-Medical UW requirement drop down
            </Typography>
            <Dropdown
              label="Non-Medical UW requirement"
              options={nonMedicalOptions}
              value={nonMedicalRequirement}
              onChange={handleNonMedicalChange}
            />
          </Grid>
         
          <Grid item xs={12} md={6}>
            <Typography variant="h6" gutterBottom>
              Medical UW requirement drop down
            </Typography>
            <Dropdown
              label="Medical UW requirement"
              options={medicalOptions}
              value={medicalRequirement}
              onChange={handleMedicalChange}
            />
          </Grid>
        </Grid>
      </Paper>
 
      <Paper sx={{ p: 2 }}>
        <Stack direction="row" spacing={2} justifyContent="flex-end">
          <Button variant="outlined" onClick={() => navigate(`/underwriting/${txnTypeId}`)}>
            Back
          </Button>
          <Button variant="contained">
            Save
          </Button>
        </Stack>
      </Paper>
    </Box>
  );
};
 
export default UWRequirements;
 