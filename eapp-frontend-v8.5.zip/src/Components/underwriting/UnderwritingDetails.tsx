import React, { useState, useEffect } from 'react';
import { 
  Box, Paper, Typography, Grid, TextField, 
  Button, Stack, IconButton, CircularProgress, 
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  MenuItem, Select, FormControl, InputLabel, Chip, Divider,
  Checkbox, Accordion, AccordionSummary, AccordionDetails
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { ArrowBack, Person, Assignment, LocalHospital, Assessment, Gavel, ExpandMore } from '@mui/icons-material';
import { useParams, useNavigate } from 'react-router-dom';
import axios from '../../api/axiosInterceptor';
import dayjs from 'dayjs';
import DecisionModal, { PolicyProduct } from './DecisionModal'; // Import the type from child

// --- Interfaces ---
interface ApiRecord {
  quotation_id: string;
  screen_No: number;
  json_DATA: string;
  creation_TIME: string;
  version_NO: number;
}

interface UnderwritingCase {
  uwCode: string;
  creationDate: string;
  applicantName: string;
  serviceType: string;
  appNumber: string;
  policyNumber: string;
  agentCode: string;
  branch: string;
  productName: string;
  email: string;
  mobile: string;
  dob: string;
  gender: string;
  age: string;
  weight: string;
  height: string;
  bmi: string;
  heightWeight: string; 
  occupation: string;
  income: string;
  sumAssured: string;
  premium: string;
  address: string;
  occLevelLife: string;
  occLevelAccident: string;
  occLevelHealth: string;
  tpdExposure: string;
  medicalReport: string;
}

interface PolicyRow {
    id: string;
    productName: string;
    sumAssured: string;
    premium: string;
    status: string;
}

// --- MAIN PAGE COMPONENT ---
const UnderwritingDetails: React.FC = () => {
  const { txnTypeId } = useParams();
  const navigate = useNavigate();
  
  const [loading, setLoading] = useState(true);
const [caseData, setCaseData] = useState<UnderwritingCase>({
  uwCode: '',
  creationDate: '',
  applicantName: '',
  serviceType: '',
  appNumber: '',
  policyNumber: '',
  agentCode: '',
  branch: '',
  productName: '',
  email: '',
  mobile: '',
  dob: '',
  gender: '',
  age: '',
  weight: '',
  height: '',
  bmi: '',
  heightWeight: '',
  occupation: '',
  income: '',
  sumAssured: '',
  premium: '',
  address: '',
  occLevelLife: '',
  occLevelAccident: '',
  occLevelHealth: '',
  tpdExposure: '',
  medicalReport: ''
});  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  
  // Controls Modal Visibility
  const [openModal, setOpenModal] = useState(false);
  const [comments, setComments] = useState('');

  // --- NEW STATE VARIABLES ---
  // 1. Risk Dropdown States
  const [riskValues, setRiskValues] = useState({
    life: '',
    accident: '',
    health: '',
    smokingStatus: '',
    alcoholConsumption: '',
    occupation: '',
    lifestyle: '',
    travel: '',
    familyHistory: '',
    healthImpairments: '',
    medicalImpairments: '',
    mentalHealthHistory: '',
    prescriptionDrugHistory: '',
    drivingHistory: '',
    criminalHistory: ''
  });

  // 2. Table Data and Selection States
  const [policyList, setPolicyList] = useState<PolicyRow[]>([]);
  const [selectedPolicyIds, setSelectedPolicyIds] = useState<string[]>([]);

  useEffect(() => {
    if (!txnTypeId) {
      setLoading(false);
      return;
    }

    const fetchData = async () => {
      setLoading(true);
      try {
        const response = await axios.get<ApiRecord[]>('http://localhost:8001/eapp/getAll');
        const allRecords = response.data;
        const matchingRecords = allRecords.filter(item => item.quotation_id === txnTypeId);

        if (matchingRecords.length === 0) {
            // setCaseData(null);
            return;
        }

        const screens: { [key: number]: any } = {};
        let creationTime = '';

        matchingRecords.forEach(rec => {
            if (!creationTime || new Date(rec.creation_TIME) > new Date(creationTime)) {
                creationTime = rec.creation_TIME;
            }
            const currentStored = screens[rec.screen_No];
            if (!currentStored || rec.version_NO > currentStored.version_NO) {
                try {
                    const parsedData = typeof rec.json_DATA === 'string' ? JSON.parse(rec.json_DATA) : rec.json_DATA;
                    screens[rec.screen_No] = { ...rec, parsedData };
                } catch (e) {
                    console.error(`Error parsing JSON for Screen ${rec.screen_No}`, e);
                }
            }
        });

        const s1 = screens[1]?.parsedData || {};
        const s2 = screens[2]?.parsedData || {};
        const s3 = screens[3]?.parsedData || {};
        const s10 = screens[10]?.parsedData || {};

        const calculateAge = (dob: string) => {
          if (!dob) return '-';
          const today = dayjs();
          const birthDate = dayjs(dob);
          return today.diff(birthDate, 'year').toString();
        };

        const mapped: UnderwritingCase = {
          uwCode: `UW-${txnTypeId}`,
          creationDate: creationTime ? dayjs(creationTime).format('DD MMM YYYY') : '-',
          applicantName: `${s1.insuredFirstName || ''} ${s1.insuredSurName || ''}`.trim() || 'Unknown',
          serviceType: 'New Business',
          appNumber: txnTypeId,
          policyNumber: 'PENDING-001', 
          agentCode: 'AG-1029 (Direct)', 
          branch: 'Head Office',
          productName: s2.basicPlan || 'General Life Plan',
          email: s1.emailAddress || '-',
          mobile: s1.primaryNumber || s1.workPhoneNumber || '-',
          dob: s1.insuredDateOfBirth ? dayjs(s1.insuredDateOfBirth).format('DD/MM/YYYY') : '-',
          gender: s1.insuredGender || '-',
          age: calculateAge(s1.insuredDateOfBirth),
          weight: '83',
          height: '174',
          bmi: '27.40',
          heightWeight: 'N/A', 
          occupation: s1.occupationCode || s1.occupationDetail || 'N/A',
          income: s1.annualIncome ? `INR ${Number(s1.annualIncome).toLocaleString()}` : '-',
          sumAssured: s2.basicSumInsured ? `${Number(s2.basicSumInsured).toLocaleString()}` : '0',
          premium: (s10.annualPremium || s3.AmountOfPaymentWithThisApplication) ? `${Number(s10.annualPremium || s3.AmountOfPaymentWithThisApplication).toLocaleString()}` : '0',
          address: s1.regFullAddr || `${s1.regAddrNum || ''} ${s1.regAddrStrNum || ''} ${s1.regAddrProvince || ''}`.trim(),
          occLevelLife: 'Class 1',
          occLevelAccident: 'Class 1',
          occLevelHealth: 'Standard',
          tpdExposure: 'Low',
          medicalReport: 'Pending Review'
        };

        setCaseData(mapped);
        setWeight('83');
        setHeight('174');

        // Initialize Risk Dropdowns from data
        setRiskValues({
            life: mapped.occLevelLife,
            accident: mapped.occLevelAccident,
            health: mapped.occLevelHealth,
            smokingStatus: 'Non-smoker',
            alcoholConsumption: 'Non-drinker',
            occupation: 'No hazardous Occupation',
            lifestyle: 'Low-risk lifestyle',
            travel: 'No Frequent travel',
            familyHistory: 'clean family history',
            healthImpairments: 'No Health Impairments',
            medicalImpairments: 'No medical Impairments',
            mentalHealthHistory: 'No Mental Health History',
            prescriptionDrugHistory: 'No Prescription Drug History',
            drivingHistory: 'Clean Driving Record',
            criminalHistory: 'No Criminal History'
        });

        // Initialize Policy List (Simulating a list based on the single case)
        setPolicyList([{
            id: 'POL-001',
            productName: mapped.productName,
            sumAssured: mapped.sumAssured,
            premium: mapped.premium,
            status: 'Pending'
        }]);

      } catch (error) {
        console.error("Error fetching details", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [txnTypeId]);

  const calculateBMI = (weightKg: string, heightCm: string): string => {
    const w = parseFloat(weightKg);
    const h = parseFloat(heightCm) / 100; // Convert cm to meters
    if (w > 0 && h > 0) {
      const bmi = w / (h * h);
      return bmi.toFixed(2);
    }
    return '';
  };

  const handleWeightChange = (value: string) => {
    setWeight(value);
    if (caseData) {
      const newBMI = calculateBMI(value, height);
      setCaseData({ ...caseData, weight: value, bmi: newBMI });
    }
  };

  const handleHeightChange = (value: string) => {
    setHeight(value);
    if (caseData) {
      const newBMI = calculateBMI(weight, value);
      setCaseData({ ...caseData, height: value, bmi: newBMI });
    }
  };

  const handleDecisionSubmit = (data: any) => {
    console.log("Decision from Modal:", data);
  };

  // --- Handlers for Selection ---
  const handleSelectAllClick = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.checked) {
      const newSelecteds = policyList.map((n) => n.id);
      setSelectedPolicyIds(newSelecteds);
      return;
    }
    setSelectedPolicyIds([]);
  };

  const handleRowClick = (id: string) => {
    const selectedIndex = selectedPolicyIds.indexOf(id);
    let newSelected: string[] = [];

    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selectedPolicyIds, id);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selectedPolicyIds.slice(1));
    } else if (selectedIndex === selectedPolicyIds.length - 1) {
      newSelected = newSelected.concat(selectedPolicyIds.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selectedPolicyIds.slice(0, selectedIndex),
        selectedPolicyIds.slice(selectedIndex + 1),
      );
    }
    setSelectedPolicyIds(newSelected);
  };

  const isSelected = (id: string) => selectedPolicyIds.indexOf(id) !== -1;

  // --- PREPARE DATA FOR MODAL ---
  // This maps the selected rows from the parent table to the detailed format needed for the modal
  const policiesForModal: PolicyProduct[] = policyList
    .filter(policy => selectedPolicyIds.includes(policy.id))
    .map((policy, index) => ({
        id: policy.id,
        sequence: (100 + index).toString(), // Mock sequence
        code: '6968', // Mock code
        name: policy.productName,
        insured: caseData?.applicantName || 'Unknown',
        inceptionDate: dayjs().add(1, 'year').format('YYYY-MM-DD'), // Mock inception
        nextPaymentDate: '',
        status: 'Underwriting Postponed', // Mock status
        // Financials
        laySumAssured: policy.sumAssured,
        targetPremium: policy.premium,
        em: '0',
        perMille: '0',
        increaseRate: '0.0',
        decision: 'Conditional Underwritten',
        finishStatus: 'Finished'
    }));

  // --- Render Helpers ---
  if (loading) return <Box sx={{ p: 5, textAlign: 'center' }}><CircularProgress /></Box>;
  // if (!caseData) return <Box sx={{ p: 3 }}><Typography>No records found.</Typography><Button startIcon={<ArrowBack />} onClick={() => navigate('/underwriting')}>Back</Button></Box>;

  const SectionHeader = ({ title, icon }: { title: string, icon: React.ReactNode }) => (
    <Box sx={{ display: 'flex', alignItems: 'center', mb: 2, mt: 4, pb: 1, borderBottom: '1px solid #e0e0e0' }}>
      <Box sx={{ color: 'primary.main', mr: 1, display: 'flex' }}>{icon}</Box>
      <Typography variant="h6" fontWeight="bold" color="text.primary">{title}</Typography>
    </Box>
  );

  const InfoRow = ({ label, value }: { label: string, value: string | React.ReactNode }) => (
    <Grid item xs={12} sm={6} md={3}>
      <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 0.5, textTransform: 'uppercase', fontSize: '0.7rem', letterSpacing: '0.5px' }}>{label}</Typography>
      <Typography variant="body2" fontWeight="500">{value}</Typography>
    </Grid>
  );

  return (
    <Box sx={{ p: 3, maxWidth: 1400, margin: 'auto', backgroundColor: '#f4f6f8', minHeight: '100vh' }}>
      
      {/* Top Nav */}
      <Stack direction="row" alignItems="center" spacing={2} sx={{ mb: 3 }}>
        <IconButton onClick={() => navigate('/underwriting')} sx={{ bgcolor: 'white', border: '1px solid #ccc' }}><ArrowBack /></IconButton>
        <Box>
          <Typography variant="h5" fontWeight="bold" color="text.primary">Underwriting Details</Typography>
          <Typography variant="body2" color="text.secondary">Reviewing Application: {txnTypeId}</Typography>
        </Box>
      </Stack>

      {/* 1. Header Info */}
      <Paper elevation={0} sx={{ p: 3, borderRadius: 2, border: '1px solid #e0e0e0' }}>
        <Grid container spacing={3}>
          <InfoRow label="Underwriting Code" value={caseData.uwCode} />
          <InfoRow label="Creation Date" value={caseData.creationDate} />
          <InfoRow label="Applicant Name" value={caseData.applicantName} />
          <InfoRow label="Service Type" value={<Chip label={caseData.serviceType} color="primary" size="small" variant="outlined"/>} />
        </Grid>
      </Paper>

      {/* 2. Basic Info */}
      <SectionHeader title="Policy / Application Basic Info" icon={<Assignment />} />
      <Paper elevation={1} sx={{ p: 3, borderRadius: 2 }}>
        <Grid container spacing={3}>
          <InfoRow label="Application No." value={caseData.appNumber} />
          <InfoRow label="Policy No." value={caseData.policyNumber} />
          <InfoRow label="Agent Code" value={caseData.agentCode} />
          <InfoRow label="Branch" value={caseData.branch} />
          <InfoRow label="Product Name" value={caseData.productName} />
          <InfoRow label="Email" value={caseData.email} />
          <InfoRow label="Mobile" value={caseData.mobile} />
        </Grid>
      </Paper>

      {/* 3. Application & Lifestyle Information */}
      <SectionHeader title="Application & Lifestyle Information" icon={<Person />} />
      <Paper elevation={1} sx={{ borderRadius: 2 }}>
        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">Personal Information</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Grid container spacing={3}>
              <InfoRow label="Full Name" value={caseData.applicantName} />
              <InfoRow label="DOB" value={caseData.dob} />
              <InfoRow label="Gender" value={caseData.gender} />
              <InfoRow label="Age" value={caseData.age} />
              <Grid item xs={12} sm={6} md={3}>
                <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 0.5, textTransform: 'uppercase', fontSize: '0.7rem', letterSpacing: '0.5px' }}>Weight (kg)</Typography>
                <TextField
                  size="small"
                  type="number"
                  value={weight}
                  onChange={(e) => handleWeightChange(e.target.value)}
                  placeholder="Enter weight"
                  sx={{ width: '100%' }}
                />
              </Grid>
              <Grid item xs={12} sm={6} md={3}>
                <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 0.5, textTransform: 'uppercase', fontSize: '0.7rem', letterSpacing: '0.5px' }}>Height (cm)</Typography>
                <TextField
                  size="small"
                  type="number"
                  value={height}
                  onChange={(e) => handleHeightChange(e.target.value)}
                  placeholder="Enter height"
                  sx={{ width: '100%' }}
                />
              </Grid>
              <InfoRow label="BMI" value={caseData.bmi || '-'} />
              <InfoRow label="Occupation" value={caseData.occupation} />
              <InfoRow label="Income" value={caseData.income} />
              <InfoRow label="Sum Assured" value={`INR ${caseData.sumAssured}`} />
              <InfoRow label="Premium" value={`INR ${caseData.premium}`} />
              <Grid item xs={12}>
                <Divider sx={{ my: 1 }} />
                <Typography variant="caption" color="text.secondary" sx={{ textTransform: 'uppercase', fontSize: '0.7rem' }}>Permanent Address</Typography>
                <Typography variant="body2">{caseData.address}</Typography>
              </Grid>
            </Grid>
          </AccordionDetails>
        </Accordion>

        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">Lifestyle & Habits</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Grid container spacing={3}>
              <Grid item xs={12} sm={6} md={4}>
                <FormControl fullWidth size="small">
                    <InputLabel>Smoking Status</InputLabel>
                    <Select 
                        value={riskValues.smokingStatus} 
                        label="Smoking Status"
                        onChange={(e) => setRiskValues({...riskValues, smokingStatus: e.target.value})}
                    >
                        <MenuItem value="Smoker">Smoker</MenuItem>
                        <MenuItem value="Non-smoker">Non-smoker</MenuItem>
                    </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <FormControl fullWidth size="small">
                    <InputLabel>Alcohol Consumption</InputLabel>
                    <Select 
                        value={riskValues.alcoholConsumption} 
                        label="Alcohol Consumption"
                        onChange={(e) => setRiskValues({...riskValues, alcoholConsumption: e.target.value})}
                    >
                        <MenuItem value="Non-drinker">Non-drinker</MenuItem>
                        <MenuItem value="Heavy">Heavy</MenuItem>
                    </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <FormControl fullWidth size="small">
                    <InputLabel>Lifestyle</InputLabel>
                    <Select 
                        value={riskValues.lifestyle} 
                        label="Lifestyle"
                        onChange={(e) => setRiskValues({...riskValues, lifestyle: e.target.value})}
                    >
                        <MenuItem value="Low-risk lifestyle">Low-risk lifestyle</MenuItem>
                        <MenuItem value="High-risk hobbies(e.g.skydiving)">High-risk hobbies(e.g.skydiving)</MenuItem>
                    </Select>
                </FormControl>
              </Grid>
            </Grid>
          </AccordionDetails>
        </Accordion>

        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">Occupation & Travel</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Grid container spacing={3}>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth size="small">
                    <InputLabel>Occupation</InputLabel>
                    <Select 
                        value={riskValues.occupation} 
                        label="Occupation"
                        onChange={(e) => setRiskValues({...riskValues, occupation: e.target.value})}
                    >
                        <MenuItem value="No hazardous Occupation">No hazardous Occupation</MenuItem>
                        <MenuItem value="Hazardous Occupation">Hazardous Occupation</MenuItem>
                        <MenuItem value="Offshore Oil Rig Worker">Offshore Oil Rig Worker</MenuItem>
                        <MenuItem value="Commercial Pilot">Commercial Pilot</MenuItem>
                        <MenuItem value="Deep-sea Diver">Deep-sea Diver</MenuItem>
                    </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth size="small">
                    <InputLabel>Travel Risk</InputLabel>
                    <Select 
                        value={riskValues.travel} 
                        label="Travel Risk"
                        onChange={(e) => setRiskValues({...riskValues, travel: e.target.value})}
                    >
                        <MenuItem value="No Frequent travel">No Frequent travel</MenuItem>
                        <MenuItem value="Frequent travel to High-Risk Countries">Frequent travel to High-Risk Countries</MenuItem>
                        <MenuItem value="Permanent residence in conflict zone">Permanent residence in conflict zone</MenuItem>
                        <MenuItem value="Frequent missionary trips to epidemic-prone regions">Frequent missionary trips to epidemic-prone regions</MenuItem>
                    </Select>
                </FormControl>
              </Grid>
            </Grid>
          </AccordionDetails>
        </Accordion>

        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">Criminal History</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Grid container spacing={3}>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth size="small">
                    <InputLabel>Criminal History</InputLabel>
                    <Select 
                        value={riskValues.criminalHistory} 
                        label="Criminal History"
                        onChange={(e) => setRiskValues({...riskValues, criminalHistory: e.target.value})}
                    >
                        <MenuItem value="No Criminal History">No Criminal History</MenuItem>
                        <MenuItem value="Minor Offenses">Minor Offenses</MenuItem>
                        <MenuItem value="Felony Convictions">Felony Convictions</MenuItem>
                        <MenuItem value="Financial Crimes">Financial Crimes</MenuItem>
                        <MenuItem value="Drug-related Offenses">Drug-related Offenses</MenuItem>
                        <MenuItem value="Violent Crimes">Violent Crimes</MenuItem>
                    </Select>
                </FormControl>
              </Grid>
            </Grid>
          </AccordionDetails>
        </Accordion>

        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">Motor Vehicle Report</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Grid container spacing={3}>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth size="small">
                    <InputLabel>Driving History</InputLabel>
                    <Select 
                        value={riskValues.drivingHistory} 
                        label="Driving History"
                        onChange={(e) => setRiskValues({...riskValues, drivingHistory: e.target.value})}
                    >
                        <MenuItem value="Clean Driving Record">Clean Driving Record</MenuItem>
                        <MenuItem value="DUIs">DUIs</MenuItem>
                        <MenuItem value="reckless driving infractions">reckless driving infractions</MenuItem>
                    </Select>
                </FormControl>
              </Grid>
            </Grid>
          </AccordionDetails>
        </Accordion>
      </Paper>

      {/* 4. Medical and Health */}
      <SectionHeader title="Medical and Health" icon={<LocalHospital />} />
      <Paper elevation={1} sx={{ borderRadius: 2 }}>
        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">Medical History</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Grid container spacing={3}>
              <Grid item xs={12} sm={6} md={4}>
                <FormControl fullWidth size="small">
                    <InputLabel>Family History</InputLabel>
                    <Select 
                        value={riskValues.familyHistory} 
                        label="Family History"
                        onChange={(e) => setRiskValues({...riskValues, familyHistory: e.target.value})}
                    >
                        <MenuItem value="clean family history">clean family history</MenuItem>
                        <MenuItem value="Early-onset cardiac disease in parent (<60 yrs)">Early-onset cardiac disease in parent (&lt;60 yrs)</MenuItem>
                    </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <FormControl fullWidth size="small">
                    <InputLabel>Health Impairments</InputLabel>
                    <Select 
                        value={riskValues.healthImpairments} 
                        label="Health Impairments"
                        onChange={(e) => setRiskValues({...riskValues, healthImpairments: e.target.value})}
                    >
                        <MenuItem value="No Health Impairments">No Health Impairments</MenuItem>
                        <MenuItem value="Controlled Hypertension">Controlled Hypertension</MenuItem>
                        <MenuItem value="Diabetes(Type 2, Controlled)">Diabetes(Type 2, Controlled)</MenuItem>
                    </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <FormControl fullWidth size="small">
                    <InputLabel>Medical Impairments</InputLabel>
                    <Select 
                        value={riskValues.medicalImpairments} 
                        label="Medical Impairments"
                        onChange={(e) => setRiskValues({...riskValues, medicalImpairments: e.target.value})}
                    >
                        <MenuItem value="No medical Impairments">No medical Impairments</MenuItem>
                        <MenuItem value="Hypertension(Uncontrolled)">Hypertension(Uncontrolled)</MenuItem>
                        <MenuItem value="Diabetes Type 1">Diabetes Type 1</MenuItem>
                        <MenuItem value="Chronic Kidney Disease(Stage-3)">Chronic Kidney Disease(Stage-3)</MenuItem>
                        <MenuItem value="Chronic Obstructive Pulmonary Disease(COPD)">Chronic Obstructive Pulmonary Disease(COPD)</MenuItem>
                        <MenuItem value="Cancer History(Remission < 5 years)">Cancer History(Remission &lt; 5 years)</MenuItem>
                        <MenuItem value="Liver Cirrhosis">Liver Cirrhosis</MenuItem>
                        <MenuItem value="HIV Positive">HIV Positive</MenuItem>
                        <MenuItem value="Stroke History">Stroke History</MenuItem>
                    </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <FormControl fullWidth size="small">
                    <InputLabel>Mental Health History</InputLabel>
                    <Select 
                        value={riskValues.mentalHealthHistory} 
                        label="Mental Health History"
                        onChange={(e) => setRiskValues({...riskValues, mentalHealthHistory: e.target.value})}
                    >
                        <MenuItem value="No Mental Health History">No Mental Health History</MenuItem>
                        <MenuItem value="Severe depression">Severe depression</MenuItem>
                    </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 0.5, textTransform: 'uppercase', fontSize: '0.7rem', letterSpacing: '0.5px' }}>Medical Report</Typography>
                <Typography variant="body2" fontWeight="500">{caseData.medicalReport}</Typography>
              </Grid>
            </Grid>
          </AccordionDetails>
        </Accordion>

        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">Prescription Drug History</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Grid container spacing={3}>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth size="small">
                    <InputLabel>Prescription Drug History</InputLabel>
                    <Select 
                        value={riskValues.prescriptionDrugHistory} 
                        label="Prescription Drug History"
                        onChange={(e) => setRiskValues({...riskValues, prescriptionDrugHistory: e.target.value})}
                    >
                        <MenuItem value="No Prescription Drug History">No Prescription Drug History</MenuItem>
                        <MenuItem value="Accessing prescription history reports to confirm medical conditions and adherence to treatment">Accessing prescription history reports to confirm medical conditions and adherence to treatment</MenuItem>
                    </Select>
                </FormControl>
              </Grid>
            </Grid>
          </AccordionDetails>
        </Accordion>
      </Paper>

      {/* 5. Risk Assessment */}
      <SectionHeader title="Risk Assessment" icon={<LocalHospital />} />
      <Paper elevation={1} sx={{ borderRadius: 2 }}>
        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">Occupation Risk Levels</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Grid container spacing={3}>
              <Grid item xs={12} sm={6} md={4}>
                <FormControl fullWidth size="small">
                    <InputLabel>Life Occ. Level</InputLabel>
                    <Select 
                        value={riskValues.life} 
                        label="Life Occ. Level"
                        onChange={(e) => setRiskValues({...riskValues, life: e.target.value})}
                    >
                        <MenuItem value="Class 1">Class 1</MenuItem>
                        <MenuItem value="Class 2">Class 2</MenuItem>
                        <MenuItem value="Class 3">Class 3</MenuItem>
                        <MenuItem value="Class 4">Class 4</MenuItem>
                        <MenuItem value="Standard">Standard</MenuItem>
                    </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                 <FormControl fullWidth size="small">
                    <InputLabel>Accident Occ. Level</InputLabel>
                    <Select 
                        value={riskValues.accident} 
                        label="Accident Occ. Level"
                        onChange={(e) => setRiskValues({...riskValues, accident: e.target.value})}
                    >
                        <MenuItem value="Class 1">Class 1</MenuItem>
                        <MenuItem value="Class 2">Class 2</MenuItem>
                        <MenuItem value="Class 3">Class 3</MenuItem>
                        <MenuItem value="Standard">Standard</MenuItem>
                        <MenuItem value="Declined">Declined</MenuItem>
                    </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6} md={4}>
                <FormControl fullWidth size="small">
                    <InputLabel>Health Occ. Level</InputLabel>
                    <Select 
                        value={riskValues.health} 
                        label="Health Occ. Level"
                        onChange={(e) => setRiskValues({...riskValues, health: e.target.value})}
                    >
                        <MenuItem value="Standard">Standard</MenuItem>
                        <MenuItem value="Sub-Standard A">Sub-Standard A</MenuItem>
                        <MenuItem value="Sub-Standard B">Sub-Standard B</MenuItem>
                        <MenuItem value="Declined">Declined</MenuItem>
                    </Select>
                </FormControl>
              </Grid>
            </Grid>
          </AccordionDetails>
        </Accordion>
      </Paper>

      {/* 6. Policy Table */}
      <SectionHeader title="Policy Details" icon={<Assessment />} />
      <TableContainer component={Paper} elevation={1} sx={{ borderRadius: 2 }}>
        <Table size="small">
          <TableHead sx={{ bgcolor: '#f5f5f5' }}>
            <TableRow>
              {/* Select All Checkbox */}
              <TableCell padding="checkbox">
                <Checkbox
                  color="primary"
                  indeterminate={selectedPolicyIds.length > 0 && selectedPolicyIds.length < policyList.length}
                  checked={policyList.length > 0 && selectedPolicyIds.length === policyList.length}
                  onChange={handleSelectAllClick}
                  inputProps={{ 'aria-label': 'select all policies' }}
                />
              </TableCell>
              <TableCell><strong>Product Name</strong></TableCell>
              <TableCell><strong>Sum Assured</strong></TableCell>
              <TableCell><strong>Annual Premium</strong></TableCell>
              <TableCell><strong>UW Decision</strong></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {policyList.map((row) => {
                const isItemSelected = isSelected(row.id);
                return (
                    <TableRow 
                        key={row.id} 
                        hover
                        role="checkbox"
                        aria-checked={isItemSelected}
                        selected={isItemSelected}
                    >
                        {/* Row Checkbox */}
                        <TableCell padding="checkbox">
                            <Checkbox
                                color="primary"
                                checked={isItemSelected}
                                onClick={() => handleRowClick(row.id)}
                            />
                        </TableCell>
                        <TableCell>{row.productName}</TableCell>
                        <TableCell>{row.sumAssured}</TableCell>
                        <TableCell>{row.premium}</TableCell>
                        <TableCell><Typography color="orange" fontWeight="bold">{row.status}</Typography></TableCell>
                    </TableRow>
                );
            })}
            {policyList.length === 0 && (
                <TableRow>
                    <TableCell colSpan={5} align="center">No policies found</TableCell>
                </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>

{/* 7. Quick Action / Open Modal */}
<SectionHeader title="Underwriting Action" icon={<Gavel />} />
<Paper elevation={3} sx={{ p: 4, mb: 5, borderRadius: 2, borderLeft: '6px solid #1976d2' }}>
  <Grid container spacing={3}>
    <Grid item xs={12} md={8}>
      <TextField 
        fullWidth 
        label="Quick Comments / Notes" 
        multiline 
        rows={2} 
        placeholder="Enter internal remarks..."
        value={comments}
        onChange={(e) => setComments(e.target.value)}
      />
    </Grid>
    <Grid item xs={12} display="flex" justifyContent="flex-end" gap={2} mt={1}>
      <Button 
        variant="outlined" 
        size="large" 
        onClick={() => setOpenModal(true)}
        disabled={selectedPolicyIds.length === 0}
      >
        Underwriting Decision
      </Button>
      <Button variant="contained" size="large" onClick={() => {}}>
        Underwritten
      </Button>
    </Grid>
  </Grid>
</Paper>

{/* INTEGRATED MODAL */}
<DecisionModal 
  open={openModal} 
  onClose={() => setOpenModal(false)} 
  selectedPolicies={policiesForModal} 
  onSubmit={handleDecisionSubmit}
/>

{/* ================= BOTTOM ACTION BUTTONS ================= */}
<Paper sx={{ p: 2, mt: 3 }}>
  <Stack direction="row" spacing={2} justifyContent="flex-end">

    <Button
      variant="outlined"
      onClick={() => navigate('/underwriting')}
    >
      Back
    </Button>

    <Button
      variant="contained"
      color="primary"
      onClick={() => {
        console.log('Save clicked');
      }}
    >
      Save
    </Button>

    <Button
      variant="contained"
      color="primary"
      disabled={!txnTypeId}
      onClick={() => navigate(`/underwriting/${txnTypeId}/requirements`)}
    >
      Next
    </Button>

  </Stack>
</Paper>

</Box>
);
};

export default UnderwritingDetails;