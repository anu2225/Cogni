import axios from "../../api/axiosInterceptor";

axios.defaults.baseURL="http://localhost:8001/eapp/dropdown";

const getCoutries = async () =>{
    const url="/getCoutries"
    return await axios.get(url);
}

const getState = async (country  : string) =>{
    const url=`/getStates?country=${country}`
    return await axios.get(url);
}

const getDistrict = async (state : string) =>{
    const url=`/getDistrict?state=${state}`
    return await axios.get(url);
}

const getBanks = async () =>{
    const url=`/getBanks`
    return await axios.get(url);
}

const getBankBranch = async (bank : string) =>{
    const url=`/getBankBranch?bank=${bank}`
    return await axios.get(url);
}

const getEvidenceProof = async() => {
    const url = `/getEvidenceProof`
    return await axios.get(url);
}

const getOccupationCode = async() => {
    const url = `/getOccupationCode`
    return await axios.get(url);
}

const getMaritalStatus = async() => {
    const url = `/getMaritalStatus`
    return await axios.get(url);
}

const getFamilyMemberType = async() => {
    const url = `/getFamilyMemberType`
    return await axios.get(url);
}

const getBeneficiaryRelation = async() => {
    const url = `/getBeneficiaryRelation`
    return await axios.get(url);
}

const getInsuredData = async () =>{
    // const url="/getCoutries"
    return {
        data: {
         "insuredFirstName": "Priyanka",
         "insuredNationality": "India",
        "insuredLastName": "Sen",
        "insuredAge": "30",
        "insuredGender": "Female",
        "insuredDob": "01/24/1998",
        "insuredTitle": "MS",
        "insuredCurAddrLine1": "222/1",
        "insuredCurAddrLine2": "A.B. Street",
        "insuredCurVilla": "Villa-A",
        "insuredCurAlley": "XYZ",
        "insuredCurPin": "700001",
        "insuredCurMobile": "9838776366"
        }
      };
}

export {getCoutries, getState,getDistrict, getBanks, getBankBranch,getEvidenceProof,getOccupationCode,getMaritalStatus,getFamilyMemberType,getBeneficiaryRelation,getInsuredData};