import { MenuItem, Select, SelectChangeEvent } from "@mui/material";
import "bootstrap/dist/js/bootstrap.js";
import React from "react";

interface IDropdownProps{
  label?: string;
  options: any[];
  value?: string;
  onChange?: (event: SelectChangeEvent<string>,child: React.ReactNode) => void;
  customValueKey?: string;
}

export const Dropdown : React.FC<IDropdownProps> = ({
  label, options, value, onChange, customValueKey 
}) =>  {
  return (
    <div>
      <Select size="small" variant="standard" value={value} onChange={onChange} displayEmpty>
        <MenuItem value="" disabled>
          Select {label}
        </MenuItem>
        {options.map((opt) => {
          if (typeof opt === "string") {
            return(
               <MenuItem key={opt} value={opt}>{opt}</MenuItem>
               );
          } else {
            const data = customValueKey ? opt[customValueKey] : opt.value;
            return (
            <MenuItem key={data} value={data}>{data}</MenuItem>);
          }
        })}
      </Select>
    </div>
  );
};
