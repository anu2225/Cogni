import {
  Box,
  Checkbox,
  Divider,
  FormControlLabel,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableRow,
  TextField,
  ToggleButton,
  ToggleButtonGroup,
  Typography,
  tableCellClasses,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { useTranslation } from "react-i18next";
import Camera from "./Camera";
import dayjs, { Dayjs } from "dayjs";
import { Dropdown } from "./Dropdown/Dropdown";
import { getCoutries, getDistrict, getEvidenceProof, getOccupationCode, getState,getMaritalStatus,getFamilyMemberType,getInsuredData } from "./Dropdown/DropdownApi";
import { DateField } from "@mui/x-date-pickers";
import "../styles.css"



interface ChildComponentProps {
  fields: {
    insuredNationality: string;
    insuredEvidenceOfProof: string;
    insuredIdNumber: string;
    customerIdEbao: number;
    insuredIdExpiryDate: dayjs.Dayjs;
    insuredTitle: string;
    insuredFirstName: string;
    insuredSurName: string;
    insuredDateOfBirth: dayjs.Dayjs;
    insuredGender : string;
    insuredAge: string;

    insuredProvince: string;
    insuredDistrict: string;
    imgURL: string;
    workplaceAddressOptn: string;
    currentAddressOptn: string;
    insContactAddressIndicator: string;
    motorcycleOptn: string;
    regAddrNum: string;
    regAddrVilla: string;
    regAddrMooNum: string;
    regAddrAlley: string;
    regAddrStrNum: string;
    regAddrSubDist: string;
    regAddrZipCode: string;
    regFullAddr:string;
    familyMemberType: string;
    insuredMritalStatus: string;

    workCompanyName:string;
    workAddrNum: string;
    workAddrVilla: string;
    workAddrMooNum: string;
    workAddrAlley: string;
    workAddrStrNum: string;
    insuredWorkProvince: string;
    insuredWorkDistrict: string;
    workAddrSubDist: string;
    workAddrZipCode: string;
    workFullAddress: string;

    cRegAddNum: string;
    cRegAddVilla: string;
    cRegAddMoo: string;
    cRegAddAlley: string;
    cRegAddStrNum: string;
    cRegAddProvince: string;
    cRegAddDist: string;
    cRegAddSubDis: string;
    cRegAddZipCode: string;
    contactFullAddr: string;

    primaryNumber: string;
    homeNumber: string;
    workPhoneNumber: string;
    emailAddress: string;

    occupationCode:string;
    positionHeld: string;
    occupationDetail: string;
    businessDetail: string;
    annualIncome: string;
    otherOccupation: string;
  };
  setFields: React.Dispatch<
    React.SetStateAction<{
      insuredNationality: string;
      insuredEvidenceOfProof: string;
      insuredIdNumber: string;
      customerIdEbao: number;
      insuredIdExpiryDate: dayjs.Dayjs;
      insuredTitle: string;
      insuredFirstName: string;
      insuredSurName: string;
      insuredDateOfBirth: dayjs.Dayjs;
      insuredGender : string;
      insuredAge: string;
      insuredProvince: string;
      insuredDistrict: string;
      imgURL: string;
      workplaceAddressOptn: string;
      currentAddressOptn: string;
      insContactAddressIndicator: string;
      motorcycleOptn: string;
      regAddrNum: string;
      regAddrVilla: string;
      regAddrMooNum: string;
      regAddrAlley: string;
      regAddrStrNum: string;
      regAddrSubDist: string;
      regAddrZipCode: string;
      regFullAddr:string;
      familyMemberType: string;
      insuredMritalStatus: string;

      workCompanyName:string;
      workAddrNum: string;
      workAddrVilla: string;
      workAddrMooNum: string;
      workAddrAlley: string;
      workAddrStrNum: string;
      insuredWorkProvince: string;
      insuredWorkDistrict: string;
      workAddrSubDist: string;
      workAddrZipCode: string;
      workFullAddress: string;

      cRegAddNum: string;
      cRegAddVilla: string;
      cRegAddMoo: string;
      cRegAddAlley: string;
      cRegAddStrNum: string;
      cRegAddProvince: string;
      cRegAddDist: string;
      cRegAddSubDis: string;
      cRegAddZipCode: string;
      contactFullAddr: string;

      primaryNumber: string;
      homeNumber: string;
      workPhoneNumber: string;
      emailAddress: string;
      occupationCode:string;

      positionHeld: string;
      occupationDetail: string;
      businessDetail: string;
      annualIncome: string;
      otherOccupation: string;
    }>
  >;
  savedTransaction: any;
}

const LifeAssuredDetail: React.FC<ChildComponentProps> = ({
  fields,
  setFields,
  savedTransaction,
}) => {
  const handleFieldChange = (
    val: string,
    fieldName: string,
    imgURL?: string
  ) => {
    const newFields = { ...fields, [fieldName]: val };
    if (imgURL !== undefined) {
      newFields["imgURL"] = imgURL;
    }
    setFields({ ...newFields });
    console.log("After ==>", newFields);
  };

  const handleDateChange = (date: dayjs.Dayjs | null, fieldName: string) => {
    setFields({ ...fields, [fieldName]: date });
  };

  const handleButtonChange = (
    event: React.MouseEvent<HTMLElement>,
    fieldName: string
  ) => {
    console.log(event.currentTarget.textContent);
    const stateVal = event.currentTarget.textContent;
    setFields((fields) => ({ ...fields, [fieldName]: stateVal }));
  };

  const { t } = useTranslation();

  useEffect(() => {
    if (savedTransaction && savedTransaction.length > 0) {
      const nameLI = savedTransaction[0]?.txn_input_json?.Name_LI;
      const genderLI = savedTransaction[0]?.txn_input_json?.Gender_LI;
      const ageLI = savedTransaction[0]?.txn_input_json?.Age_LI;
      // const term = savedTransaction[0]?.txn_input_json["SSPP.Policy_Term"];
      const dob = savedTransaction[0]?.txn_input_json?.DOB_LI;
      setFields((prevFields) => ({
        ...prevFields,
        insuredFirstName : nameLI,
        insuredGender : genderLI,
        insuredAge:ageLI,
        insuredDateOfBirth:dob,

      }));
    }

  }, [savedTransaction]);

  // for dependent dropdown
  const [countries, setCountries] = useState([]);
  const [states, setStates] = useState([]);
  const [districts, setDistricts] = useState([]);
  const[evidenceProof,setEvidenceProof] = useState([]);
  const [occupationCode1,setOccupationCode1] = useState([]);
  const[marriageStatus,setMarriageStatus] = useState([]);
  const[familyMemTyp,setFamilyMemTyp] = useState([]);

  useEffect(() => {
    getFamilyMemberType().then((res) => {
      setFamilyMemTyp(res.data);
    });
  }, []);

  useEffect(() => {
    getMaritalStatus().then((res) => {
      setMarriageStatus(res.data);
    });
  }, []);

  useEffect(() => {
    getOccupationCode().then((res) => {
      setOccupationCode1(res.data);
    });
  }, []);


  useEffect(() => {
    getEvidenceProof().then((res) => {
      setEvidenceProof(res.data);
    });
  }, []);

  useEffect(() => {
    getCoutries().then((res) => {
      setCountries(res.data);
    });
  }, []);


  useEffect(() => {
    getInsuredData().then((res) => {
      console.log("Insdata ==>",res);
      const fnameLI = res.data.insuredFirstName;
      const lNameLI = res.data.insuredLastName;
      const genderLI = res.data.insuredGender;
      const ageLI = res.data.insuredAge;  
      const nationalityLI= res.data.insuredNationality;
      const titleLI= res.data.insuredTitle;
      const dobstring = res.data.insuredDob;
      const dob: Dayjs = dayjs(dobstring);
      const insCurAddr1 = res.data.insuredCurAddrLine1;
      const insCurAddr2 = res.data.insuredCurAddrLine2;
      const insCurVilla = res.data.insuredCurVilla;
      const insCurMobile = res.data.insuredCurMobile;
      const insCurAlley = res.data.insuredCurAlley;
      const insCurPin = res.data.insuredCurPin
         
      setFields((prevFields) => ({
        ...prevFields,
          insuredFirstName : fnameLI,
          insuredSurName : lNameLI,
          insuredGender : genderLI,
          insuredAge: ageLI,
          insuredNationality: nationalityLI,
          insuredTitle: titleLI,
          insuredDateOfBirth: dob,
          regAddrNum: insCurAddr1,
          regAddrVilla: insCurVilla,
          regAddrMooNum: insCurMobile,
          regAddrAlley: insCurAlley,
          regAddrZipCode: insCurPin,
          regAddrStrNum: insCurAddr2
         }));
     
    });      
     
  }, []);


  useEffect(() => {
    setStates([]);
    handleFieldChange("", "insuredProvince");
    setDistricts([]);
    getState(fields.insuredNationality).then((res) => {
      setStates(res.data);
    });
  }, [fields.insuredNationality]);

  useEffect(() => {
    setDistricts([]);
    handleFieldChange("", "insuredDistrict");
    getDistrict(fields.insuredProvince).then((res) => {
      setDistricts(res.data);
    });
  }, [fields.insuredNationality, fields.insuredProvince]);

  const [error, setError] = useState("");

  const handleEmailChange = (value: string, fieldName: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    setFields((fields) => ({ ...fields, [fieldName]: value }));

    if(fieldName === 'emailAddress'){
    if (value.trim() === "") {
      setError("Email is required");
    } else if (!emailRegex.test(value)) {
      setError("Invalid email format");
    } else {
      setError("");
    }
  }
  };

 const [priErr,setPriErr] = useState('')
 const [homeErr,setHomeErr] = useState('')
 const [workErr,setWorkErr] = useState('')


  const handlePhoneNumberChange = (value: string, fieldName: string) => {
    const phoneRegex = /^[0-9]{10}$/;
    setFields((fields) => ({ ...fields, [fieldName]: value }));
if(fieldName === 'primaryNumber'){
    if (value.trim() === "") {
      setPriErr("Phone Number is required");
    } else if (!phoneRegex.test(value)) {
      setPriErr("Invalid Phone Number format");
    } else {
      setPriErr("");
    }
  } else if (fieldName === 'homeNumber'){
    if (value.trim() === "") {
      setHomeErr("Home Phone Number is required");
    } else if (!phoneRegex.test(value)) {
      setHomeErr("Invalid Phone Number format");
    } else {
      setHomeErr("");
    }
  }
  else if (fieldName === 'workPhoneNumber'){
    if (value.trim() === "") {
      setWorkErr("Work Phone Number is required");
    } else if (!phoneRegex.test(value)) {
      setWorkErr("Invalid Phone Number format");
    } else {
      setWorkErr("");
    }
  }
  };

  return (
    <Box>
      <Paper elevation={3} sx={{ margin: 2 }}>
        <Box sx={{ padding: 2 }}>
          <Typography className="typography-main-header" 
          >
            {t("welcome_message")}
          </Typography>
          <Divider />
          <Box sx={{ marginTop: 2 }}>
            <TableContainer>
              <Table
                className="table-main"
                aria-label="table2"
              >
                <TableBody>
                  <TableRow>
                    {/* <TableCell>{t("insured_nationality")}</TableCell> */}
                    <TableCell>
                      <Dropdown
                        label={t("insured_nationality")}
                        options={countries}
                        value={fields.insuredNationality}
                        onChange={(e) =>
                          handleFieldChange(
                            e.target.value,
                            "insuredNationality"
                          )
                        }
                      />
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>{t("camera")}</TableCell>
                    <TableCell colSpan={2}>
                    {fields.imgURL !== "" && (
                        <img src={fields.imgURL} alt="Captured Image" />
                  )}
                      <Camera handleFieldChange={handleFieldChange} />
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    {/* <TableCell>{t("insured_evidence_of_proof")}</TableCell> */}
                    <TableCell>
                      <Dropdown
                        label={t("insured_evidence_of_proof")}
                        options={evidenceProof}
                        value={fields.insuredEvidenceOfProof}
                        onChange={(e) =>
                          handleFieldChange(
                            e.target.value,
                            "insuredEvidenceOfProof"
                          )
                        }
                      />
                    </TableCell>
                  {/* </TableRow>
                  <TableRow> */}
                    {/* <TableCell> */}
                      {/* {t("insured_id_number_/_passport_number")} */}
                    {/* </TableCell> */}
                    <TableCell>
                      <TextField
                        size="small"
                        label={t("insured_id_number_/_passport_number")}
                        variant="standard"
                        // fullWidth
                        value={fields.insuredIdNumber}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "insuredIdNumber")
                        }
                      ></TextField>
                    </TableCell>
                  {/* </TableRow>
                  <TableRow>
                    <TableCell>{t("insured_id_expiry_date")}</TableCell> */}
                    <TableCell>
                      <LocalizationProvider dateAdapter={AdapterDayjs}>
                        <DatePicker
                          slotProps={{ textField: { size: "small" } }}
                          name="date"
                          label={t("insured_id_expiry_date")}
                          // variant="standard"
                          // value={dayjs(new Date())}
                          value={dayjs(fields.insuredIdExpiryDate)}
                          onChange={(e) =>
                            handleDateChange(e, "insuredIdExpiryDate")
                          }
                        />
                      </LocalizationProvider>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    {/* <TableCell>{t("customer_id_in_eBao")}</TableCell> */}
                    <TableCell>
                      <TextField
                        type="number"
                        label={t("customer_id_in_eBao")}
                        size="small"
                        variant="standard"
                        value={fields.customerIdEbao}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "customerIdEbao")
                        }
                      ></TextField>
                    </TableCell>
                  {/* </TableRow>
                  <TableRow> */}
                    {/* <TableCell>{t("family_member_type")}</TableCell> */}
                    <TableCell>
                      <Dropdown
                        label={t("family_member_type")}
                        // variant="standard"
                        options={familyMemTyp}
                        value={fields.familyMemberType}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "familyMemberType")
                        }
                      />
                    </TableCell>
                  {/* </TableRow>
                  <TableRow> */}
                    {/* <TableCell>{t("insured_title")}</TableCell> */}
                    <TableCell>
                      <TextField
                        size="small"
                        label={t("insured_title")}
                        variant="standard"
                        // fullWidth
                        //label='insuredTitle'
                        value={fields.insuredTitle}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "insuredTitle")
                        }
                      />
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    {/* <TableCell>{t("insured_first_name")}</TableCell> */}
                    <TableCell>
                      <TextField
                        size="small"
                        // fullWidth
                        variant="standard"
                        label={t('insured_first_name')}
                        value={fields.insuredFirstName}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "insuredFirstName")
                        }
                      />
                    </TableCell>
                  {/* </TableRow>
                  <TableRow> */}
                    {/* <TableCell>{t("insured_surname")}</TableCell> */}
                    <TableCell>
                      <TextField
                        size="small"
                        // fullWidth
                        variant="standard"
                        label={t("insured_surname")}
                        //label='insuredTitle'
                        value={fields.insuredSurName}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "insuredSurName")
                        }
                      />
                    </TableCell>
                  {/* </TableRow>
                  <TableRow> */}
                    {/* <TableCell>{t("insured_date_of_birth")}</TableCell> */}
                    <TableCell>
                      <LocalizationProvider dateAdapter={AdapterDayjs}>
                        <DateField
                        // fullWidth
                          slotProps={{ textField: { size: "small" } }}
                          name="date"
                          readOnly
                          label={t("insured_date_of_birth")}
                          variant="standard"
                          // value={dayjs(new Date())}
                          value={dayjs(fields.insuredDateOfBirth)}
                          onChange={(e) =>
                            handleDateChange(e, "insuredDateOfBirth")
                          }
                        />
                      </LocalizationProvider>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    {/* <TableCell>{t("insured_age")}</TableCell> */}
                    <TableCell><TextField 
                    value={fields.insuredAge}
                    label={t("insured_age")}
                    variant="standard"
                    ></TextField></TableCell>
                  {/* </TableRow>
                  <TableRow> */}
                    {/* <TableCell>{t("insured_gender")}</TableCell> */}
                    <TableCell><TextField 
                    value={fields.insuredGender}
                    label={t("insured_gender")}
                    variant="standard"
                    ></TextField></TableCell>
                    {/* <TableCell><Typography>{fields.insuredGender}</Typography></TableCell> */}
                  {/* </TableRow>
                  <TableRow> */}
                    {/* <TableCell>{t("insured_marital_status")}</TableCell> */}

                    <TableCell>
                      <Dropdown
                        label={t("insured_marital_status")}
                        options={marriageStatus}
                        value={fields.insuredMritalStatus}
                        onChange={(e) =>
                          handleFieldChange(
                            e.target.value,
                            "insuredMritalStatus"
                          )
                        }
                      />
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>
                      <FormControlLabel
                        disabled
                        control={<Checkbox defaultChecked />}
                        label="Policy Owner is the insured person of this policy "
                      />
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        </Box>
      </Paper>
      <Paper elevation={3} sx={{ margin: 2 }}>
        <Box sx={{ padding: 2 }}>
          <Typography className="typography-main-header">
            {t("insured_address")}
          </Typography>
          <Divider />
          <Box sx={{ marginTop: 2 }}>
            <TableContainer>
              <Table
                className="table-main"
                aria-label="simple table"
              >
                <TableBody>
                  <TableRow>
                    {/* <TableCell>{t("registered_address_number")}</TableCell> */}
                    <TableCell>
                      <TextField
                        id="outlined-basic"
                        label = {t("registered_address_number")}
                        size="small"
                        variant="standard"
                        value={fields.regAddrNum}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "regAddrNum")
                        }
                      />
                    </TableCell>
                  {/* </TableRow>
                  <TableRow>
                    <TableCell>
                      {t("registered_address_villa/building")}
                    </TableCell> */}
                    <TableCell>
                      <TextField
                        id="outlined-basic"
                        label={t("registered_address_villa/building")}
                        size="small"
                        variant="standard"
                        value={fields.regAddrVilla}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "regAddrVilla")
                        }
                      />
                    </TableCell>
                  {/* </TableRow>
                  <TableRow>
                    <TableCell>{t("registered_address_moo_number")}</TableCell> */}
                    <TableCell>
                      <TextField
                        id="outlined-basic"
                        label={t("registered_address_moo_number")}
                        size="small"
                        variant="standard"
                        value={fields.regAddrMooNum}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "regAddrMooNum")
                        }
                      />
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    {/* <TableCell>
                      {t("registered_address_alleyway/soi")}
                    </TableCell> */}
                    <TableCell>
                      <TextField
                        id="outlined-basic"
                        label={t("registered_address_alleyway/soi")}
                        size="small"
                        variant="standard"
                        value={fields.regAddrAlley}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "regAddrAlley")
                        }
                      />
                    </TableCell>
                  {/* </TableRow>
                  <TableRow>
                    <TableCell>{t("registered_address_street")} </TableCell> */}
                    <TableCell>
                      <TextField
                        id="outlined-basic"
                        label={t("registered_address_street")}
                        size="small"
                        variant="standard"
                        value={fields.regAddrStrNum}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "regAddrStrNum")
                        }
                      />
                    </TableCell>
                  {/* </TableRow>
                  <TableRow>
                    <TableCell>{t("registered_address_province")} </TableCell> */}
                    <TableCell>
                      <Dropdown
                        label="Province"
                        options={states}
                        value={fields.insuredProvince}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "insuredProvince")
                        }
                      />
                    </TableCell>
                   </TableRow>
                  <TableRow>
                    {/*
                    <TableCell>{t("registered_address_district")}</TableCell> */}
                    <TableCell>
                      <Dropdown
                        label="District"
                        options={districts}
                        value={fields.insuredDistrict}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "insuredDistrict")
                        }
                      />
                    </TableCell>
                  {/* </TableRow>
                  <TableRow>
                    <TableCell>
                      {t("registered_address_sub_district")}
                    </TableCell> */}
                    <TableCell>
                      <TextField
                        id="outlined-basic"
                        label={t("registered_address_sub_district")}
                        size="small"
                        variant="standard"
                        value={fields.regAddrSubDist}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "regAddrSubDist")
                        }
                      />
                    </TableCell>
                  {/* </TableRow>
                  <TableRow>
                    <TableCell>{t("registered_address_zip_code")} </TableCell> */}
                    <TableCell>
                      <TextField
                        id="standard-basic"
                        label={t("registered_address_zip_code")}
                        size="small"
                        variant="standard"
                        value={fields.regAddrZipCode}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "regAddrZipCode")
                        }
                      />
                    </TableCell>
                   </TableRow>
                  <TableRow>
                    {/*
                    <TableCell>{t("registered_full_address")}</TableCell> */}
                    <TableCell>
                      <TextField
                        id="outlined-basic"
                        size="small"
                        label={t("registered_full_address")}
                        multiline
                        value={fields.regFullAddr}
                        variant="standard"
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "regFullAddr")
                        }
                      />
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        </Box>
      </Paper>
      <Paper elevation={3} sx={{ margin: 2 }}>
        <Box sx={{ padding: 2 }}>
          <Typography className="typography-main-header">
            {t("insured_address_workplace")}
          </Typography>
          <Divider />
          <Box sx={{ marginTop: 2 }}>
            <TableContainer>
              <Table
                className="table-main"
                aria-label="simple table"
              >
                <TableBody>
                  <TableRow>
                    <TableCell>{t("same_as_the_registered_address")}</TableCell>
                    <TableCell colSpan={2}>
                      <ToggleButtonGroup
                        color="primary"
                        value={fields.workplaceAddressOptn}
                        exclusive
                        fullWidth
                        onChange={(event) =>
                          handleButtonChange(event, "workplaceAddressOptn")
                        }
                        aria-label="Platform"
                      >
                        <ToggleButton value="Yes">Yes</ToggleButton>
                        <ToggleButton value="No">No</ToggleButton>
                      </ToggleButtonGroup>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    {/* <TableCell>{t("working_company_name")}</TableCell> */}
                    <TableCell>
                      <TextField
                        id="standard-basic"
                        label={t("working_company_name")}
                        size="small"
                        variant="standard"
                        value={fields.workCompanyName}
                            onChange={(e) =>
                              handleFieldChange(e.target.value, "workCompanyName")
                            }
                      />
                    </TableCell>
                  </TableRow>
                  {fields.workplaceAddressOptn === "No" && (
                    <>
                      <TableRow>
                        {/* <TableCell>{t("workplace_address_number")}</TableCell> */}
                        <TableCell>
                          <TextField
                            id="outlined-basic"
                            label={t("workplace_address_number")}
                            size="small"
                            variant="standard"
                            value={fields.workAddrNum}
                            onChange={(e) =>
                              handleFieldChange(e.target.value, "workAddrNum")
                            }
                          />
                        </TableCell>
                      {/* </TableRow>
                      <TableRow> */}
                        {/* <TableCell>
                          {t("workplace_address_villa/building")}
                        </TableCell> */}
                        <TableCell>
                          <TextField
                            id="outlined-basic"
                            label={t("workplace_address_villa/building")}
                            size="small"
                            variant="standard"
                            value={fields.workAddrVilla}
                            onChange={(e) =>
                              handleFieldChange(e.target.value, "workAddrVilla")
                            }
                          />
                        </TableCell>
                      {/* </TableRow>
                      <TableRow> */}
                        {/* <TableCell>
                          {t("workplace_address_moo_number")}
                        </TableCell> */}
                        <TableCell>
                          <TextField
                            id="outlined-basic"
                            label={t("workplace_address_moo_number")}
                            size="small"
                            variant="standard"
                            value={fields.workAddrMooNum}
                            onChange={(e) =>
                              handleFieldChange(
                                e.target.value,
                                "workAddrMooNum"
                              )
                            }
                          />
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        {/* <TableCell>
                          {t("workplace_address_alleyway/soi")}
                        </TableCell> */}
                        <TableCell>
                          <TextField
                            id="outlined-basic"
                            label={t("workplace_address_alleyway/soi")}
                            size="small"
                            variant="standard"
                            value={fields.workAddrAlley}
                            onChange={(e) =>
                              handleFieldChange(e.target.value, "workAddrAlley")
                            }
                          />
                        </TableCell>
                      {/* </TableRow>
                      <TableRow> */}
                        {/* <TableCell>{t("workplace_address_street")} </TableCell> */}
                        <TableCell>
                          <TextField
                            id="outlined-basic"
                            size="small"
                            label={t("workplace_address_street")}
                            variant="standard"
                            value={fields.workAddrStrNum}
                            onChange={(e) =>
                              handleFieldChange(
                                e.target.value,
                                "workAddrStrNum"
                              )
                            }
                          />
                        </TableCell>
                      {/* </TableRow>
                      <TableRow> */}
                        {/* <TableCell>
                          {t("workplace_address_province")}{" "}
                        </TableCell> */}
                        <TableCell>
                          <Dropdown
                            label={t("workplace_address_province")}
                            options={states}
                            value={fields.insuredWorkProvince}
                            onChange={(e) =>
                              handleFieldChange(
                                e.target.value,
                                "insuredWorkProvince"
                              )
                            }
                          />
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        {/* <TableCell>{t("workplace_address_district")}</TableCell> */}
                        <TableCell>
                          <Dropdown
                            label={t("workplace_address_district")}
                            options={districts}
                            value={fields.insuredWorkDistrict}
                            onChange={(e) =>
                              handleFieldChange(
                                e.target.value,
                                "insuredWorkDistrict"
                              )
                            }
                          />
                        </TableCell>
                      {/* </TableRow>
                      <TableRow>
                        <TableCell>
                          {t("workplace_address_sub_district")}
                        </TableCell> */}
                        <TableCell>
                          <TextField
                            id="outlined-basic"
                           label={t("workplace_address_sub_district")}
                            size="small"
                            variant="standard"
                            value={fields.workAddrSubDist}
                            onChange={(e) =>
                              handleFieldChange(
                                e.target.value,
                                "workAddrSubDist"
                              )
                            }
                          />
                        </TableCell>
                      {/* </TableRow>
                      <TableRow> */}
                        {/* <TableCell>
                          {t("workplace_address_zip_code")}{" "}
                        </TableCell> */}
                        <TableCell>
                          <TextField
                            id="outlined-basic"
                            label={t("workplace_address_zip_code")}
                            size="small"
                            variant="standard"
                            value={fields.workAddrZipCode}
                            onChange={(e) =>
                              handleFieldChange(
                                e.target.value,
                                "workAddrZipCode"
                              )
                            }
                          />
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        {/* <TableCell>{t("workplace_full_address")}</TableCell> */}
                        <TableCell>
                          <TextField
                            id="outlined-basic"
                            label={t("workplace_full_address")}
                            size="small"
                            multiline
                            value={fields.workFullAddress}
                            onChange={(e) =>
                              handleFieldChange(
                                e.target.value,
                                "workFullAddress"
                              )
                            }
                            variant="standard"
                          />
                        </TableCell>
                      </TableRow>
                    </>
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        </Box>
      </Paper>
      <Paper elevation={3} sx={{ margin: 2 }}>
        <Box sx={{ padding: 2 }}>
          <Typography className="typography-main-header">
            {t("contact_address_indicator")}
          </Typography>
          <Divider />
          <Box sx={{ marginTop: 2 }}>
            <TableContainer>
              <Table
                className="table-main"
                aria-label="simple table"
              >
                <TableBody>
                  <TableRow>
                    <TableCell>
                      {t(
                        "current_address_same_as_the_registered/working_address"
                      )}
                    </TableCell>
                    <TableCell colSpan={2}>
                      <ToggleButtonGroup
                        color="primary"
                        value={fields.currentAddressOptn}
                        exclusive
                        fullWidth
                        onChange={(event) =>
                          handleButtonChange(event, "currentAddressOptn")
                        }
                        aria-label="Platform"
                      >
                        <ToggleButton value="Registered Address">
                          Registered Address
                        </ToggleButton>
                        <ToggleButton value="Work Address">
                          Work Address
                        </ToggleButton>
                        <ToggleButton value="Different Address">
                          Different Address
                        </ToggleButton>
                      </ToggleButtonGroup>
                    </TableCell>
                  </TableRow>
                  {/* 3rd set */}
                  {fields.currentAddressOptn === "Different Address" && (
                    <>
                      <TableRow>
                        {/* <TableCell>{t("contact_address_number")}</TableCell> */}
                        <TableCell>
                          <TextField
                            id="outlined-basic"
                            label={t("contact_address_number")}
                            size="small"
                            variant="standard"
                            value={fields.cRegAddNum}
                            onChange={(e) =>
                              handleFieldChange(e.target.value, "cRegAddNum")
                            }
                          />
                        </TableCell>
                      {/* </TableRow>
                      <TableRow>
                        <TableCell>
                          {t("contact_address_villa/building")}
                        </TableCell> */}
                        <TableCell>
                          <TextField
                            id="outlined-basic"
                            label={t("contact_address_villa/building")}
                            size="small"
                            variant="standard"
                            value={fields.cRegAddVilla}
                            onChange={(e) =>
                              handleFieldChange(e.target.value, "cRegAddVilla")
                            }
                          />
                        </TableCell>
                      {/* </TableRow>
                      <TableRow> */}
                        {/* <TableCell>{t("contact_address_moo_number")}</TableCell> */}
                        <TableCell>
                          <TextField
                            id="outlined-basic"
                            label={t("contact_address_moo_number")}
                            size="small"
                            variant="standard"
                            value={fields.cRegAddMoo}
                            onChange={(e) =>
                              handleFieldChange(e.target.value, "cRegAddMoo")
                            }
                          />
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        {/* <TableCell>
                          {t("contact_address_alleyway/soi")}
                        </TableCell> */}
                        <TableCell>
                          <TextField
                            id="outlined-basic"
                            label={t("contact_address_alleyway/soi")}
                            size="small"
                            variant="standard"
                            value={fields.cRegAddAlley}
                            onChange={(e) =>
                              handleFieldChange(e.target.value, "cRegAddAlley")
                            }
                          />
                        </TableCell>
                      {/* </TableRow>
                      <TableRow> */}
                        {/* <TableCell>{t("contact_address_street")} </TableCell> */}
                        <TableCell>
                          <TextField
                            id="outlined-basic"
                            label={t("contact_address_street")}
                            size="small"
                            variant="standard"
                            value={fields.cRegAddStrNum}
                            onChange={(e) =>
                              handleFieldChange(e.target.value, "cRegAddStrNum")
                            }
                          />
                        </TableCell>
                      {/* </TableRow>
                      <TableRow> */}
                        {/* <TableCell>{t("contact_address_province")} </TableCell> */}
                        <TableCell>
                          <Dropdown
                            label={t("contact_address_province")}
                            options={states}
                            value={fields.cRegAddProvince}
                            onChange={(e) =>
                              handleFieldChange(
                                e.target.value,
                                "cRegAddProvince"
                              )
                            }
                          />
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        {/* <TableCell>{t("contact_address_district")}</TableCell> */}
                        <TableCell>
                          <Dropdown
                            label={t("contact_address_district")}
                            options={districts}
                            value={fields.cRegAddDist}
                            onChange={(e) =>
                              handleFieldChange(e.target.value, "cRegAddDist")
                            }
                          />
                        </TableCell>
                      {/* </TableRow>
                      <TableRow> */}
                        {/* <TableCell>
                          {t("contact_address_sub_district")}
                        </TableCell> */}
                        <TableCell>
                          <TextField
                            id="outlined-basic"
                            label={t("contact_address_sub_district")}
                            size="small"
                            variant="standard"
                            value={fields.cRegAddSubDis}
                            onChange={(e) =>
                              handleFieldChange(e.target.value, "cRegAddSubDis")
                            }
                          />
                        </TableCell>
                      {/* </TableRow>
                      <TableRow> */}
                        {/* <TableCell>{t("contact_address_zip_code")} </TableCell> */}
                        <TableCell>
                          <TextField
                            id="outlined-basic"
                            label={t("contact_address_zip_code")}
                            size="small"
                            variant="standard"
                            value={fields.cRegAddZipCode}
                            onChange={(e) =>
                              handleFieldChange(
                                e.target.value,
                                "cRegAddZipCode"
                              )
                            }
                          />
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        {/* <TableCell>{t("contact_full_address")}</TableCell> */}
                        <TableCell>
                          <TextField
                            id="outlined-basic"
                            label={t("contact_full_address")}
                            size="small"
                            multiline
                            value={fields.contactFullAddr}
                            onChange={(e) =>
                              handleFieldChange(
                                e.target.value,
                                "contactFullAddr"
                              )
                            }
                            // value={fields.cRegAddAlley + " , " + fields.cRegAddNum}
                            // InputProps={{ readOnly: true }}
                            variant="standard"
                          />
                        </TableCell>
                      </TableRow>
                    </>
                  )}
                  <TableRow>
                    <TableCell>
                      {t("insured_contact_address_indicator")}
                    </TableCell>
                    <TableCell>
                      <ToggleButtonGroup
                        color="primary"
                        value={fields.insContactAddressIndicator}
                        fullWidth
                        exclusive
                        onChange={(event) =>
                          handleButtonChange(
                            event,
                            "insContactAddressIndicator"
                          )
                        }
                        aria-label="Platform"
                      >
                        <ToggleButton value="Registered Address">
                          Registered Address
                        </ToggleButton>
                        <ToggleButton value="Work Address">
                          Work Address
                        </ToggleButton>
                        <ToggleButton value="Current Address">
                          Current Address
                        </ToggleButton>
                      </ToggleButtonGroup>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        </Box>
      </Paper>
      <Paper elevation={3} sx={{ margin: 2 }}>
        <Box sx={{ padding: 2 }}>
          <Typography className="typography-main-header">
            {t("insured_contact_number")}
          </Typography>
          <Divider />
          <Box sx={{ marginTop: 2 }}>
            <TableContainer>
              <Table
                className="table-main"
                aria-label="simple table"
              >
                <TableBody>
                  <TableRow>
                    {/* <TableCell> {t("primary_number")}</TableCell> */}
                    <TableCell>
                    {/* <Stack
            // spacing={2}
            direction={"row"}
            justifyContent={"flex-end"}
            paddingRight={5}
            paddingBottom={3}
          >
                      <CountrySelect/> */}
                      <TextField
                        variant="standard"
                        size="small"
                        label={t("primary_number")}
                        // k  onChange={handlePhoneNumberChange_primary}/>
                        //{isValid?(<p style={{color:'green'}}>valid mobile number</p>):(<p style={{color:'red'}}>please enter valid 10 digits mobile number</p>)}
                        value={fields.primaryNumber}
                        onChange={(e) =>
                          handlePhoneNumberChange(
                            e.target.value,
                            "primaryNumber"
                          )
                        }
                        error={Boolean(priErr)}
                        helperText={priErr}
                      ></TextField>
                      {/* </Stack> */}
                    </TableCell>
                  {/* </TableRow>
                  <TableRow> */}
                    {/* <TableCell> {t("home_number")}</TableCell> */}
                    <TableCell>
                      <TextField
                        variant="standard"
                        size="small"
                        label={t("home_number")}
                        value={fields.homeNumber}
                        onChange={(e) =>
                          handlePhoneNumberChange(e.target.value, "homeNumber")
                        }
                        error={Boolean(homeErr)}
                        helperText={homeErr}
                      ></TextField>
                    </TableCell>
                  {/* </TableRow>
                  <TableRow> */}
                    {/* <TableCell> {t("workplace_phone_number")}</TableCell> */}
                    <TableCell>
                      <TextField
                        variant="standard"
                        size="small"
                        label={t("workplace_phone_number")}
                        value={fields.workPhoneNumber}
                        onChange={(e) =>
                          handlePhoneNumberChange(
                            e.target.value,
                            "workPhoneNumber"
                          )
                        }
                        error={Boolean(workErr)}
                        helperText={workErr}
                      ></TextField>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    {/* <TableCell> {t("insured_email_address")}</TableCell> */}
                    <TableCell>
                      <TextField
                        variant="standard"
                        size="small"
                        label={t("insured_email_address")}
                        value={fields.emailAddress}
                        onChange={(e) =>
                          handleEmailChange(e.target.value, "emailAddress")
                        }
                        error={Boolean(error)}
                        helperText={error}
                      ></TextField>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        </Box>
      </Paper>
      <Paper elevation={3} sx={{ margin: 2 }}>
        <Box sx={{ padding: 2 }}>
          <Typography className="typography-main-header">
            {t("insured_occupation")}
          </Typography>
          <Divider />
          <Box sx={{ marginTop: 2 }}>
            <TableContainer>
              <Table
                sx={{
                  [`& .${tableCellClasses.root}`]: { borderBottom: "none" },
                }}
                aria-label="simple table"
              >
                <TableBody>
                  <TableRow>
                    {/* <TableCell>{t("occupation_code")}</TableCell> */}
                    <TableCell>
                    <Dropdown
                        label={t("occupation_code")}
                        options={occupationCode1}
                        value={fields.occupationCode}
                        onChange={(e) =>
                          handleFieldChange(
                            e.target.value,
                            "occupationCode"
                          )
                        }
                      />
                    </TableCell>
                  {/* </TableRow>
                  <TableRow> */}
                    {/* <TableCell>{t("position_held")}</TableCell> */}
                    <TableCell>
                      <TextField
                        variant="standard"
                        size="small"
                        label={t("position_held")}
                        value={fields.positionHeld}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "positionHeld")
                        }
                      ></TextField>
                    </TableCell>
                  {/* </TableRow>
                  <TableRow> */}
                    {/* <TableCell>{t("occupation_detail")}</TableCell> */}
                    <TableCell>
                      <TextField
                        variant="standard"
                        size="small"
                        label={t("occupation_detail")}
                        value={fields.occupationDetail}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "occupationDetail")
                        }
                      ></TextField>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    {/* <TableCell>{t("business_detail")}</TableCell> */}
                    <TableCell>
                      <TextField
                        variant="standard"
                        size="small"
                        label={t("business_detail")}
                        value={fields.businessDetail}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "businessDetail")
                        }
                      ></TextField>
                    </TableCell>
                  {/* </TableRow>
                  <TableRow> */}
                    {/* <TableCell> {t("annual_income")}</TableCell> */}
                    <TableCell>
                      <TextField
                        variant="standard"
                        size="small"
                        label={t("annual_income")}
                        type="number"
                        value={fields.annualIncome}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "annualIncome")
                        }
                      ></TextField>
                    </TableCell>
                  {/* </TableRow>
                  <TableRow> */}
                    {/* <TableCell>{t("other_occupations")}</TableCell> */}
                    <TableCell>
                      <TextField
                        variant="standard"
                        size="small"
                        label={t("other_occupations")}
                        multiline
                        value={fields.otherOccupation}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "otherOccupation")
                        }
                      ></TextField>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell
                      sx={{
                        whiteSpace: "normal",
                        wordWrap: "break-word",
                      }}
                    >
                      {t("do_you_use_the_motorcycle_in_your_occupation")}
                    </TableCell>
                    <TableCell>
                      <ToggleButtonGroup
                        color="primary"
                        value={fields.motorcycleOptn}
                        exclusive
                        fullWidth
                        size="small"
                        onChange={(event) =>
                          handleButtonChange(event, "motorcycleOptn")
                        }
                        aria-label="Platform"
                      >
                        <ToggleButton value="Yes">Yes</ToggleButton>
                        <ToggleButton value="No">No</ToggleButton>
                      </ToggleButtonGroup>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        </Box>
      </Paper>
    </Box>
  );
};

export default LifeAssuredDetail;
