import React, { useState, useEffect } from 'react';
import { 
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow, 
  Paper, TextField, Box, TablePagination, Link as MuiLink, CircularProgress,
  Button
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import axios from '../../api/axiosInterceptor'; // Adjust path if needed


export interface PolicyDisplay {
  quoteId: string;
  policyholderName: string;
  productName: string;
  status: number; // Displaying State ID directly
  date: string;
}


interface ApiPolicy {
  policyId: string;
  holderName: string;
  productName: string;
  stateId: number;
  insertTime: string; 

  sa?: number;
  periodPrem?: number;
  normalPrem?: number;
  updateTime?: string;
  assignRole?: string;
}

const ApplicationPolicyList: React.FC = () => {
  const navigate = useNavigate();
  
  const userEmail = localStorage.getItem('email') || ''; 

  const [policies, setPolicies] = useState<PolicyDisplay[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  useEffect(() => {
    const fetchPolicies = async () => {
      // Guard clause: Don't fetch if email isn't available
      if (!userEmail) return;

      try {
        setLoading(true);
        
   
        const response = await axios.get('http://localhost:8001/eapp/getAll');
        
        const rawData = response.data;

        // Group by quotation_id to get unique applications
        const uniqueApplications = rawData.reduce((acc: any, record: any) => {
          if (!acc[record.quotation_id]) {
            acc[record.quotation_id] = {
              quoteId: record.policyId,
              policyholderName: 'Unknown',
              productName: 'General Life Plan',
              status: 1,
              date: new Date(Date.now()).toISOString().split('T')[0],
            };
          }
          
          let parsedData = {};
          try {
            parsedData = typeof record.json_DATA === 'string' ? JSON.parse(record.json_DATA) : record.json_DATA;
          } catch (e) {
            console.error('Error parsing JSON:', e);
          }
          
          // Update with screen-specific data
          if (record.screen_No === 1) {
            // Screen 1 has personal details
            acc[record.quotation_id].policyholderName = `${(parsedData as any)?.insuredFirstName || ''} ${(parsedData as any)?.insuredSurName || ''}`.trim() || 'Unknown';
          } else if (record.screen_No === 2) {
            // Screen 2 has plan details
            acc[record.quotation_id].productName = (parsedData as any)?.basicPlan || 'General Life Plan';
          }
          
          return acc;
        }, {});

        const mappedData: PolicyDisplay[] = Object.values(uniqueApplications);

        setPolicies(mappedData);
      } catch (error) {
        console.error("Error fetching policies:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchPolicies();
  }, [userEmail]);

  const handleOpenDetails = (quoteId: string) => {
    navigate(`/application/${quoteId}`);
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => { 
      setSearchQuery(e.target.value); 
      setPage(0); 
  };
  
  const handleChangePage = (_: unknown, newPage: number) => {
      setPage(newPage);
  };
  
  const handleChangeRowsPerPage = (e: React.ChangeEvent<HTMLInputElement>) => { 
      setRowsPerPage(parseInt(e.target.value, 10)); 
      setPage(0); 
  };

  
  const filteredPolicies = policies.filter((policy) => {
    if (!searchQuery) return true;
    const lowerQuery = searchQuery.toLowerCase();
    return (
      policy.quoteId.toLowerCase().includes(lowerQuery) || 
      policy.policyholderName.toLowerCase().includes(lowerQuery)
    );
  });

  const handleNewPolicyClick = () => {
    axios
      .post("http://localhost:8001/eapp/generateQuoteId")
      .then(function (res) {
        const QuoteId = res.data;
        navigate(`/application/${QuoteId}`);
      })
      .catch(function (error) {
        console.log("Quote ID generation Error", error);
      });
  };

  // Slice data for pagination
  const visiblePolicies = filteredPolicies.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  return (
    <div>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2, mt: 2 }}>
        <TextField 
            label="Search ID or Name" 
            variant="outlined" 
            size="small" 
            value={searchQuery} 
            onChange={handleSearchChange} 
            sx={{ width: '300px' }} 
        />
        <Button
          variant="contained"
          color="primary"
          onClick={handleNewPolicyClick}
        >
          Start a new Quote
        </Button>
      </Box>

      <TableContainer component={Paper} >
        <Table>
          <TableHead>
            <TableRow sx={{ backgroundColor: '#f5f5f5' }}>
              <TableCell><strong>Application ID</strong></TableCell>
              <TableCell><strong>Holder Name</strong></TableCell>
              <TableCell><strong>Product Name</strong></TableCell>
              <TableCell><strong>State ID</strong></TableCell>
              <TableCell><strong>Date</strong></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {loading ? (
               <TableRow>
                <TableCell colSpan={5} align="center" sx={{ py: 3 }}>
                  <CircularProgress size={24} /> <span style={{ marginLeft: 10 }}>Loading...</span>
                </TableCell>
              </TableRow>
            ) : visiblePolicies.length > 0 ? (
              visiblePolicies.map((policy) => (
                <TableRow key={policy.quoteId} hover>
                  <TableCell>
                    <MuiLink 
                        component="button" 
                        variant="body2" 
                        onClick={() => handleOpenDetails(policy.quoteId)}
                        sx={{ fontWeight: 'bold', textDecoration: 'none' }}
                    >
                        {policy.quoteId}
                    </MuiLink>
                  </TableCell>
                  <TableCell>{policy.policyholderName}</TableCell>
                  <TableCell>{policy.productName}</TableCell>
                  <TableCell>{policy.status}</TableCell>
                  <TableCell>{policy.date}</TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                  <TableCell colSpan={5} align="center">
                      No applications found.
                  </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
        <TablePagination 
            rowsPerPageOptions={[5, 10, 25]} 
            component="div" 
            count={filteredPolicies.length} 
            rowsPerPage={rowsPerPage} 
            page={page} 
            onPageChange={handleChangePage} 
            onRowsPerPageChange={handleChangeRowsPerPage} 
        />
      </TableContainer>
    </div>
  );
};

export default ApplicationPolicyList;