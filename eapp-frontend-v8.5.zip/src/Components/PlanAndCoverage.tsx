import {
  Box,
  Button,
  Divider,
  Link,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  SelectChangeEvent,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  CircularProgress,
} from "@mui/material";

import React, { useEffect, useState } from "react";

import { useTranslation } from "react-i18next";

import { apiClient } from "../api/axiosInterceptor";

interface ChildComponentProps {
  fields: {
    basicPlan: string;

    basicSumInsured: string;

    basicPlanPremium: string;

    typeOfDivident: string;

    insuranceTerm: string;

    ppt: string;

    Product: string;

    Policy_Inception_Date: string;

    Smoker: string;

    Pre_Existing_Disease: string;

    Extra_mortality: string;

    Policy_Term: string;

    Mandatory_Premium_Period: string;

    PAV: string;

    per_mille_rating_death: string;

    per_mille_rating_TPD: string;

    per_mille_rating_SCI: string;

    Death_Benefit: string;

    Total_and_Permanent_Disability_TPD: string;

    Accidental_Death_and_Dismemberment_ADD: string;

    Staged_Critical_Illness_SCI: string;

    _2e_Hospital_Cash_Benefit_HCB: string;

    Partial_Withdrawl: string;

    Partial_Withdrawl_Amount: string;
  };

  setFields: React.Dispatch<
    React.SetStateAction<{
      basicPlan: string;

      basicSumInsured: string;

      basicPlanPremium: string;

      typeOfDivident: string;

      insuranceTerm: string;

      ppt: string;

      Product: string;

      Policy_Inception_Date: string;

      Smoker: string;

      Pre_Existing_Disease: string;

      Extra_mortality: string;

      Policy_Term: string;

      Mandatory_Premium_Period: string;

      PAV: string;

      per_mille_rating_death: string;

      per_mille_rating_TPD: string;

      per_mille_rating_SCI: string;

      Death_Benefit: string;

      Total_and_Permanent_Disability_TPD: string;

      Accidental_Death_and_Dismemberment_ADD: string;

      Staged_Critical_Illness_SCI: string;

      _2e_Hospital_Cash_Benefit_HCB: string;

      Partial_Withdrawl: string;

      Partial_Withdrawl_Amount: string;
    }>
  >;

  savedQuotation: any;

  savedTransaction: any;

  lifeAssuredDetails: {
    DOB: string;
    Gender: string;
    Occupation: string;
  };
}

const MAIN_PLANS = [
  "Term Insurance",
  "Whole Life Insurance", 
  "Universal Life Insurance",
  "Endowment Plan"
];

const RIDERS = [
  "ADD",
  "CI",
  "TPD",
  "HCB",
  "DB"
];

const YES_NO = ["Yes", "No"];

const PRODUCT_OPTIONS = ["a", "b"];

const EXTRA_MORTALITY_OPTIONS = ["5%", "10%", "15%", "20%", "25%", "30%", "35%", "40%", "45%", "50%", "55%", "60%", "65%", "70%", "75%", "80%", "85%", "90%", "95%", "100%"];

const camelToNormal = (text: string) => {
  return text
    .replace(/([A-Z])/g, " $1")
    .replace(/^./, (str) => str.toUpperCase());
};

const PlanAndCoverage: React.FC<ChildComponentProps> = ({
  fields,

  setFields,

  savedQuotation,

  savedTransaction,

  lifeAssuredDetails,
}) => {
  let jsonData;

  let headers: any[] = [];

  let OptRiderData;

  let OptHeaders: any[] = [];

  const [selectedRiders, setSelectedRiders] = useState<string[]>([]);
  const [premiumModalOpen, setPremiumModalOpen] = useState(false);
  const [premiumData, setPremiumData] = useState<{
    totalTargetPremium?: number;
    totalSubStandardPremium?: number;
    totalStandardPremium?: number;
  } | null>(null);
  const [loadingPremium, setLoadingPremium] = useState(false);

  const handleCalculatePremium = async () => {
    setLoadingPremium(true);
    try {
      // Map fields to API expected keys
       const requestData = {
      root: {
        request_data: {
          inputs: {
            _1a_DOB: lifeAssuredDetails.DOB,
            _1b_Product: fields.Product,
            _1c_Gender: lifeAssuredDetails.Gender,
            _1d_Face_Amount: fields.basicSumInsured,
            _1e_Occupation: lifeAssuredDetails.Occupation,
            _1h_Policy_Inception_Date: fields.Policy_Inception_Date,
            _1i_Smoker: fields.Smoker === "Yes" ? "Y" : "N",
            _1j_Pre_Existing_Disease: fields.Pre_Existing_Disease,
            _1k_Extra_mortality: fields.Extra_mortality,
            _1p_Policy_Term: fields.Policy_Term,
            _1r_Mandatory_Premium_Period: fields.Mandatory_Premium_Period,
            _1zb_PAV: fields.PAV,
            _1zc_per_mille_rating_death: fields.per_mille_rating_death,
            _1zd_per_mille_rating_TPD: fields.per_mille_rating_TPD,
            _1ze_per_mille_rating_SCI: fields.per_mille_rating_SCI,
            _2a_Death_Benefit: fields.Death_Benefit,
            _2b_Total_and_Permanent_Disability_TPD:
              fields.Total_and_Permanent_Disability_TPD,
            _2c_Accidental_Death_and_Dismemberment_ADD:
              fields.Accidental_Death_and_Dismemberment_ADD,
            _2d_Staged_Critical_Illness_SCI:
              fields.Staged_Critical_Illness_SCI,
            _2e_Hospital_Cash_Benefit_HCB:
              fields._2e_Hospital_Cash_Benefit_HCB,
            _3a_Partial_Withdrawl: fields.Partial_Withdrawl,
            _3b_Partial_Withdrawl_Amount: fields.Partial_Withdrawl_Amount
          }
        },
        request_meta: {
          version_id: "57e38b87-052c-4fb1-a6c5-76bd1567df2d",
          call_purpose: "Spark - API Tester",
          source_system: "SPARK",
          correlation_id: null,
          requested_output: null,
          service_category: "",
          compiler_type: "Neuron"
        }
      }
    };

      console.log('Request data being sent to API:', requestData);

      const response = await apiClient.post(
        'https://excel.uat.us.coherent.global/cognizant/api/v3/folders/Sanjana_Test/services/Universal-Life-product-TestPrd/execute',
        requestData
      );
      console.log('API Response:', response.data);
      
      // Extract premium data from response - handle different possible response structures
      const responseData = response.data?.response_data?.outputs || response.data?.outputs || response.data;
      
      if (responseData && (
        responseData._2m_Total_Target_Premium !== undefined ||
        responseData._2l_Total_Sub_Std_Premium !== undefined ||
        responseData._2f_Total_Std_Premium !== undefined
      )) {
        setPremiumData({
          totalTargetPremium: responseData._2m_Total_Target_Premium,
          totalSubStandardPremium: responseData._2l_Total_Sub_Std_Premium,
          totalStandardPremium: responseData._2f_Total_Std_Premium,
        });
        setPremiumModalOpen(true);
      } else {
        console.error('Premium data not found in response. Response structure:', response.data);
        alert('Premium calculation completed but required premium fields were not found in the response.');
      }
    } catch (error) {
      console.error('Error calculating premium:', error);
      alert('Error calculating premium. Please try again.');
    } finally {
      setLoadingPremium(false);
    }
  };

  const handleFieldChange = (val: string, fieldName: string) => {
    setFields({ ...fields, [fieldName]: val });
  };

  const handlePlanChange = (event: SelectChangeEvent<string>) => {
    const selectedPlan = event.target.value;
    handleFieldChange(selectedPlan, "basicPlan");

    // Set Product based on plan type
    if (selectedPlan === "Term Insurance") {
      handleFieldChange("a", "Product");
    } else if (selectedPlan === "Whole Life Insurance") {
      handleFieldChange("b", "Product");
    }

    // Set default values based on plan type
    const defaultSumInsured = getDefaultSumInsured(selectedPlan);
    const defaultPremium = calculatePremium(defaultSumInsured, selectedPlan);

    handleFieldChange(defaultSumInsured.toString(), "basicSumInsured");
    handleFieldChange(defaultPremium.toString(), "basicPlanPremium");
  };

  const getDefaultSumInsured = (planType: string): number => {
    switch (planType) {
      case "Term Insurance": return 1000000;
      case "Whole Life Insurance": return 500000;
      case "Universal Life Insurance": return 750000;
      case "Endowment Plan": return 300000;
      default: return 500000;
    }
  };

  const calculatePremium = (sumInsured: number, planType: string): number => {
    const baseRate = {
      "Term Insurance": 0.002,
      "Whole Life Insurance": 0.015,
      "Universal Life Insurance": 0.012,
      "Endowment Plan": 0.025
    };
    return Math.round(sumInsured * (baseRate[planType as keyof typeof baseRate] || 0.01));
  };

  const handleRiderChange = (event: SelectChangeEvent<string[]>) => {
    const value = event.target.value;
    const newSelectedRiders = typeof value === 'string' ? value.split(',') : value;
    setSelectedRiders(newSelectedRiders);

    // Update benefit fields based on selected riders
    const riderToFieldMap: { [key: string]: string } = {
      "DB": "Death_Benefit",
      "TPD": "Total_and_Permanent_Disability_TPD",
      "ADD": "Accidental_Death_and_Dismemberment_ADD",
      "CI": "Staged_Critical_Illness_SCI",
      "HCB": "_2e_Hospital_Cash_Benefit_HCB"
    };

    newSelectedRiders.forEach(rider => {
      const field = riderToFieldMap[rider];
      if (field) {
        handleFieldChange("Yes", field);
      }
    });
  };

  const { t } = useTranslation();

  useEffect(() => {
    if (savedTransaction && savedTransaction.length > 0) {
      const baseSA = savedTransaction[0]?.txn_input_json?.Base_SA;

      const plan = savedTransaction[0]?.txn_input_json?.Plan;

      const term = savedTransaction[0]?.txn_input_json["SSPP.Policy_Term"];

      const ppt = savedTransaction[0]?.txn_input_json?.PPT;

      setFields((prevFields) => ({
        ...prevFields,

        basicPlanPremium:
          savedTransaction[0]?.txn_output_json?.outputs?.PremiumSummary[1]
            ?.basePlan,

        basicSumInsured: baseSA || '200000',

        basicPlan: plan,

        insuranceTerm: term,

        ppt: ppt,

        typeOfDivident: "Non - Participatory",

        Product: '',

        DOB: '',

        Gender: '',

        Occupation: '',

        Policy_Inception_Date: new Date().toISOString().split('T')[0],

        Smoker: 'No',

        Pre_Existing_Disease: 'Yes',

        Extra_mortality: '75%',

        Policy_Term: '45',

        Mandatory_Premium_Period: 'ErrName',

        PAV: '0',

        per_mille_rating_death: '1',

        per_mille_rating_TPD: '1',

        per_mille_rating_SCI: '1',

        Death_Benefit: 'No',

        Total_and_Permanent_Disability_TPD: 'No',

        Accidental_Death_and_Dismemberment_ADD: 'No',

        Staged_Critical_Illness_SCI: 'No',

        _2e_Hospital_Cash_Benefit_HCB: 'No',

        Partial_Withdrawl: 'Yes',

        Partial_Withdrawl_Amount: '5000',
      }));
    } else {
      // Set defaults when no savedTransaction
      setFields((prevFields) => ({
        ...prevFields,

        basicSumInsured: '200000',

        Product: '',

        DOB: '',

        Gender: '',

        Occupation: '',

        Policy_Inception_Date: new Date().toISOString().split('T')[0],

        Smoker: 'No',

        Pre_Existing_Disease: 'Yes',

        Extra_mortality: '75%',

        Policy_Term: '45',

        Mandatory_Premium_Period: 'ErrName',

        PAV: '0',

        per_mille_rating_death: '1',

        per_mille_rating_TPD: '1',

        per_mille_rating_SCI: '1',

        Death_Benefit: 'No',

        Total_and_Permanent_Disability_TPD: 'No',

        Accidental_Death_and_Dismemberment_ADD: 'No',

        Staged_Critical_Illness_SCI: 'No',

        _2e_Hospital_Cash_Benefit_HCB: 'No',

        Partial_Withdrawl: 'Yes',

        Partial_Withdrawl_Amount: '5000',
      }));
    }
  }, [savedTransaction]);

  if (
    savedTransaction &&
    typeof savedTransaction === "object" &&
    Object.keys(savedTransaction).length !== 0
  ) {
    jsonData = savedTransaction[0]?.txn_output_json?.outputs?.RiderDetails;

    if (jsonData?.length) {
      headers = Object.keys(jsonData[0]);
    }

    OptRiderData =
      savedTransaction[0]?.txn_output_json?.outputs?.OptionalBenefitDetails;

    if (OptRiderData?.length) {
      OptHeaders = Object.keys(OptRiderData[0]);
    }
  }

  return (
    <Box sx={{ width: "100%", padding: 2 }}>
      {/* Quotation Summary */}
      <Paper elevation={3} sx={{ marginBottom: 2, padding: 2 }}>
        <Typography className="typography-main-header">
          {t("quotation_summaryh")}
        </Typography>
        <Divider />
        <Box
          sx={{
            display: "flex",
            flexDirection: { xs: "column", sm: "row" },
            marginTop: 2,
          }}
        >
          <Typography>{t("quotation_summary")}&emsp;</Typography>
          <Link
            underline="always"
            color="inherit"
            sx={{ color: "#000048" }}
            onClick={() => {
              const file = new Blob(
                [
                  Uint8Array.from(atob(savedQuotation.txn_pdf), (c) =>
                    c.charCodeAt(0)
                  ),
                ],
                {
                  type: "application/pdf",
                }
              );

              const fileURL = URL.createObjectURL(file);

              window.open(fileURL);
            }}
          >
            Download Link to Quotation
          </Link>
        </Box>
      </Paper>

      {/* Main Plan */}
      <Paper elevation={3} sx={{ marginBottom: 2, padding: 2 }}>
        <Typography className="typography-main-header">
          {t("main_plan")}
        </Typography>
        <Divider />
        <Box sx={{ marginTop: 2 }}>
          <TableContainer sx={{ width: "100%" }}>
            <Table className="table-main" sx={{ width: "100%" }} >
              <TableBody>
                <TableRow sx={{ display: "flex", flexWrap: "wrap" }}>
                  <TableCell sx={{ flex: "1 1 30%", minWidth: "120px" }}>
                    <FormControl variant="standard" size="small" fullWidth>
                      <InputLabel>{t("basicPlan")}</InputLabel>
                      <Select
                        value={fields.basicPlan}
                        onChange={handlePlanChange}
                      >
                        {MAIN_PLANS.map((plan) => (
                          <MenuItem key={plan} value={plan}>
                            {plan}
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </TableCell>
                  {["basicSumInsured", "basicPlanPremium", "typeOfDivident", "insuranceTerm", "ppt"].map((field) => (
                    <TableCell
                      key={field}
                      sx={{ flex: "1 1 30%", minWidth: "120px" }}
                    >
                      <TextField
                        size="small"
                        label={t(field)}
                        variant="standard"
                        InputProps={{
                          readOnly: !["basicPlanPremium", "typeOfDivident", "insuranceTerm", "ppt"].includes(field)
                        }}
                        value={fields[field as keyof typeof fields]}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, field)
                        }
                      />
                    </TableCell>
                  ))}
                  <TableCell sx={{ flex: "1 1 30%", minWidth: "120px" }}>
                    <FormControl variant="standard" size="small" fullWidth>
                      <InputLabel>Product</InputLabel>
                      <Select
                        value={fields.Product}
                        onChange={(e) => handleFieldChange(e.target.value, "Product")}
                      >
                        {PRODUCT_OPTIONS.map((option) => (
                          <MenuItem key={option} value={option}>
                            {option}
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </TableCell>
                  <TableCell sx={{ flex: "1 1 30%", minWidth: "120px" }}>
                    <TextField
                      size="small"
                      label="Policy Inception Date"
                      variant="standard"
                      type="date"
                      value={fields.Policy_Inception_Date}
                      onChange={(e) => handleFieldChange(e.target.value, "Policy_Inception_Date")}
                    />
                  </TableCell>
                  <TableCell sx={{ flex: "1 1 30%", minWidth: "120px" }}>
                    <FormControl variant="standard" size="small" fullWidth>
                      <InputLabel>Smoker</InputLabel>
                      <Select
                        value={fields.Smoker}
                        onChange={(e) => handleFieldChange(e.target.value, "Smoker")}
                      >
                        {YES_NO.map((option) => (
                          <MenuItem key={option} value={option}>
                            {option}
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </TableCell>
                  <TableCell sx={{ flex: "1 1 30%", minWidth: "120px" }}>
                    <FormControl variant="standard" size="small" fullWidth>
                      <InputLabel>Pre Existing Disease</InputLabel>
                      <Select
                        value={fields.Pre_Existing_Disease}
                        onChange={(e) => handleFieldChange(e.target.value, "Pre_Existing_Disease")}
                      >
                        {YES_NO.map((option) => (
                          <MenuItem key={option} value={option}>
                            {option}
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </TableCell>
                  <TableCell sx={{ flex: "1 1 30%", minWidth: "120px" }}>
                    <FormControl variant="standard" size="small" fullWidth>
                      <InputLabel>Extra Mortality</InputLabel>
                      <Select
                        value={fields.Extra_mortality}
                        onChange={(e) => handleFieldChange(e.target.value, "Extra_mortality")}
                      >
                        {EXTRA_MORTALITY_OPTIONS.map((option) => (
                          <MenuItem key={option} value={option}>
                            {option}
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </TableCell>
                  <TableCell sx={{ flex: "1 1 30%", minWidth: "120px" }}>
                    <TextField
                      size="small"
                      label="Policy Term"
                      variant="standard"
                      value={fields.Policy_Term}
                      onChange={(e) => handleFieldChange(e.target.value, "Policy_Term")}
                    />
                  </TableCell>
                  <TableCell sx={{ flex: "1 1 30%", minWidth: "120px" }}>
                    <TextField
                      size="small"
                      label="Mandatory Premium Period"
                      variant="standard"
                      value={fields.Mandatory_Premium_Period}
                      onChange={(e) => handleFieldChange(e.target.value, "Mandatory_Premium_Period")}
                    />
                  </TableCell>

                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      </Paper>

      {/* Riders */}
      <Paper elevation={3} sx={{ marginBottom: 2, padding: 2 }}>
        <Typography className="typography-main-header">
          {t("riders")}
        </Typography>
        <Divider />
        <Box sx={{ marginTop: 2 }}>
          <FormControl variant="standard" size="small" sx={{ minWidth: 200, marginBottom: 2 }}>
            <InputLabel>Select Riders</InputLabel>
            <Select
              multiple
              value={selectedRiders}
              onChange={handleRiderChange}
              renderValue={(selected) => selected.join(', ')}
            >
              {RIDERS.map((rider) => (
                <MenuItem key={rider} value={rider}>
                  {rider}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          <Box sx={{ marginTop: 2 }}>
            <Typography variant="h6" sx={{ marginBottom: 1 }}>Benefits</Typography>
            <Box sx={{ display: 'flex', flexWrap: 'wrap' }}>
              {[
                { key: 'Death_Benefit', label: 'Death Benefit' },
                { key: 'Total_and_Permanent_Disability_TPD', label: 'Total and Permanent Disability TPD' },
                { key: 'Accidental_Death_and_Dismemberment_ADD', label: 'Accidental Death and Dismemberment ADD' },
                { key: 'Staged_Critical_Illness_SCI', label: 'Staged Critical Illness SCI' },
                { key: '_2e_Hospital_Cash_Benefit_HCB', label: 'Hospital Cash Benefit HCB' }
              ].map(({ key, label }) => (
                <FormControl key={key} variant="standard" size="small" sx={{ marginRight: 2, marginBottom: 1, minWidth: 200 }}>
                  <InputLabel>{label}</InputLabel>
                  <Select
                    value={fields[key as keyof typeof fields]}
                    onChange={(e) => handleFieldChange(e.target.value, key)}
                  >
                    {YES_NO.map((option) => (
                      <MenuItem key={option} value={option}>
                        {option}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              ))}
            </Box>
          </Box>
          {jsonData && (
            <TableContainer sx={{ width: "100%" }}>
              <Table sx={{ width: "100%" }}>
                <TableHead>
                  <TableRow>
                    {headers?.map((header) => (
                      <TableCell key={header}>{camelToNormal(header)}</TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {jsonData?.map((row: any, rowIndex: number) => (
                    <TableRow key={rowIndex}>
                      {headers?.map((header) => (
                        <TableCell key={header}>{row[header]}</TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </Box>
      </Paper>

      {/* Calculate Button */}
      <Box sx={{ display: 'flex', justifyContent: 'center', marginBottom: 2 }}>
        <Button
          variant="contained"
          color="primary"
          size="large"
          onClick={handleCalculatePremium}
          disabled={loadingPremium}
          startIcon={loadingPremium ? <CircularProgress size={20} /> : null}
          sx={{
            minWidth: 200,
            padding: '12px 24px',
            fontSize: '16px',
            fontWeight: 'bold',
            textTransform: 'none',
            borderRadius: '8px',
            boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
            '&:hover': {
              boxShadow: '0 6px 8px rgba(0, 0, 0, 0.15)',
            }
          }}
        >
          {loadingPremium ? 'Calculating...' : 'Calculate Premium'}
        </Button>
      </Box>

      {/* Premium Details Modal */}
      <Dialog
        open={premiumModalOpen}
        onClose={() => setPremiumModalOpen(false)}
        maxWidth="sm"
        fullWidth
        PaperProps={{
          sx: {
            borderRadius: '12px',
            boxShadow: '0 8px 32px rgba(0, 0, 0, 0.12)',
          }
        }}
      >
        <DialogTitle
          sx={{
            backgroundColor: '#1976d2',
            color: 'white',
            fontWeight: 'bold',
            fontSize: '20px',
            padding: '20px 24px',
          }}
        >
          Premium Calculation Results
        </DialogTitle>
        <DialogContent sx={{ padding: '24px' }}>
          {premiumData && (
            <Box>
              <Box
                sx={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: 2,
                }}
              >
                {/* Total Target Premium */}
                <Paper
                  elevation={2}
                  sx={{
                    padding: '20px',
                    backgroundColor: '#f5f5f5',
                    borderRadius: '8px',
                    border: '1px solid #e0e0e0',
                  }}
                >
                  <Typography
                    variant="body2"
                    sx={{
                      color: '#666',
                      fontSize: '14px',
                      marginBottom: '8px',
                      fontWeight: 500,
                    }}
                  >
                    Total Target Premium
                  </Typography>
                  <Typography
                    variant="h5"
                    sx={{
                      color: '#1976d2',
                      fontWeight: 'bold',
                      fontSize: '24px',
                    }}
                  >
                    ₹{premiumData.totalTargetPremium?.toLocaleString('en-IN') || 'N/A'}
                  </Typography>
                </Paper>

                {/* Total Standard Premium */}
                <Paper
                  elevation={2}
                  sx={{
                    padding: '20px',
                    backgroundColor: '#f5f5f5',
                    borderRadius: '8px',
                    border: '1px solid #e0e0e0',
                  }}
                >
                  <Typography
                    variant="body2"
                    sx={{
                      color: '#666',
                      fontSize: '14px',
                      marginBottom: '8px',
                      fontWeight: 500,
                    }}
                  >
                    Total Standard Premium
                  </Typography>
                  <Typography
                    variant="h5"
                    sx={{
                      color: '#2e7d32',
                      fontWeight: 'bold',
                      fontSize: '24px',
                    }}
                  >
                    ₹{premiumData.totalStandardPremium?.toLocaleString('en-IN') || 'N/A'}
                  </Typography>
                </Paper>

                {/* Total Sub Standard Premium */}
                <Paper
                  elevation={2}
                  sx={{
                    padding: '20px',
                    backgroundColor: '#f5f5f5',
                    borderRadius: '8px',
                    border: '1px solid #e0e0e0',
                  }}
                >
                  <Typography
                    variant="body2"
                    sx={{
                      color: '#666',
                      fontSize: '14px',
                      marginBottom: '8px',
                      fontWeight: 500,
                    }}
                  >
                    Total Sub Standard Premium
                  </Typography>
                  <Typography
                    variant="h5"
                    sx={{
                      color: '#ed6c02',
                      fontWeight: 'bold',
                      fontSize: '24px',
                    }}
                  >
                    ₹{premiumData.totalSubStandardPremium?.toLocaleString('en-IN') || 'N/A'}
                  </Typography>
                </Paper>
              </Box>
            </Box>
          )}
        </DialogContent>
        <DialogActions sx={{ padding: '16px 24px', backgroundColor: '#f5f5f5' }}>
          <Button
            onClick={() => setPremiumModalOpen(false)}
            variant="contained"
            color="primary"
            sx={{
              minWidth: 100,
              textTransform: 'none',
              borderRadius: '6px',
            }}
          >
            Close
          </Button>
        </DialogActions>
      </Dialog>

      {/* Optional Benefits */}
      <Paper elevation={3} sx={{ marginBottom: 2, padding: 2 }}>
        <Typography className="typography-main-header">
          {t("optional_benefits")}
        </Typography>
        <Divider />
        <Box sx={{ marginTop: 2 }}>
          <TableContainer sx={{ width: "100%" }}>
            <Table sx={{ width: "100%" }}>
              <TableHead>
                <TableRow>
                  {OptHeaders?.map((header) => (
                    <TableCell key={header}>{camelToNormal(header)}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {OptRiderData?.map((row: any, rowIndex: number) => (
                  <TableRow key={rowIndex}>
                    {OptHeaders?.map((header) => (
                      <TableCell key={header}>{row[header]}</TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      </Paper>
    </Box>
  );
};

export default PlanAndCoverage;
