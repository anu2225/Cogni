import React, { useRef } from "react";
import SignatureCanvas from 'react-signature-canvas';
import Button from '@mui/material/Button'
import { Box, Divider, Paper, Stack, styled, Table, TableBody, TableCell, tableCellClasses, TableContainer, TableRow, Typography, useMediaQuery,useTheme } from "@mui/material";
import { useTranslation } from "react-i18next";

const StyledButton = styled(Button)({
    backgroundColor: "#ffffff",
    color: "#000048",
    borderColor: "#000048",
    borderRadius: "20px",
    "&:hover": {
      color: "#ffffff",
      backgroundColor: "#000048",
    },
  });
  
   

interface ChildComponentProps {
    fields: { signURL: string };
    setFields: React.Dispatch<React.SetStateAction<{ signURL : string }>>;
}
const Signatures:React.FC<ChildComponentProps> = ({ fields, setFields }) => {
    const { t } = useTranslation();
    const signatureRef = useRef<any>(null);

    const theme = useTheme();
    const isSmallScreen = useMediaQuery(theme.breakpoints.down("sm"));

    const clearSignature = () => {
        if (signatureRef.current) {
            signatureRef.current.clear();
        }
    };

    const getSignatureImage = () => {
        if (signatureRef.current) {

            const signURL = signatureRef.current.toDataURL();
            console.log("Sign is==> ",signURL);
            //fields.signURL = signURL;
            setFields({
                ...fields,
                signURL:signURL
            })
            return signURL;
        }
        return null;
    };

    return (
        <Box>
            <Paper elevation={3} sx={{ margin: 2 }}>
                <Box sx={{ padding: 2 }}>
                    <Typography sx={{ color: '#000048', fontWeight: 'bold' }}>
                    {t("signatures")}
                    </Typography>
                    <Divider />
                    <Box sx={{ marginTop: 2 }}>
                        <TableContainer >
                            <Table className="table-main"
                                aria-label="sign table">
                                <TableBody>
                                    <TableRow>
                                        <TableCell sx={{fontSize:isSmallScreen? "0.8rem" : "1rem"}}>{t("sign_of_life_assured")}</TableCell>
                                        <TableCell>
                                            <div style={{ border: '2px solid #000048',  borderRadius:'5px' , width:isSmallScreen?"100%": "700px",}}>
                                            <SignatureCanvas
                                                penColor='black'
                                                canvasProps={{ width: isSmallScreen ? 300 : 700, height: 200, className: 'signatureCanvas' }}
                                                ref={signatureRef}
                                            />
                                            </div>
                                            <Stack direction={isSmallScreen? "column" : "row"} spacing={1} justifyContent={'flex-end'} marginTop={1}>
                                            <Button className="styled-button" variant='contained' onClick={clearSignature}> Clear </Button>
                                            <Button  className="styled-button" variant='contained' onClick={getSignatureImage}>Get Signature</Button>
                                            </Stack>
                                        </TableCell>
                                    </TableRow>
                                    {fields.signURL !== "" &&
                                    <TableRow>
                                        <TableCell sx={{fontSize: isSmallScreen ? "0.8rem" : "1rem"}} >{t("signature_for_display")}
                                        </TableCell>
                                        <TableCell>
                                            <img src={fields.signURL} alt={"signURL"}/>
                                        </TableCell>
                                    </TableRow>
                                    }
                                </TableBody>
                            </Table>
                        </TableContainer>
                    </Box>
                </Box>
            </Paper>
        </Box>
    );
};

export default Signatures;