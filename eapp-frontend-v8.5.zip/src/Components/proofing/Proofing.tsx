import { Paper, Typography } from '@mui/material'
import ProofingPolicyList from './ProofingPolicyList'


const Proofing = () => {
  return (
    <Paper sx={{ p: 3, height: '100%' }}>
      <Typography variant="h5" gutterBottom>
        Proofing Sharing Pool
      </Typography>
      <ProofingPolicyList />
    </Paper>
  )
}

export default Proofing