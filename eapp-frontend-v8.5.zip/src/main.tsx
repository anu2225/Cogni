
import React, { Suspense } from 'react';
import ReactDOM from 'react-dom/client';
import i18next from 'i18next';
import { initReactI18next } from 'react-i18next';
import HttpApi from 'i18next-http-backend';
import LanguageDetector from 'i18next-browser-languagedetector';

import 'bootstrap/dist/js/bootstrap.js';
import 'bootstrap/dist/css/bootstrap.min.css';
import "./index.css";

import { RouterProvider, createBrowserRouter } from 'react-router-dom';

// --- COMPONENT IMPORTS ---
import App from './App.jsx';
import SignIn from './Components/Auth/SignIn.js';
import SignUp from './Components/Auth/SignUp.js';
import BasicTabs from './Components/BasicTabs';
import Underwriting from './Components/underwriting/Underwriting';
import Application from './Components/application/Application.js';
import UnderwritingDetails from './Components/underwriting/UnderwritingDetails';
import Proofing from './Components/proofing/Proofing.js';
import UWRequirements from './Components/underwriting/UWRequirements';

// --- PLACEHOLDER COMPONENTS ---
const Payment = () => <div className="p-4"><h2>Payment Gateway</h2></div>;
const Claims = () => <div className="p-4"><h2>Claims Processing</h2></div>;

// --- I18N CONFIGURATION ---
i18next
  .use(HttpApi)
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    supportedLngs: ['en', 'th'],
    fallbackLng: 'en',
    debug: false,
    detection: {
      order: ['path', 'cookie', 'htmlTag'],
      caches: ['cookie'],
    },
    backend: {
      loadPath: '/assets/locales/{{lng}}/translation.json',
    },
  });

// --- ROUTER CONFIGURATION ---
const router = createBrowserRouter([
  // 1. PUBLIC ROUTES
  {
    path: '/',
    element: <SignIn />
  },
  {
    path: '/signin',
    element: <SignIn />
  },
  {
    path: '/signup',
    element: <SignUp />
  },

  // 2. PROTECTED APP ROUTES (Wrapped in App Layout)
  {
    element: <App />,
    children: [
      // A. Application
      {
        path: 'application',
        element: <Application />
      },
      {
        path: 'application/:txnTypeId',
        element: <BasicTabs />
      },

      // B. Underwriting
      {
        path: 'underwriting',
        element: <Underwriting />
      },
      {
        path: 'underwriting/:txnTypeId',
        element: <Underwriting />
      },
      {
        path: 'underwriting/:txnTypeId/details',
        element: <UnderwritingDetails />
      },

      // ✅ NEW – UW Requirements Screen
      {
        path: 'underwriting/:txnTypeId/requirements',
        element: <UWRequirements />
      },

      // C. Proofing
      {
        path: 'proofing',
        element: <Proofing />
      },
      {
        path: 'proofing/:txnTypeId',
        element: <Proofing />
      },

      // D. Other Modules
      {
        path: 'payment',
        element: <Payment />
      },
      {
        path: 'payment/:txnTypeId',
        element: <Payment />
      },
      {
        path: 'claims',
        element: <Claims />
      },
      {
        path: 'claims/:txnTypeId',
        element: <Claims />
      }
    ]
  }
]);

const loadingMarkup = (
  <div className="py-4 text-center">
    <h3>Loading..</h3>
  </div>
);

ReactDOM.createRoot(document.getElementById('root')!).render(
  <Suspense fallback={loadingMarkup}>
    <React.StrictMode>
      <RouterProvider router={router} />
    </React.StrictMode>
  </Suspense>
);
