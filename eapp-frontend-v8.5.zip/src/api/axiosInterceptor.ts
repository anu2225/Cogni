import axios, { AxiosRequestConfig, AxiosResponse } from 'axios';

// Create an axios instance with default config
const axiosInstance = axios.create();

// Add request interceptor to attach bearer token to all requests
axiosInstance.interceptors.request.use(
  (config) => {
    // Get the user object from localStorage
    // const userStr = localStorage.getItem('user');
    
    const token = 'eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJ3b2ZGYnJPNWQyWWpaSnVrSHR5Q3Z4cU1QeHBHMXB1emhPYm9qUjVkb3NnIn0.eyJleHAiOjE3NjU2NDc1OTgsImlhdCI6MTc2NTY0MDQwOCwiYXV0aF90aW1lIjoxNzY1NjExNTk4LCJqdGkiOiJvbnJ0YWM6NjE4ZDc0MGMtM2FlZS00YjQ3LTk2NDItZmE5Y2YyNWFjMTQ4IiwiaXNzIjoiaHR0cHM6Ly9rZXljbG9hay51YXQudXMuY29oZXJlbnQuZ2xvYmFsL2F1dGgvcmVhbG1zL2NvZ25pemFudCIsImF1ZCI6WyJwcm9kdWN0LWZhY3RvcnkiLCJyZWFsbS1tYW5hZ2VtZW50Il0sInN1YiI6ImZmNTFjMjBjLTQ1NmItNDUxZi04MWJlLTdjYjQyYzIzOTZiZSIsInR5cCI6IkJlYXJlciIsImF6cCI6InByb2R1Y3QtZmFjdG9yeSIsInNpZCI6ImJkN2JhMmUyLTY2NjQtNGRhMy05MzFiLWUyMjdlZTE0OWI4NSIsImFsbG93ZWQtb3JpZ2lucyI6WyJodHRwczovL21vZGVsaW5nLWNlbnRlci5kZXYuY29oZXJlbnQuZ2xvYmFsIiwiaHR0cHM6Ly9zYS51YXQudXMuY29oZXJlbnQuZ2xvYmFsIiwiaHR0cHM6Ly9tb2RlbGluZy1jZW50ZXIudXMuY29oZXJlbnQuZ2xvYmFsIiwiaHR0cHM6Ly9hc3Npc3RhbnQuc3RhZ2luZy5jb2hlcmVudC5nbG9iYWwiLCJodHRwczovL3NwYXJrLnVhdC51cy5jb2hlcmVudC5nbG9iYWwiLCJodHRwczovL2Fzc2lzdGFudC5leHQuY29oZXJlbnQuZ2xvYmFsIiwiaHR0cHM6Ly9wcm9kdWN0ZmFjdG9yeS51YXQudXMuY29oZXJlbnQuZ2xvYmFsIiwiaHR0cHM6Ly9zcGFyay11c2VyLW1hbmFnZXIudWF0LnVzLmNvaGVyZW50Lmdsb2JhbCIsImh0dHBzOi8vc2Euc3RhZ2luZy5jb2hlcmVudC5nbG9iYWwiLCJodHRwczovL21vZGVsaW5nLWNlbnRlci5zdGFnaW5nLmNvaGVyZW50Lmdsb2JhbCJdLCJyZXNvdXJjZV9hY2Nlc3MiOnsicmVhbG0tbWFuYWdlbWVudCI6eyJyb2xlcyI6WyJ2aWV3LXVzZXJzIiwicXVlcnktZ3JvdXBzIiwicXVlcnktdXNlcnMiXX19LCJzY29wZSI6Im9wZW5pZCBzcGFyayBwcm9maWxlIiwibmFtZSI6IlNhbmphbiBNdWtoZXJqZWUiLCJncm91cHMiOlsidXNlcjpwZiJdLCJyZWFsbSI6ImNvZ25pemFudCIsInByZWZlcnJlZF91c2VybmFtZSI6InNhbmphbmEubXVraGVyamVlQGNvZ25pemFudC5jb20iLCJnaXZlbl9uYW1lIjoiU2FuamFuIiwiZmFtaWx5X25hbWUiOiJNdWtoZXJqZWUiLCJ1c2VyX2NyZWF0ZWRfdGltZXN0YW1wIjoxNjY5NzAxMjI0MzI0LCJyZWxhdGlvbiI6InBhcnRuZXIifQ.IXZBG8lRpreim9M1y7pxHAdXkIeeIPS6LmhmpujUXczogMgCh3Srs3j7PvKMGJqNmZqn_iimSOAfXsJ4UxhPJoU4WMBt9ar6PTohs8UzXMmIwNkJHa0HlSW8MCe1d0FWtxpF3R_eX49viI5M-UvoI5BPMdxMuZ-ATRpmGtewD_oKhEQP4hJFwossOEkaK0E8XFXn0cT8ycRUResFdlCs_bc4ktKa14qBBrJTrwJCZV030McOq2VWpC4tzlHJaJHChZwfPKtkH3QPdTyANDamiTLCOe5Snmjp8vaPF7qhOZu7SzbkL7hLqGI2sZNIVuOQurBYwLzJgeGo_JdbDMUatA';
      config.headers.Authorization = `Bearer ${token}`;
    // if (userStr) {
    //   try {
    //     const user = JSON.parse(userStr);

    //     // If user has a token, attach it to the Authorization header
    //     if (user.token) {
    //       config.headers.Authorization = `Bearer ${user.token}`;
    //     }
    //   } catch (error) {
    //     console.error('Error parsing user from localStorage:', error);
    //   }
    // } else {
    //   // Use the provided Bearer token if no user in localStorage
    //   const token = 'eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJ3b2ZGYnJPNWQyWWpaSnVrSHR5Q3Z4cU1QeHBHMXB1emhPYm9qUjVkb3NnIn0.eyJleHAiOjE3NjU2Mjc3ODUsImlhdCI6MTc2NTYyMDU4NSwiYXV0aF90aW1lIjoxNzY1NjExNTk4LCJqdGkiOiJvbnJ0cnQ6NGM4MWFlODQtYjlmMi00YmI2LWEzZWYtNzI1N2RkYTgyMGQwIiwiaXNzIjoiaHR0cHM6Ly9rZXljbG9hay51YXQudXMuY29oZXJlbnQuZ2xvYmFsL2F1dGgvcmVhbG1zL2NvZ25pemFudCIsImF1ZCI6WyJwcm9kdWN0LWZhY3RvcnkiLCJyZWFsbS1tYW5hZ2VtZW50Il0sInN1YiI6ImZmNTFjMjBjLTQ1NmItNDUxZi04MWJlLTdjYjQyYzIzOTZiZSIsInR5cCI6IkJlYXJlciIsImF6cCI6InByb2R1Y3QtZmFjdG9yeSIsInNpZCI6ImJkN2JhMmUyLTY2NjQtNGRhMy05MzFiLWUyMjdlZTE0OWI4NSIsImFsbG93ZWQtb3JpZ2lucyI6WyJodHRwczovL21vZGVsaW5nLWNlbnRlci5kZXYuY29oZXJlbnQuZ2xvYmFsIiwiaHR0cHM6Ly9zYS51YXQudXMuY29oZXJlbnQuZ2xvYmFsIiwiaHR0cHM6Ly9tb2RlbGluZy1jZW50ZXIudXMuY29oZXJlbnQuZ2xvYmFsIiwiaHR0cHM6Ly9hc3Npc3RhbnQuc3RhZ2luZy5jb2hlcmVudC5nbG9iYWwiLCJodHRwczovL3NwYXJrLnVhdC51cy5jb2hlcmVudC5nbG9iYWwiLCJodHRwczovL2Fzc2lzdGFudC5leHQuY29oZXJlbnQuZ2xvYmFsIiwiaHR0cHM6Ly9wcm9kdWN0ZmFjdG9yeS51YXQudXMuY29oZXJlbnQuZ2xvYmFsIiwiaHR0cHM6Ly9zcGFyay11c2VyLW1hbmFnZXIudWF0LnVzLmNvaGVyZW50Lmdsb2JhbCIsImh0dHBzOi8vc2Euc3RhZ2luZy5jb2hlcmVudC5nbG9iYWwiLCJodHRwczovL21vZGVsaW5nLWNlbnRlci5zdGFnaW5nLmNvaGVyZW50Lmdsb2JhbCJdLCJyZXNvdXJjZV9hY2Nlc3MiOnsicmVhbG0tbWFuYWdlbWVudCI6eyJyb2xlcyI6WyJ2aWV3LXVzZXJzIiwicXVlcnktZ3JvdXBzIiwicXVlcnktdXNlcnMiXX19LCJzY29wZSI6Im9wZW5pZCBzcGFyayBwcm9maWxlIiwibmFtZSI6IlNhbmphbiBNdWtoZXJqZWUiLCJncm91cHMiOlsidXNlcjpwZiJdLCJyZWFsbSI6ImNvZ25pemFudCIsInByZWZlcnJlZF91c2VybmFtZSI6InNhbmphbmEubXVraGVyamVlQGNvZ25pemFudC5jb20iLCJnaXZlbl9uYW1lIjoiU2FuamFuIiwiZmFtaWx5X25hbWUiOiJNdWtoZXJqZWUiLCJ1c2VyX2NyZWF0ZWRfdGltZXN0YW1wIjoxNjY5NzAxMjI0MzI0LCJyZWxhdGlvbiI6InBhcnRuZXIifQ.j4fHc5Px71v4NLxb3IO0xmDYHcKHWkkRZ0xTPLSxin53GoRkZPmBBr5sq_dVc7syaim2Y_CRUEqNDgqN0rBUDQSF_g1Qv-Ps6D_5_Gx4XNqpus-dJscPl80zc1ahdHwl1BIqtLKkG1fXjmgHx4WtRwP4EnERtat4jX_whK7wYi8i1vJDJ5l65EP1TuYuR6NUIHgSJnjc3iElZvJgbpfWfIERvBAAxRUrlE5WEVsZ0icqpfwtIamWD2v86WRUSHCeLYrhNrCLkJ6zOKdMgmIdybopEkaFbLownuGJnAlA7zQ0mkAUMB6xd27aKncD6Rw_EfgM9eiOr4SOuBNFKHuhOg';
    //   config.headers.Authorization = `Bearer ${token}`;
    // }
    

    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// // Add response interceptor to handle 401 errors
// axiosInstance.interceptors.response.use(
//   (response) => {
//     return response;
//   },
//   (error) => {
//     // Handle 401 Unauthorized - redirect to login
//     if (error.response && error.response.status === 401) {
//       localStorage.removeItem('user');
//       window.location.href = '/signin';
//     }
    
//     return Promise.reject(error);
//   }
// );

// Helper methods for common HTTP operations
export const apiClient = {
  // GET request
  get: <T = any>(url: string, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> => {
    return axiosInstance.get<T>(url, config);
  },

  // POST request
  post: <T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> => {
    return axiosInstance.post<T>(url, data, config);
  },

  // PUT request
  put: <T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> => {
    return axiosInstance.put<T>(url, data, config);
  },

  // DELETE request
  delete: <T = any>(url: string, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> => {
    return axiosInstance.delete<T>(url, config);
  },

  // PATCH request
  patch: <T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> => {
    return axiosInstance.patch<T>(url, data, config);
  },
};

export default axiosInstance;
