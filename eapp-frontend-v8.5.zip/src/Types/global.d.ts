interface Window {
    Razorpay : any;
}