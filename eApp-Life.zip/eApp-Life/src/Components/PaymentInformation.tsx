import {
  Box,
  Divider,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableRow,
  TextField,
  Typography,
  tableCellClasses,
  Checkbox,
  Button,
  MenuItem,
  ToggleButton,
  ToggleButtonGroup,
  Stack,
  FormControlLabel,
} from "@mui/material";

import CloudUploadIcon from "@mui/icons-material/CloudUpload";
import * as React from "react";
import { Dropdown } from "./Dropdown/Dropdown";
import { getBankBranch, getBanks } from "./Dropdown/DropdownApi";
import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";
import { useEffect } from "react";
import styled from "@emotion/styled";

const StyledToggleButton = styled(ToggleButton)({
  // borderColor: '#000048',
  // color:'#000048',
  '&:Mui-selected':{
    // backgroundColor:'#000048',
      color:'#000048',
  },
  // '&.Mui-selected:hover':{
  //   backgroundColor:'#000036',
  // }
});

const CustomToggleButtonGroup = styled(ToggleButtonGroup)({
  borderColor:'#000048',
})

interface ChildComponentProps {
  fields: {
    PayerIsDifferentPerson: string;
    ModeofPayment: string;
    totalPremium: string;
    AmountOfPaymentWithThisApplication: string;
    AccountHolderFullName: string;
    AccountNumber: string;
    TypeOfAccount: string;
    BankNames: string;
    BankBranchNames: string;
    bookBank: any;
    renewalPaymentFrequency: string;
    renewalPremPayMethod: string;
    paymentMethod: string;
    checkBox: boolean;

    firstPremium:string;
    basicPlan:string;
  };
  setFields: React.Dispatch<
    React.SetStateAction<{
      PayerIsDifferentPerson: string;
      ModeofPayment: string;
      totalPremium: string;
      AmountOfPaymentWithThisApplication: string;
      AccountHolderFullName: string;
      AccountNumber: string;
      TypeOfAccount: string;
      BankNames: string;
      BankBranchNames: string;
      bookBank: any;
      renewalPaymentFrequency: string;
      renewalPremPayMethod: string;
      paymentMethod: string;
      checkBox: boolean;

      firstPremium:string;
      basicPlan:string;
    }>
  >;
  savedTransaction:any;  
}
const PaymentInformation: React.FC<ChildComponentProps> = ({
  fields,
  setFields,
  savedTransaction,
}) => {

  const handleFieldChange = (val: any, fieldName: string) => {
    const newFields = { ...fields, [fieldName]: val };
    console.log("After ==>", newFields);
    setFields({ ...newFields });
  };

 
  const setFiles = async (e: any) => {
    const file = e.target.files[0];
    // we need to get the raw bytes
    const buffer = await file.arrayBuffer();
    // each entry of array should contain 8 bits
    const bytes = new Uint8Array(buffer);
    handleFieldChange(bytes, "bookBank");
  };

  const handleButtonChange = (
    event: React.MouseEvent<HTMLElement>,
    fieldName: string
  ) => {
    console.log(event.currentTarget.textContent);
    const stateVal = event.currentTarget.textContent;
    setFields((fields) => ({ ...fields, [fieldName]: stateVal }));
    console.log("After ==>", fields);
  };

  // const label = { inputProps: { "aria-label": "Checkbox demo" } };

  const [banks, setBanks] = React.useState([]);
  const [bankBranches, setBankBranches] = React.useState([]);

  const handleChange = (
    value : boolean,
    fieldName: any,
  ) => {
    // const value = event.target.checked
    console.log("Bool value ==> ", value);
    setFields((prevFields) => ({
      ...prevFields,
      [fieldName]: value,
    }));
  };

  const TypeOfAccountOptn = [
    {
      value: "Savings",
      label: "Savings",
    },
    {
      value: "Current",
      label: "Current",
    },
    {
      value: "Salary",
      label: "Salary",
    },
    {
      value: "Custodial",
      label: "Custodial",
    },
  ];


  React.useEffect(() => {
    getBanks().then((res) => {
      setBanks(res.data);
    });
  }, []);
  useEffect(() => {
    setBankBranches([]);
    handleFieldChange("", "BankBranchNames");
    getBankBranch(fields.BankNames).then((res) => {
      setBankBranches(res.data);
    });
  }, [fields.BankNames]);

  const { t } = useTranslation();

  useEffect(() => {
    if (savedTransaction && savedTransaction.length > 0) {
      const firstPrem = savedTransaction[0]?.txn_output_json?.outputs?.PremiumSummary[1]?.basePlan;
      console.log("inside if",firstPrem);
      setFields((prevFields) => ({
        ...prevFields,
        totalPremium : firstPrem,
      }));
    }
  }, [savedTransaction]);

  return (
    <Box>
      <Paper elevation={3} sx={{ margin: 2 }}>
        <Box sx={{ padding: 2 }}>
          <Typography className="typography-main-header">
            {t("payment")}
          </Typography>
          <Divider />
          <Box sx={{ marginTop: 2 }}>
            <TableContainer>
              <Table
                className="table-main"
                aria-label="simple table"
              >
                <TableBody>
                  <TableRow>
                    <TableCell> {t("reference_no")}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>
                      <FormControlLabel
                        control={
                          <Checkbox 
                          checked={fields.checkBox}
                            onChange={(e) => handleChange(e.target.checked, "checkBox")}
                            inputProps={{ "aria-label": "controlled" }}
                          />
                        }
                        label={t("statement")}
                      />
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>
                      {t("mode_of_payment")}
                      <span style={{ color: "red" }}>*</span>{" "}
                    </TableCell>
                    <TableCell>
                      <CustomToggleButtonGroup
                        color="primary"
                        value={fields.renewalPaymentFrequency}
                        exclusive
                        fullWidth
                        size="small"
                        onChange={(event) =>
                          handleButtonChange(event, "renewalPaymentFrequency")
                        }
                        aria-label="Platform"
                      >
                        <StyledToggleButton value="Yearly">Yearly</StyledToggleButton>
                        <StyledToggleButton value="Half-Yearly">
                          Half-Yearly
                        </StyledToggleButton>
                        <StyledToggleButton value="Quaterly">Quaterly</StyledToggleButton>
                        <StyledToggleButton value="Monthly">Monthly</StyledToggleButton>
                        <StyledToggleButton value="Single">Single</StyledToggleButton>
                      </CustomToggleButtonGroup>
                    </TableCell>
                  </TableRow>

                  <TableRow>
                    <TableCell>
                      {t("please_choose_your_payment_method")}
                      <span style={{ color: "red" }}>*</span>{" "}
                    </TableCell>
                    <TableCell>
                      <ToggleButtonGroup
                        color="primary"
                        value={fields.paymentMethod}
                        exclusive
                        fullWidth
                        size="small"
                        onChange={(event) =>
                          handleButtonChange(event, "paymentMethod")
                        }
                        aria-label="Platform"
                      >
                        <ToggleButton value="Cash">Cash</ToggleButton>
                        <ToggleButton value="Bank Transfer">
                          Bank Transfer
                        </ToggleButton>
                        <ToggleButton value="Cheque">Cheque</ToggleButton>
                        <ToggleButton value="Credit Card">
                          Credit Card
                        </ToggleButton>
                      </ToggleButtonGroup>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        </Box>
      </Paper>
      <Paper elevation={3} sx={{ margin: 2 }}>
        <Box sx={{ padding: 2 }}>
          <Typography className="typography-main-header">
            {t("1st_premium_collected_details")}
          </Typography>
          <Divider />
          <Box sx={{ marginTop: 2 }}>
            <TableContainer>
              <Table
                className="table-main"
                aria-label="simple table"
              >
                <TableBody>
                  <TableRow>
                    <TableCell>
                    <TextField type="text" size="small" 
                      label={t("total_premium")}
                      variant="standard" 
                      value={fields.totalPremium}
                       ></TextField>
                    </TableCell>
                    <TableCell>
                      <TextField
                        size="small"
                        label={t("amount_of_payment_with_this_application")}
                        variant="standard"
                        value={fields.AmountOfPaymentWithThisApplication}
                        onChange={(e) =>
                          handleFieldChange(
                            e.target.value,
                            "AmountOfPaymentWithThisApplication"
                          )
                        }
                      ></TextField>
                    </TableCell>
                    <TableCell>
                    <TextField type="text" size="small" 
                      label={t("temporary_receipt_no")}
                      variant="standard" 
                      value="240030029"
                       ></TextField>
                    </TableCell>
                    {/* <TableCell> {t("total_premium")}</TableCell>
                    <TableCell>{fields.totalPremium}</TableCell> */}
                  </TableRow>
                  {/* <TableRow>
                    <TableCell>
                      {t("amount_of_payment_with_this_application")}
                    </TableCell>
                    <TableCell>
                      <TextField
                        size="small"
                        label={t("amount_of_payment_with_this_application")}
                        variant="standard"
                        value={fields.AmountOfPaymentWithThisApplication}
                        onChange={(e) =>
                          handleFieldChange(
                            e.target.value,
                            "AmountOfPaymentWithThisApplication"
                          )
                        }
                      ></TextField>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>{t("temporary_receipt_no")}</TableCell>
                    <TableCell>240030029</TableCell>
                  </TableRow> */}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        </Box>
      </Paper>
      <Paper elevation={3} sx={{ margin: 2 }}>
        <Box sx={{ padding: 2 }}>
          <Typography className="typography-main-header">
            {t("disbursement_information")}
          </Typography>
          <Divider />
          <Box sx={{ marginTop: 2 }}>
            <TableContainer>
              <Table
                className="table-main"
                aria-label="simple table"
              >
                <TableBody>
                  {/* <TableRow>
                    <TableCell>{t("state")}</TableCell>
                  </TableRow> */}
                  <TableRow>
                    {/* <TableCell> {t("account_holder_full_name")}</TableCell> */}
                    <TableCell>
                      <TextField
                        size="small"
                        id="outlined"
                        variant="standard"
                        label={t("account_holder_full_name")}
                        value={fields.AccountHolderFullName}
                        onChange={(e) =>
                          handleFieldChange(
                            e.target.value,
                            "AccountHolderFullName"
                          )
                        }
                      />
                    </TableCell>
                  {/* </TableRow>
                  <TableRow> */}
                    {/* <TableCell> {t("account_number")}</TableCell> */}
                    <TableCell>
                      <TextField
                        size="small"
                        id="outlined"
                        label={t("account_number")}
                        variant="standard"
                        value={fields.AccountNumber}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "AccountNumber")
                        }
                      />
                    </TableCell>
                  {/* </TableRow>
                  <TableRow> */}
                    {/* <TableCell> {t("type_of_account")}</TableCell> */}
                    <TableCell>
                      <TextField
                        id="outlined"
                        label={t("type_of_account")}
                        select
                        size="small"
                        variant="standard"
                        fullWidth
                        value={fields.TypeOfAccount}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "TypeOfAccount")
                        }
                      >
                        {TypeOfAccountOptn.map((option) => (
                          <MenuItem key={option.value} value={option.value}>
                            {option.label}
                          </MenuItem>
                        ))}
                      </TextField>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    {/* <TableCell>{t("bank_name")}</TableCell> */}
                    <TableCell>
                      <Dropdown
                        label={t("bank_name")}
                        options={banks}
                        value={fields.BankNames}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "BankNames")
                        }
                      />
                    </TableCell>
                    <TableCell>
                      <Dropdown
                        label={t("bank_branch_name")}
                        options={bankBranches}
                        value={fields.BankBranchNames}
                        onChange={(e) =>
                          handleFieldChange(e.target.value, "BankBranchNames")
                        }
                      />
                    </TableCell>
                    <TableCell>
                      {" "}
                      <Stack
                        spacing={2}
                        direction={"row"}
                        justifyContent={"flex-start"}
                        paddingRight={5}
                        paddingBottom={3}
                      >
                        <Button
                          variant="outlined"
                          component="label"
                          startIcon={<CloudUploadIcon />}
                        >
                          {t("book_bank")}
                          <input
                            name="documents"
                            type="file"
                            hidden
                            onInput={(e) => setFiles(e)}
                          />
                        </Button>

                        {fields.bookBank !== "" && (
                          <Link
                            onClick={() => {
                              var blob = new Blob(
                                [
                                  new Uint8Array(
                                    Object.keys(fields.bookBank).map(
                                      (key) => fields.bookBank[key]
                                    )
                                  ),
                                ],
                                { type: "application/pdf" }
                              );
                              var url = URL.createObjectURL(blob);
                              window.open(url);
                            }}
                            underline="always"
                            color="inherit"
                            sx={{ color: "purple" }}
                          >
                            View File
                          </Link>
                        )}
                      </Stack>
                    </TableCell>
                  </TableRow>
                  {/* <TableRow>
                    <TableCell>{t("bank_branch_name")}</TableCell>
                    
                  </TableRow> */}
                  {/* <TableRow>
                    <TableCell>{t("book_bank")}</TableCell>
                    
                  </TableRow> */}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        </Box>
      </Paper>

      <Paper elevation={3} sx={{ margin: 2 }}>
        <Box sx={{ padding: 2 }}>
          <Typography className="typography-main-header">
            {t("renewal_premium_payment")}
          </Typography>
          <Divider />
          <Box sx={{ marginTop: 2 }}>
            <TableContainer>
              <Table
                className="table-main"
                aria-label="simple table"
              >
                <TableBody>
                  <TableRow>
                    <TableCell>{t("renewal_premium_payment_method")}</TableCell>
                    <TableCell>
                      <ToggleButtonGroup
                        color="primary"
                        value={fields.renewalPremPayMethod}
                        exclusive
                        fullWidth
                        onChange={(event) =>
                          handleButtonChange(event, "renewalPremPayMethod")
                        }
                        aria-label="Platform"
                      >
                        <ToggleButton value="Cash">Cash</ToggleButton>
                        <ToggleButton value="Credit Card">
                          Credit Card
                        </ToggleButton>
                        <ToggleButton value="GIRO">GIRO</ToggleButton>
                      </ToggleButtonGroup>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        </Box>
      </Paper>
    </Box>
  );
};

export default PaymentInformation;
