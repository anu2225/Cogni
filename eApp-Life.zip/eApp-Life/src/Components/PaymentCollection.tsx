import styled from "@emotion/styled";
import {
  Box,
  Button,
  Divider,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableRow,
  TextField,
  ToggleButton,
  ToggleButtonGroup,
  Typography,
  tableCellClasses,
} from "@mui/material";
import { DateField, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import axios from "axios";
import dayjs from "dayjs";
import { useEffect } from "react";
import { useTranslation } from "react-i18next";
import PaymentIcon from "@mui/icons-material/Payment";

const StyledButton = styled(Button)({
  backgroundColor: "#000048",
  color: "#ffffff",
  borderRadius: "20px",
  "&:hover": {
    backgroundColor: "#000036",
  },
});

// const StyledButton = styled(Button)({
//   backgroundColor: "#ffffff",
//   color: "#000048",
//   borderColor: "#000048",
//   borderRadius: "20px",
//   "&:hover": {
//     color: "#ffffff",
//     backgroundColor: "#000048",
//   },
// });

interface ChildComponentProps {
  fields: {
    paymentMethod: string;
    paymentReceived: string;
    annualPremium: number;
    paymentDueDate: dayjs.Dayjs;
    extraPremium: string;
    other: string;
    totalPaidAmount: string;
    amountPaidInWords: string;
    tempReceiptDate: dayjs.Dayjs;

    //
    check: string;
  };
  setFields: React.Dispatch<
    React.SetStateAction<{
      paymentMethod: string;
      paymentReceived: string;
      annualPremium: number;
      paymentDueDate: dayjs.Dayjs;
      extraPremium: string;
      other: string;
      totalPaidAmount: string;
      amountPaidInWords: string;
      tempReceiptDate: dayjs.Dayjs;
      //
      check: string;
    }>
  >;
  savedTransaction: any;
}

const PaymentCollection: React.FC<ChildComponentProps> = ({
  fields,
  setFields,
  savedTransaction,
}) => {
  const handleFieldChange = (val: any, fieldName: string) => {
    const newFields = { ...fields, [fieldName]: val };
    console.log("After ==>", newFields);
    setFields({ ...newFields });
  };

  const handleButtonChange = (
    event: React.MouseEvent<HTMLElement>,
    fieldName: string
  ) => {
    console.log(event.currentTarget.textContent);
    const stateVal = event.currentTarget.textContent;
    setFields((fields) => ({ ...fields, [fieldName]: stateVal }));
  };

  useEffect(() => {
    if (savedTransaction && savedTransaction.length > 0) {
      setFields((prevFields) => ({
        ...prevFields,
        annualPremium:
          savedTransaction[0]?.txn_output_json?.outputs?.PremiumSummary[1]
            ?.totalInstallmentPremium,
        check: savedTransaction[0]?.txn_input_json["SSPP.Policy_Term"],
      }));
    }
  }, [savedTransaction]);

  const createOrder = async () => {
    try {
      console.log("Amount is =>", fields.annualPremium);
      console.log("Type of", typeof fields.annualPremium);
      const result = await axios.post(
        `http://localhost:8001/eapp/payments/createPaymentTransaction/?amount=${
          fields.annualPremium * 100
        }`,
        {
          mode: "no-cors",
          // method: 'GET',
        }
      );
      const { orderId } = result.data;

      const options = {
        //key:"rzp_test_1Vkv26rKzSCi4u",
        key: "rzp_test_5OqmwaVdTGWLd6",
        amount: fields.annualPremium * 100,
        currency: "INR",
        name: "Test",
        description: "test desc",

        orderId: orderId,
        handler: function (response: {
          razorpay_payment_id: any;
          razorpay_order_id: any;
          razorpay_signature: any;
        }) {
          console.log("Response", response);
          // alert(response.razorpay_payment_id);
          // alert(response.razorpay_order_id);
          // alert(response.razorpay_signature);
        },
        prefill: {
          name: "userName",
          email: "email",
          contact: "contact",
        },
        notes: {
          address: "ABC, Delhi",
        },
        theme: {
          color: "#3399cc",
        },
      };

      const rzp1 = new window.Razorpay(options);
      rzp1.open();
    } catch (error) {
      console.error("Error in creating order", error);
    }
  };

  const { t } = useTranslation();
  return (
    <Box>
      <Paper elevation={3} sx={{ margin: 2 }}>
        <Box sx={{ padding: 2 }}>
          <Typography className="typography-main-header">
            {t("payment")}
          </Typography>
          <Divider />
          <Box sx={{ marginTop: 2 }}>
            <TableContainer>
              <Table
                className="table-main"
                aria-label="table2"
              >
                <TableBody>
                  <TableRow>
                    <TableCell>{t("mode_of_payment")}</TableCell>
                    <TableCell>Yearly</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>
                      {t("please_choose_your_payment_method")}
                    </TableCell>
                    <TableCell>
                      <ToggleButtonGroup
                        color="primary"
                        value={fields.paymentMethod}
                        exclusive
                        fullWidth
                        size="small"
                        onChange={(event) =>
                          handleButtonChange(event, "paymentMethod")
                        }
                        aria-label="Platform"
                      >
                        <ToggleButton value="Cash">Cash</ToggleButton>
                        <ToggleButton value="Credit Card">
                          Credit Card
                        </ToggleButton>
                      </ToggleButtonGroup>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        </Box>
      </Paper>
      {fields.paymentMethod === "Cash" && (
        <Paper elevation={3} sx={{ margin: 2 }}>
          <Box sx={{ padding: 2 }}>
            <Typography className="typography-main-header">
              {t("cbr_tr")}
            </Typography>
            <Divider />
            <Box sx={{ marginTop: 2 }}>
              <TableContainer>
                <Table
                  className="table-main"
                >
                  <TableBody>
                    <TableRow>
                      {/* <TableCell>{t("renewal_premium_due_date")}</TableCell> */}
                      <TableCell>
                        <LocalizationProvider dateAdapter={AdapterDayjs}>
                          <DateField
                            size="small"
                            variant="standard"
                            label={t("renewal_premium_due_date")}
                            readOnly
                            value={dayjs(fields.paymentDueDate)}
                          />
                        </LocalizationProvider>
                      </TableCell>
                      <TableCell>
                        <TextField
                          type="text"
                          size="small"
                          label={t("extra_premiuim_for_new_business")}
                          variant="standard"
                          value={fields.extraPremium}
                          onChange={(e) =>
                            handleFieldChange(e.target.value, "extraPremium")
                          }
                        ></TextField>
                      </TableCell>
                      <TableCell>
                        <TextField
                          type="text"
                          size="small"
                          variant="standard"
                          label={t("other")}
                          value={fields.other}
                          onChange={(e) =>
                            handleFieldChange(e.target.value, "other")
                          }
                        ></TextField>
                      </TableCell>
                    </TableRow>
                    {/* <TableRow>
                    <TableCell>
                      {t("extra_premiuim_for_new_business")}
                    </TableCell>
                    
                  </TableRow> */}
                    {/* <TableRow>
                    <TableCell>{t("other")}</TableCell>
                    
                      
                  </TableRow> */}
                    <TableRow>
                      {/* <TableCell>{t("total_paid_amount")} </TableCell> */}
                      <TableCell>
                        <TextField
                          type="number"
                          size="small"
                          label={t("total_paid_amount")}
                          variant="standard"
                          value={fields.totalPaidAmount}
                          onChange={(e) =>
                            handleFieldChange(e.target.value, "totalPaidAmount")
                          }
                        ></TextField>
                      </TableCell>
                      <TableCell>
                        <TextField
                          type="text"
                          size="small"
                          variant="standard"
                          label={t("amount_in_word")}
                          value={fields.amountPaidInWords}
                          onChange={(e) =>
                            handleFieldChange(
                              e.target.value,
                              "amountPaidInWords"
                            )
                          }
                        ></TextField>
                      </TableCell>
                    </TableRow>
                    {/* <TableRow>
                    <TableCell>{t("amount_in_word")}</TableCell>
                    
                  </TableRow> */}
                    <TableRow>
                      <TableCell>{t("payment_received")}</TableCell>
                      <TableCell>
                        <ToggleButtonGroup
                          color="primary"
                          value={fields.paymentReceived}
                          exclusive
                          fullWidth
                          size="small"
                          onChange={(event) =>
                            handleButtonChange(event, "paymentReceived")
                          }
                          aria-label="Platform"
                        >
                          <ToggleButton value="Yes">Yes</ToggleButton>
                          <ToggleButton value="No">No</ToggleButton>
                        </ToggleButtonGroup>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      {/* <TableCell>{t("temporary_receipt_date")}</TableCell> */}
                      {fields.paymentReceived === "Yes" && (
                        <TableCell>
                          <LocalizationProvider dateAdapter={AdapterDayjs}>
                            <DateField
                              size="small"
                              variant="standard"
                              label={t("temporary_receipt_date")}
                              readOnly
                              value={dayjs(fields.tempReceiptDate)}
                            />
                          </LocalizationProvider>
                        </TableCell>
                      )}
                      <TableCell>
                        <TextField
                          type="text"
                          size="small"
                          label={t("payment_status")}
                          variant="standard"
                          value={
                            fields.paymentReceived === "No"
                              ? "Not Paid"
                              : "Paid"
                          }
                        ></TextField>
                      </TableCell>
                      <TableCell>
                        <TextField
                          type="text"
                          size="small"
                          label={t("collection_status")}
                          variant="standard"
                          value={
                            fields.paymentReceived === "No"
                              ? "Pending Collection"
                              : "Amount Received"
                          }
                        ></TextField>
                      </TableCell>
                    </TableRow>
                    {/* <TableRow>
                    <TableCell>{t("payment_status")}</TableCell>
                    {fields.paymentReceived === "No" && (
                    <TableCell>Not Paid</TableCell>
                    )}
                    {fields.paymentReceived === "Yes" && (
                      <TableCell>Paid</TableCell>
                    )}
                  </TableRow>
                  <TableRow>
                    <TableCell>{t("collection_status")} </TableCell>
                    {fields.paymentReceived === "No" && (
                      <TableCell>Pending Collection</TableCell>
                    )}
                    {fields.paymentReceived === "Yes" && (
                      <TableCell>Amount Received</TableCell>
                    )}
                  </TableRow> */}
                  </TableBody>
                </Table>
              </TableContainer>
            </Box>
          </Box>
        </Paper>
      )}

      {fields.paymentMethod === "Credit Card" && (
        <Paper elevation={3} sx={{ margin: 2 }}>
          <Box sx={{ padding: 2 }}>
            <Typography className="typography-main-header">
              {t("issue_payment_request")}
            </Typography>
            <Divider />
            <Box sx={{ marginTop: 2 }}>
              <TableContainer>
                <Table
                  className="table-main"
                >
                  <TableBody>
                    <TableRow>
                      {/* <TableCell>{t("policy_number")}</TableCell>
                    <TableCell>A510405043{fields.check} </TableCell> */}
                      <TableCell>
                        <TextField
                          type="text"
                          size="small"
                          label={t("policy_number")}
                          variant="standard"
                          value={`A510405043${fields.check}`}
                        ></TextField>
                      </TableCell>
                      <TableCell>
                        <TextField
                          type="text"
                          size="small"
                          label={t("reference_number")}
                          variant="standard"
                          value="240030029"
                        ></TextField>
                      </TableCell>
                      <TableCell>
                        <TextField
                          type="text"
                          size="small"
                          label={t("annual_premiuim")}
                          variant="standard"
                          value={fields.annualPremium}
                        ></TextField>
                      </TableCell>
                      <TableCell>
                        <TextField
                          type="text"
                          size="small"
                          label={t("collection_status")}
                          variant="standard"
                          value={fields.check}
                        ></TextField>
                      </TableCell>
                    </TableRow>
                    {/* <TableRow>
                    <TableCell>{t("reference_number")}</TableCell>
                    <TableCell>240030029 </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>{t("annual_premiuim")}</TableCell>
                    <TableCell>{fields.annualPremium}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>{t("collection_status")}</TableCell>
                    {success === true && (
                      <TableCell>Successful</TableCell>
                    )}
                    {success === false && (
                      <TableCell></TableCell>
                    )}
                    <TableCell>{fields.check}</TableCell>
                  </TableRow> */}
                  </TableBody>
                </Table>
              </TableContainer>
              <Box sx={{ margin: 2 }}>
                <StyledButton
                  variant="contained"
                  size="medium"
                  color="primary"
                  startIcon={<PaymentIcon />}
                  aria-label="Basic button group"
                  onClick={createOrder}
                >
                  {t("request_payment")}
                </StyledButton>
              </Box>
            </Box>
          </Box>
        </Paper>
      )}
    </Box>
  );
};

export default PaymentCollection;
