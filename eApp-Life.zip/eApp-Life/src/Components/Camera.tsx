import styled from "@emotion/styled";
import { Button } from "@mui/material";
import React, { useEffect, useRef, useState } from "react";

const StyledButton = styled(Button)({
  backgroundColor: '#ffffff',
  color:'#000048',
  '&:hover':{
      color:'#000048',
  }
})

const Camera: React.FC <{handleFieldChange:Function}> = ({handleFieldChange}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
const [cameraActive, setCameraActive] = useState<boolean>(false);
  const [parentHeight, setParentHeight] = useState<string>("auto");

  const startCamera = () => {
    navigator.mediaDevices
      .getUserMedia({ video: true })
      .then((stream) => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
setCameraActive(true);
          setParentHeight("auto");
        }
      })
      .catch((error) => {
        console.error("Error Accessing the camera:", error);
      });
  };

  useEffect(()=>{
    console.log("UseEffect imgURL ==>",capturedImage)
    handleFieldChange(capturedImage,"imgURL");
  },[capturedImage])

  const captureImage = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const context = canvas.getContext("2d");

      if (context) {
        const videoWidth = video.videoWidth;
        const videoHeight = video.videoHeight;

        canvas.width = videoWidth;
        canvas.height = videoHeight;

        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        const imageDataUrl = canvas.toDataURL("image/png");

        setCapturedImage(imageDataUrl);
        // setTimeout(() => {
        //   handleFieldChange(imageDataUrl,"imgURL");
        // },0)
        // console.log("Img URL ==>",imageDataUrl)

        const stream = video.srcObject as MediaStream;
        const tracks = stream.getTracks();
        tracks.forEach((track) => track.stop());
setCameraActive(false);
        setParentHeight("100px");
      }
    }
  };

  return (
    <div style={{ minHeight: parentHeight }}>
      <div style={{ position: "relative" }}>
        <video
          ref={videoRef}
          autoPlay
          style={{ width: "auto", height: "auto", display: cameraActive ? "block" : "none" }}
        ></video>
        {/* {capturedImage && (
          <img
            src={capturedImage}
            alt="Captured Image"
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              maxWidth: "100%",
              height: "auto",
            }}
          />
        )} */}
      </div>
      <div>
        {!capturedImage ? (
          <StyledButton onClick={startCamera}> Start Camera</StyledButton>
        ) : (
          <StyledButton onClick={() => setCapturedImage(null)}>Retake</StyledButton>
        )}
        {!capturedImage && <StyledButton onClick={captureImage}>Capture</StyledButton>}
      </div>
      <canvas ref={canvasRef} style={{ display: "none" }}></canvas>
    </div>
  );
};
export default Camera;

