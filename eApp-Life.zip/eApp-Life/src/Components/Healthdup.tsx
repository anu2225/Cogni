import React from 'react';
import { Box, Paper, Typography, Divider, TableContainer, Table, TableBody, TableRow, TableCell, TextField, MenuItem, useMediaQuery, useTheme } from '@mui/material';
import { useTranslation } from 'react-i18next';
import '../styles.css';

const Health: React.FC<{ fields: any, handleFieldChange: any, QuestionnaireYesNoOptn: any[] }> = ({ fields, handleFieldChange, QuestionnaireYesNoOptn }) => {
  const { t } = useTranslation();
  const theme = useTheme();
  const isSmallScreen = useMediaQuery(theme.breakpoints.down("sm"));

  return (
    <Box sx={{ width: '100%', padding: 2 }}>
      <Paper elevation={3} sx={{ margin: 2 }}>
        <Box sx={{ padding: 2 }}>
          <Typography className="typography-main-header">
            {t("health_questionnaire")}
          </Typography>
          <Divider />
          <Box sx={{ padding: 2 }}>
            <Divider />
            <Box sx={{ marginTop: 2 }}>
              <TableContainer>
                <Table className="table-main" aria-label="health questionnaire table">
                  <TableBody>
                    {[
                      "hq1",
                      "hq2",
                      "hq3",
                      "hq4",
                      "hq5",
                      "hq6",
                      "hq7",
                      "hq8",
                      "hq9",
                      "hq10",
                      "hq11",
                    ].map((key, index) => (
                      <TableRow
                        key={index}
                        sx={{
                          display: isSmallScreen ? "block" : "table-row",
                          marginBottom: isSmallScreen ? "16px" : 0,
                        }}
                      >
                        <TableCell
                          sx={{
                            display: isSmallScreen ? "block" : "table-cell",
                            fontWeight: isSmallScreen ? "bold" : "normal",
                            width: isSmallScreen ? '100%' : 'auto',
                          }}
                        >
                          {t(key)}
                        </TableCell>
                        <TableCell
                          sx={{
                            display: isSmallScreen ? "block" : "table-cell",
                            width: isSmallScreen ? '100%' : 'auto',
                          }}
                        >
                          <TextField
                            id={`Questionnaire${index + 1}`}
                            select={index < 8} // First 8 are select fields
                            size="small"
                            fullWidth
                            value={fields[`Questionnaire${index + 1}` as keyof typeof fields]}
                            onChange={(e) =>
                              handleFieldChange(e, `Questionnaire${index + 1}` as keyof typeof fields)
                            }
                          >
                            {index < 8 &&
                              QuestionnaireYesNoOptn.map((option) => (
                                <MenuItem
                                  key={option.value}
                                  value={option.value}
                                >
                                  {option.label}
                                </MenuItem>
                              ))}
                          </TextField>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </Box>
          </Box>
        </Box>
      </Paper>
    </Box>
  );
};

export default Health;