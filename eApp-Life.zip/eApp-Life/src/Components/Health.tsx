import React from "react";

import {
  Box,
  Divider,
  MenuItem,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableRow,
  TextField,
  Typography,
  useMediaQuery,
} from "@mui/material";
// import { useMediaQuery } from 'react-responsive';

import { useTranslation } from "react-i18next";

interface ChildComponentProps {
  fields: {
    Questionnaire11: string;

    Questionnaire10: string;

    Questionnaire9: string;

    Questionnaire8: string;

    Questionnaire7: string;

    Questionnaire6: string;

    Questionnaire5: string;

    Questionnaire4: string;

    Questionnaire3: string;

    Questionnaire2: string;

    Questionnaire1: string;
  };

  setFields: React.Dispatch<
    React.SetStateAction<{
      Questionnaire8: string;

      Questionnaire7: string;

      Questionnaire6: string;

      Questionnaire5: string;

      Questionnaire4: string;

      Questionnaire3: string;

      Questionnaire2: string;

      Questionnaire1: string;

      Questionnaire11: string;

      Questionnaire10: string;

      Questionnaire9: string;
    }>
  >;
}

const Health: React.FC<ChildComponentProps> = ({ fields, setFields }) => {
  const handleFieldChange = (
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,

    fieldName: keyof typeof fields
  ) => {
    const { value } = event.target;

    setFields((prevFields) => ({ ...prevFields, [fieldName]: value }));
  };

  const QuestionnaireYesNoOptn = [
    { value: "No", label: "No" },

    { value: "Yes", label: "Yes" },
  ];

  const { t } = useTranslation();

  // Use useMediaQuery for conditional layout changes

  const isSmallScreen = useMediaQuery("(max-width:600px)");

  return (
    <Box>
      <Paper elevation={3} sx={{ margin: 2 }}>
        <Box sx={{ padding: 2 }}>
          <Typography className="typography-main-header">
            {t("health_questionnaire")}
          </Typography>
          <Divider />
          <Box sx={{ padding: 2 }}>
            <Divider />
            <Box sx={{ marginTop: 2 }}>
              <TableContainer>
                <Table className="table-main" aria-label="health questionnaire table">
                  <TableBody>
                    {[
                      "hq1",

                      "hq2",

                      "hq3",

                      "hq4",

                      "hq5",

                      "hq6",

                      "hq7",

                      "hq8",

                      "hq9",

                      "hq10",

                      "hq11",
                    ].map((key, index) => (
                      <TableRow
                        key={index}
                        sx={{
                          display: isSmallScreen ? "block" : "table-row",

                          marginBottom: isSmallScreen ? "16px" : 0,
                        }}
                      >
                        <TableCell
                          sx={{
                            display: isSmallScreen ? "block" : "table-cell",

                            fontWeight: isSmallScreen ? "bold" : "normal",
                          }}
                        >
                          {t(key)}
                        </TableCell>
                        <TableCell
                          sx={{
                            display: isSmallScreen ? "block" : "table-cell",
                          }}
                        >
                          <TextField
                            id={`Questionnaire${index + 1}`}
                            select={index < 8} // First 8 are select fields
                            size="small"
                            fullWidth
                            value={fields[`Questionnaire${index + 1}` as keyof typeof fields]}
                            onChange={(e) =>
                              handleFieldChange(e, `Questionnaire${index + 1}`as keyof typeof fields)
                            }
                          >
                            {index < 8 &&
                              QuestionnaireYesNoOptn.map((option) => (
                                <MenuItem
                                  key={option.value}
                                  value={option.value}
                                >
                                  {option.label}
                                </MenuItem>
                              ))}
                          </TextField>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </Box>
          </Box>
        </Box>
      </Paper>
    </Box>
  );
};

export default Health;
